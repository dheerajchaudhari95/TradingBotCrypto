# V2 BreakoutV1 — Development Notes

## Status
**FINALIZED.** `BreakoutV1.py` contains the canonical, evidence-validated strategy design:
- 4H Donchian Channel Breakout with daily EMA200 macro filter
- **3.0x ATR custom stoploss** (evidence-based correction from the original 2.0x design)
- In-sample backtest: 2021–2026, BTC/USDT + ETH/USDT
- Out-of-sample validation: 2017–2021, 112 trades, +10.12% total return
- MFE/MAE analysis confirmed 3.0x ATR as the optimal stop width
- Archived superseded variants: `V2/archive/BreakoutV1_stop25.py`, `V2/archive/BreakoutV1_stop30.py`
- RSIMeanReversion retired to `V2/archive/` after evidence-based rejection (see `V2/archive/README_ARCHIVED.md`)

---

## 0. Informative Pairs — Verified Syntax (Freqtrade 2026.8)

**Source verified:** https://www.freqtrade.io/en/stable/strategy-customization/#informative-pairs

Two supported patterns exist. We use the `@informative` decorator (the simpler, preferred approach):

### Pattern used in BreakoutV1.py

```python
from freqtrade.strategy import IStrategy, informative, stoploss_from_absolute

class BreakoutV1(IStrategy):
    @informative('1d')
    def populate_indicators_1d(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['ema200'] = ta.ema(dataframe['close'], length=200)
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 'ema200_1d' is available here — auto-merged and ffilled by the decorator
        # (1d value forward-filled into every 4h candle)
        ...
```

**Column naming rule (confirmed from docs):**
- `@informative('1d')` on same-pair method (no `asset=` arg) → columns suffixed with `_1d`
- `'ema200'` in the 1d frame becomes `'ema200_1d'` in the 4h dataframe

**Key doc notes:**
- `informative_pairs()` override is NOT required when using the decorator
- `ffill=True` is the default — daily value is forward-filled into every 4h candle
- Decorated method names must be unique (no copy-paste with same name)
- Do NOT use decorator if one informative pair needs data from another informative pair (use `merge_informative_pair()` manually in that case)
- `startup_candle_count` should account for warmup of the daily EMA200 (200 daily candles)

### Alternative: merge_informative_pair() (not used here)
```python
from freqtrade.strategy import merge_informative_pair

def informative_pairs(self):
    return [("BTC/USDT", "1d")]

def populate_indicators(self, dataframe, metadata):
    inf_df = self.dp.get_pair_dataframe(metadata['pair'], '1d')
    inf_df['ema200'] = ta.ema(inf_df['close'], length=200)
    dataframe = merge_informative_pair(dataframe, inf_df, self.timeframe, '1d', ffill=True)
    # column becomes 'ema200_1d'
    return dataframe
```

**Decision:** `@informative` chosen for cleanliness. Only one higher-TF indicator needed, no cross-informative dependencies.

---

## 1. Freqtrade Backtesting Fee Handling (Verified)

### Default Behaviour
Freqtrade uses the exchange's **default trading fee** (typically the base/lowest tier) automatically during backtesting and dry-run when no explicit fee is configured.

For **Binance spot**:
- Standard maker/taker fee: **0.1% per side** (`0.001` as a ratio)
- Fees are applied **twice per round-trip trade**: once on entry, once on exit
- Total fee drag per trade: **0.2%** at standard Binance rates

### How Freqtrade Applies Fees in Backtest
Source: [Official Freqtrade Backtesting Docs](https://www.freqtrade.io/en/stable/backtesting/)

- Freqtrade fetches the fee directly from the exchange object via CCXT at the start of each backtest run
- The fee is applied as: `trade_profit *= (1 - fee)` at entry and `(1 - fee)` at exit
- This correctly erodes profit on both sides of every trade

### Explicit Fee Configuration (Used in V2)
In `config_breakout.json`, the fee is explicitly set:
```json
"fee": 0.001
```

**Rationale:** 
- Explicit configuration makes the assumption visible and auditable
- Removes dependence on live exchange API availability during offline backtesting
- `0.001` = 0.1% = Binance standard spot fee, consistent with V1's backtest assumptions
- If BNB discount is enabled on the real account (~0.075%), backtests at 0.1% will be **conservative** (pessimistic), which is the correct direction for validation

### Override Methods Available
| Method | Syntax | Use Case |
|---|---|---|
| Config file | `"fee": 0.001` | Default for all backtests in this project |
| CLI override | `--fee 0.001` | One-off override without changing config |

### Binance Fee Context
- Standard spot: 0.1% maker and taker
- With BNB payment discount: ~0.075%
- VIP tiers start at $1M/month 30-day volume — not applicable here
- **Conservative assumption:** use 0.1% for all backtests unless specifically testing fee sensitivity

---

## 2. Data Downloaded

**Command run:**
```
freqtrade download-data --exchange binance --pairs BTC/USDT ETH/USDT --timeframe 4h --timerange 20210101-20260913 --datadir user_data/data/binance
```

**Location:** `V2/user_data/data/binance/`

**Files:**
- `BTC_USDT-4h.json`
- `ETH_USDT-4h.json`

**Expected range:** 2021-01-01 to 2026-09-13 (~5.7 years, ~12,400 4H candles per pair)

*(Actual range confirmed after download — see task report)*

---

## 3. Environment Isolation

V2 uses its own env var names to prevent accidental credential bleed from V1:

| Variable | Used For |
|---|---|
| `BINANCE_API_KEY_V2` | V2 exchange key |
| `BINANCE_API_SECRET_V2` | V2 exchange secret |
| `FREQTRADE_V2_API_USERNAME` | V2 REST API username |
| `FREQTRADE_V2_API_PASSWORD` | V2 REST API password |
| `TELEGRAM_BOT_TOKEN_V2` | V2 Telegram bot (separate bot from V1) |
| `TELEGRAM_CHAT_ID_V2` | V2 Telegram chat |

**Note:** For data download and backtesting, API keys are not required (public data only). Keys only needed if deploying V2 live.

---

## 4. Development History & Decisions

| Phase | Description | Outcome |
|---|---|---|
| Initial build | BreakoutV1.py with 2.0x ATR stop | 281 trades, 99% stop-loss exits |
| MFE/MAE analysis | Checked 20-candle post-stop excursion for 278 trailing-stop exits | Evidence supported widening stop |
| Stop comparison | Backtested 2.5x vs 3.0x ATR | 3.0x ATR selected |
| Out-of-sample validation | 2017–2021, BreakoutV1_stop30 | 112 trades, +10.12% return |
| RSI strategy test | RSIMeanReversion tested with same rigour | Negative blended return (-4.44% to -5.27%); rejected |
| **Canonical promotion** | `BreakoutV1_stop30.py` → `BreakoutV1.py` | **Current state: FINALIZED** |

---

## 5. Project Isolation Rule (Reminder)

> V2 must never reference a V1 file by path.
> If V2 needs something from V1, it must be **copied into V2 first**.

This file, `config_breakout.json`, `BreakoutV1.py`, and all data in `V2/user_data/` are fully independent copies. No symlinks, no relative paths escaping into `../V1/`.
