import json
import zipfile
import glob
from pathlib import Path
import pandas as pd
import pandas_ta as ta
import numpy as np

def main():
    results_dir = Path('user_data/backtest_results')
    data_dir = Path('user_data/data/binance')
    
    zips = glob.glob(str(results_dir / '*.zip'))
    if not zips:
        print('No zip found')
        return
    latest_zip = max(zips, key=lambda x: Path(x).stat().st_mtime)

    with zipfile.ZipFile(latest_zip, 'r') as z:
        names = z.namelist()
        for name in names:
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    break

    trades = data['strategy']['BreakoutV1']['trades']
    
    # Load OHLCV data
    dfs = {}
    for pair in ['BTC/USDT', 'ETH/USDT']:
        file_pair = pair.replace('/', '_')
        feather_path = data_dir / f"{file_pair}-4h.feather"
        df = pd.read_feather(feather_path)
        df['date'] = pd.to_datetime(df['date'], utc=True)
        df = df.sort_values('date').reset_index(drop=True)
        # Calculate ATR(14) since it's not saved in the raw feather file
        df.ta.atr(length=14, append=True)
        # pandas_ta names the column 'ATRr_14'
        df.rename(columns={'ATRr_14': 'atr'}, inplace=True)
        dfs[pair] = df

    stopped_trades = [t for t in trades if t['exit_reason'] == 'trailing_stop_loss']
    
    # We only care about the losers from the 2x ATR run to answer the recovery question
    loser_trades = [t for t in stopped_trades if t['profit_ratio'] < 0]
    
    multiples = [2.5, 3.0, 4.0]
    
    # Stats tracking
    # 141 trades recovered in the 10-candle window. We want to see how many of them survive the wider stop.
    recovered_survivors = {m: 0 for m in multiples}
    total_recovered = 0
    total_never_recovered = 0
    
    extra_loss_acc = {m: [] for m in multiples}
    
    for t in loser_trades:
        pair = t['pair']
        df = dfs[pair]
        
        open_date = pd.to_datetime(t['open_date'], utc=True)
        close_date = pd.to_datetime(t['close_date'], utc=True)
        open_rate = t['open_rate']
        close_rate = t['close_rate']
        max_rate = t['max_rate']
        
        # Get entry ATR
        entry_history = df[df['date'] <= open_date]
        if len(entry_history) == 0:
            continue
        entry_atr = entry_history.iloc[-1]['atr']
        
        # Get next 10 candles strictly AFTER close
        sub_df = df[df['date'] > close_date].head(10)
        
        breakeven_price = open_rate * 1.002
        recovered = False
        lowest_low_before_recovery = float('inf')
        
        for idx, row in sub_df.iterrows():
            # Conservative check: assume low is hit before high in the same candle
            if row['low'] < lowest_low_before_recovery:
                lowest_low_before_recovery = row['low']
                
            if row['high'] > breakeven_price:
                recovered = True
                break
                
        if recovered:
            total_recovered += 1
            for m in multiples:
                # Calculate where the wider stop would have been
                wider_stop_price = max_rate - (m * entry_atr)
                # Hard floor -10% limit
                wider_stop_price = max(wider_stop_price, open_rate * 0.90)
                
                # Did it survive?
                if lowest_low_before_recovery > wider_stop_price:
                    recovered_survivors[m] += 1
        else:
            total_never_recovered += 1
            for m in multiples:
                wider_stop_price = max_rate - (m * entry_atr)
                wider_stop_price = max(wider_stop_price, open_rate * 0.90)
                
                # Extra loss is the difference between where we exited (close_rate) and where we would exit
                # Wait, if lowest_low didn't even hit the wider stop in 10 candles, it would be still open.
                # But assuming it eventually hits it or we just measure the added risk distance:
                # The extra distance down to the wider stop is:
                extra_drop = close_rate - wider_stop_price
                if extra_drop > 0:
                    extra_loss_pct = (extra_drop / open_rate) * 100
                    extra_loss_acc[m].append(extra_loss_pct)

    print("\n--- Wider Stop Survival Analysis ---")
    print(f"Base metric: Of {len(loser_trades)} losing trailing-stop trades, {total_recovered} eventually reached breakeven in 10 candles.")
    print("If we used a wider stop from the start, would they have survived the dip to actually see that recovery?\n")
    
    print(f"{'Stop Width':<15} | {'Recoveries Preserved':<25} | {'Added Risk (Avg Extra Loss on the rest)':<40}")
    print("-" * 85)
    
    for m in multiples:
        survivors = recovered_survivors[m]
        avg_extra_loss = np.mean(extra_loss_acc[m]) if len(extra_loss_acc[m]) > 0 else 0
        
        pct_preserved = (survivors / total_recovered) * 100 if total_recovered > 0 else 0
        
        print(f"{m}x ATR         | {survivors}/{total_recovered} ({pct_preserved:.1f}%) preserved | +{avg_extra_loss:.2f}% worse per non-recovered trade")

if __name__ == "__main__":
    main()
