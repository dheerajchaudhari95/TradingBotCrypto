"""
Diagnostic script: identify trade-count source from each backtest zip,
count raw entry signals from raw feather data (independent of sizing/slots),
and find balance-insufficiency rejections by replaying wallet state.
"""
import json
import zipfile
import glob
from pathlib import Path
import pandas as pd
import pandas_ta as ta

def load_trades_from_zip(zpath):
    with zipfile.ZipFile(zpath, 'r') as z:
        for name in z.namelist():
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    strat_key = list(data.get('strategy', {}).keys())[0]
                    return strat_key, pd.DataFrame(data['strategy'][strat_key]['trades'])
    return None, pd.DataFrame()

# ── 1. Identify the fixed-stake 2021-2026 baseline (BreakoutV1_stop30) ─────────
print("=== ALL BACKTEST FILES ===")
results_dir = Path('/freqtrade/user_data/v2_root/user_data/backtest_results')
zips = sorted(glob.glob(str(results_dir / '*.zip')), key=lambda x: Path(x).stat().st_mtime)
for zp in zips:
    strat_key, tdf = load_trades_from_zip(zp)
    if not tdf.empty:
        tdf['open_date'] = pd.to_datetime(tdf['open_date'], utc=True)
        # filter to 2021-2026 range
        mask = (tdf['open_date'] >= '2021-01-01') & (tdf['open_date'] < '2026-09-14')
        filtered = tdf[mask]
        stake_std = filtered['stake_amount'].std() if 'stake_amount' in filtered.columns else 0
        mean_stake = filtered['stake_amount'].mean() if 'stake_amount' in filtered.columns else 0
        print(f"  {Path(zp).name}: strategy={strat_key}, trades={len(filtered)}, mean_stake={mean_stake:.1f}, stake_std={stake_std:.2f}")

# ── 2. Identify the fixed-stake baseline zip specifically ───────────────────────
# BreakoutV1_stop30 2021-2026 without protections = the run before RSI run
# That should be 06-41-34 (the out-of-sample was 06-04-57 to 06-28-22)
# The 06-41-34 run was BreakoutV1_stop30 from the original 2021-2026 run
FIXED_STAKE_ZIP = str(results_dir / 'backtest-result-2026-09-17_06-41-34.zip')
DYNAMIC_ZIP = str(results_dir / 'backtest-result-2026-09-17_11-07-45.zip')

print(f"\n=== FIXED-STAKE BASELINE ===")
strat_key_fixed, fixed_df = load_trades_from_zip(FIXED_STAKE_ZIP)
fixed_df['open_date'] = pd.to_datetime(fixed_df['open_date'], utc=True)
print(f"  Strategy: {strat_key_fixed}, Total trades: {len(fixed_df)}")
print(f"  Stake distribution: min={fixed_df['stake_amount'].min():.1f}, max={fixed_df['stake_amount'].max():.1f}, std={fixed_df['stake_amount'].std():.2f}")

print(f"\n=== DYNAMIC SIZING RUN ===")
strat_key_dyn, dyn_df = load_trades_from_zip(DYNAMIC_ZIP)
dyn_df['open_date'] = pd.to_datetime(dyn_df['open_date'], utc=True)
print(f"  Strategy: {strat_key_dyn}, Total trades: {len(dyn_df)}")
print(f"  Stake distribution: min={dyn_df['stake_amount'].min():.1f}, max={dyn_df['stake_amount'].max():.1f}, std={dyn_df['stake_amount'].std():.2f}")

# ── 3. Count raw entry signals (independent of sizing/slots) ────────────────────
print(f"\n=== RAW ENTRY SIGNAL COUNT (independent of sizing/slots) ===")
data_dir = Path('/freqtrade/user_data/v2_root/user_data/data/binance')
pairs = ['BTC_USDT', 'ETH_USDT']

total_signals = 0
for pf in pairs:
    pr = pf.replace('_', '/')
    feather_path = data_dir / f"{pf}-4h.feather"
    df = pd.read_feather(feather_path)
    df['date'] = pd.to_datetime(df['date'], utc=True)
    
    # Startup candles: 250 candles before 2021-01-01
    # Filter to test range only
    mask = (df['date'] >= '2021-01-01') & (df['date'] < '2026-09-14')
    df_full = df.copy()  # keep full for warmup
    
    df_full['donchian_upper_20'] = df_full['high'].shift(1).rolling(20).max()
    df_full['atr'] = ta.atr(df_full['high'], df_full['low'], df_full['close'], length=14)
    df_full['volume_avg_20'] = df_full['volume'].rolling(20).mean()
    
    # Load daily EMA200 via 1d feather
    df_1d = pd.read_feather(data_dir / f"{pf}-1d.feather")
    df_1d['date'] = pd.to_datetime(df_1d['date'], utc=True)
    df_1d['ema200'] = ta.ema(df_1d['close'], length=200)
    df_1d_map = df_1d.set_index('date')['ema200']
    
    # Forward-fill daily EMA200 into 4h candles (same as @informative)
    df_full['ema200_1d'] = df_full['date'].map(
        lambda d: df_1d_map.asof(d)
    )
    
    df_test = df_full[mask].copy()
    
    cond = (
        (df_test['close'] > df_test['donchian_upper_20']) &
        (df_test['close'] > df_test['donchian_upper_20'] + 0.5 * df_test['atr']) &
        (df_test['volume'] > df_test['volume_avg_20']) &
        (df_test['close'] > df_test['ema200_1d']) &
        (df_test['volume'] > 0)
    )
    n_signals = cond.sum()
    total_signals += n_signals
    print(f"  {pr}: raw entry signals = {n_signals}")

print(f"  Total raw signals (both pairs): {total_signals}")

# ── 4. Replay wallet to find balance-insufficiency moments ──────────────────────
print(f"\n=== WALLET REPLAY: balance-insufficient moments for dynamic run ===")
print(f"(Identifies candles where a signal fired but calculated stake > available balance)")

# Rebuild the wallet timeline from dynamic run
dyn_df['close_date'] = pd.to_datetime(dyn_df['close_date'], utc=True)

# Build a list of (time, +/- stake_amount) events to track running balance
STARTING_BALANCE = 1000.0
events = []
for _, row in dyn_df.iterrows():
    events.append((row['open_date'], -row['stake_amount']))   # balance consumed at entry
    profit = row['stake_amount'] * row['profit_ratio']
    events.append((row['close_date'], row['stake_amount'] + profit))  # returned at exit

events.sort(key=lambda x: x[0])
balance = STARTING_BALANCE
balance_at = {}
for dt, delta in events:
    balance += delta
    balance_at[dt] = balance

# Now check: for each candle in the dynamic run where a signal fired but no trade opened,
# was the balance insufficient?
# Get all signal candles
for pf in pairs:
    pr = pf.replace('_', '/')
    feather_path = data_dir / f"{pf}-4h.feather"
    df = pd.read_feather(feather_path)
    df['date'] = pd.to_datetime(df['date'], utc=True)
    df_full = df.copy()
    df_full['donchian_upper_20'] = df_full['high'].shift(1).rolling(20).max()
    df_full['atr'] = ta.atr(df_full['high'], df_full['low'], df_full['close'], length=14)
    df_full['volume_avg_20'] = df_full['volume'].rolling(20).mean()
    
    df_1d = pd.read_feather(data_dir / f"{pf}-1d.feather")
    df_1d['date'] = pd.to_datetime(df_1d['date'], utc=True)
    df_1d['ema200'] = ta.ema(df_1d['close'], length=200)
    df_1d_map = df_1d.set_index('date')['ema200']
    df_full['ema200_1d'] = df_full['date'].map(lambda d: df_1d_map.asof(d))
    
    mask = (df_full['date'] >= '2021-01-01') & (df_full['date'] < '2026-09-14')
    df_test = df_full[mask].copy()
    
    cond = (
        (df_test['close'] > df_test['donchian_upper_20']) &
        (df_test['close'] > df_test['donchian_upper_20'] + 0.5 * df_test['atr']) &
        (df_test['volume'] > df_test['volume_avg_20']) &
        (df_test['close'] > df_test['ema200_1d']) &
        (df_test['volume'] > 0)
    )
    signal_candles = df_test[cond].copy()
    
    # For each signal candle, check if a trade actually opened in dyn_df
    dyn_pair = dyn_df[dyn_df['pair'] == pr].copy()
    traded_dates = set(dyn_pair['open_date'].astype(str))
    
    skipped = signal_candles[~signal_candles['date'].astype(str).isin(traded_dates)]
    print(f"\n  {pr}: {len(signal_candles)} total signals, {len(dyn_pair)} traded, {len(skipped)} skipped")
    
    if not skipped.empty and not skipped['atr'].isna().all():
        print(f"  Sample skipped entries (first 5):")
        print(f"  {'Date':<35} {'Calc Stake':<15} {'~Balance':<15} {'Open Trades'}")
        for i, (_, row) in enumerate(skipped.head(5).iterrows()):
            if pd.isna(row['atr']): continue
            calc_stake = (1000 * 0.01) / (3.0 * row['atr'] / row['close'])
            # approximate available balance (rough reconstruction)
            approx_bal = STARTING_BALANCE  # simplified
            open_trades = len(dyn_pair[(dyn_pair['open_date'] <= row['date']) & (dyn_pair['close_date'] > row['date'])])
            print(f"  {str(row['date']):<35} {calc_stake:<15.2f} {'(see note)':<15} {open_trades} trades open")
