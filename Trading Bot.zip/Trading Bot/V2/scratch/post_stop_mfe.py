import json
import zipfile
import glob
from pathlib import Path
import pandas as pd
import numpy as np

def main():
    # Inside docker: /freqtrade/user_data/v2_root
    results_dir = Path('user_data/backtest_results')
    data_dir = Path('user_data/data/binance')
    
    zips = glob.glob(str(results_dir / '*.zip'))
    if not zips:
        print('No zip found')
        return
    latest_zip = max(zips, key=lambda x: Path(x).stat().st_mtime)

    with zipfile.ZipFile(latest_zip, 'r') as z:
        names = z.namelist()
        for name in names:
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    break

    trades = data['strategy']['BreakoutV1']['trades']
    
    # Load OHLCV data
    dfs = {}
    for pair in ['BTC/USDT', 'ETH/USDT']:
        file_pair = pair.replace('/', '_')
        feather_path = data_dir / f"{file_pair}-4h.feather"
        df = pd.read_feather(feather_path)
        # Freqtrade feather format typically has a 'date' column
        df['date'] = pd.to_datetime(df['date'], utc=True)
        # Ensure sorted
        df = df.sort_values('date').reset_index(drop=True)
        dfs[pair] = df

    stopped_trades = [t for t in trades if t['exit_reason'] == 'trailing_stop_loss']
    print(f"Total trades: {len(trades)}")
    print(f"Trailing stop-loss exits: {len(stopped_trades)}")
    
    mfe_pcts = []
    recovered_losers = 0
    total_losers = 0
    
    for t in stopped_trades:
        pair = t['pair']
        df = dfs[pair]
        
        close_date = pd.to_datetime(t['close_date'], utc=True)
        close_rate = t['close_rate']
        open_rate = t['open_rate']
        
        # Get the next 10 candles strictly starting AFTER the trade's close_date
        # (Freqtrade backtest intraday exits might happen mid-candle, so we look at candles whose open time is >= close_date
        # or we just look at the 10 candles following the close_date)
        sub_df = df[df['date'] > close_date].head(10)
        
        if len(sub_df) == 0:
            continue
            
        post_max = sub_df['high'].max()
        mfe_pct = (post_max - close_rate) / close_rate
        mfe_pcts.append(mfe_pct)
        
        # Check if it was a loser, and if it could have recovered
        # Assuming fees are 0.1% each way, break-even is roughly open_rate * 1.002
        is_loser = t['profit_ratio'] < 0
        if is_loser:
            total_losers += 1
            if post_max > open_rate * 1.002:
                recovered_losers += 1

    mfe_series = pd.Series(mfe_pcts) * 100 # to percentage
    
    print("\n--- Post-Stop 10-Candle MFE Distribution ---")
    print(f"Count analyzed:    {len(mfe_series)}")
    print(f"Mean max bounce:   {mfe_series.mean():.2f}% above stop price")
    print(f"Median bounce:     {mfe_series.median():.2f}%")
    print(f"Max bounce seen:   {mfe_series.max():.2f}%")
    print(f"75th percentile:   {mfe_series.quantile(0.75):.2f}%")
    print(f"90th percentile:   {mfe_series.quantile(0.90):.2f}%")
    
    print("\n--- Recovery Potential ---")
    print(f"Trades that closed as a loss: {total_losers}")
    print(f"Of those losers, how many reached breakeven/profit within 10 candles after stop? {recovered_losers}")
    if total_losers > 0:
        print(f"Recovery percentage: {recovered_losers / total_losers * 100:.1f}%")
        
    # Also answer the "1.5x wider" question conceptually:
    # A wider stop would have given the trade room to hit this post-max. 
    # If 10-candle bounce routinely exceeds the ATR stop distance, the stop was too tight.

if __name__ == "__main__":
    main()
