import json
import zipfile
import glob
from pathlib import Path
import pandas as pd

def main():
    results_dir = Path('user_data/backtest_results')
    
    zips = glob.glob(str(results_dir / '*.zip'))
    if not zips:
        print('No zip found')
        return
    latest_zip = max(zips, key=lambda x: Path(x).stat().st_mtime)

    with zipfile.ZipFile(latest_zip, 'r') as z:
        names = z.namelist()
        for name in names:
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    break

    strat_name = 'RSIMeanReversion'
    strat_data = data.get('strategy', {}).get(strat_name)
    trades = strat_data.get('trades', [])
    
    df = pd.DataFrame(trades)
    df['open_date'] = pd.to_datetime(df['open_date'])
    df['close_date'] = pd.to_datetime(df['close_date'])
    df['profit_pct'] = df['profit_ratio'] * 100
    
    with open('/freqtrade/user_data/v2_root/rsi_mean_reversion_trades.md', 'w') as f:
        f.write("# RSIMeanReversion Full Trade List (2021-2026)\n\n")
        f.write("| Rank | Entry Date | Exit Date | Pair | Profit % | Profit USDT |\n")
        f.write("|---|---|---|---|---|---|\n")
        rank = 1
        for _, row in df.iterrows():
            f.write(f"| {rank} | {str(row['open_date'])} | {str(row['close_date'])} | {row['pair']} | {row['profit_pct']:.2f}% | {row['profit_abs']:.3f} |\n")
            rank += 1
            
    print(f"Trade list written to rsi_mean_reversion_trades.md. Extracted from {latest_zip}.")

if __name__ == "__main__":
    main()
