"""
Diagnostic: verify overlap between fixed-stake and dynamic-stake runs,
trade duration equality, and slot-occupancy for skipped entries.
"""
import json
import zipfile
from pathlib import Path
import pandas as pd

def load_trades(zpath, strategy_name=None):
    with zipfile.ZipFile(zpath, 'r') as z:
        for name in z.namelist():
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    strats = data.get('strategy', {})
                    key = strategy_name if strategy_name else list(strats.keys())[0]
                    return key, pd.DataFrame(strats[key]['trades'])
    return None, pd.DataFrame()

RESULTS_DIR = Path('/freqtrade/user_data/v2_root/user_data/backtest_results')

# Fixed-stake 3.0x run: 06-28-22.zip (BreakoutV1_stop30, 196 trades)
FIXED_ZIP  = str(RESULTS_DIR / 'backtest-result-2026-09-17_06-28-22.zip')
# Dynamic-sizing run: 11-07-45.zip (BreakoutV1, 102 trades)
DYN_ZIP    = str(RESULTS_DIR / 'backtest-result-2026-09-17_11-07-45.zip')

_, fixed_df = load_trades(FIXED_ZIP)
_, dyn_df   = load_trades(DYN_ZIP)

for df in [fixed_df, dyn_df]:
    df['open_date']  = pd.to_datetime(df['open_date'],  utc=True)
    df['close_date'] = pd.to_datetime(df['close_date'], utc=True)
    df['profit_pct'] = df['profit_ratio'] * 100
    df['key'] = df['pair'] + '|' + df['open_date'].astype(str)

print(f"Data source: {FIXED_ZIP.split('/')[-1]} and {DYN_ZIP.split('/')[-1]}")
print(f"Fixed-stake trades:   {len(fixed_df)}")
print(f"Dynamic-stake trades: {len(dyn_df)}")

# ── 1. Overlap: trades in BOTH runs (matched by pair + open_date) ────────────
fixed_keys = set(fixed_df['key'])
dyn_keys   = set(dyn_df['key'])

common_keys      = fixed_keys & dyn_keys
only_in_fixed    = fixed_keys - dyn_keys
only_in_dynamic  = dyn_keys   - fixed_keys

print(f"\n=== OVERLAP ANALYSIS ===")
print(f"Trades in BOTH runs:          {len(common_keys)}")
print(f"Only in fixed-stake run:      {len(only_in_fixed)}")
print(f"Only in dynamic-stake run:    {len(only_in_dynamic)}")

# ── 2. For shared trades: are exit dates identical? ──────────────────────────
print(f"\n=== EXIT DATE EQUALITY FOR {len(common_keys)} SHARED TRADES ===")
fixed_common = fixed_df[fixed_df['key'].isin(common_keys)].set_index('key')
dyn_common   = dyn_df[dyn_df['key'].isin(common_keys)].set_index('key')

mismatches = []
for k in common_keys:
    f_close = fixed_common.loc[k, 'close_date']
    d_close = dyn_common.loc[k, 'close_date']
    f_dur   = fixed_common.loc[k, 'trade_duration']
    d_dur   = dyn_common.loc[k, 'trade_duration']
    if f_close != d_close or f_dur != d_dur:
        mismatches.append({
            'key': k,
            'fixed_close': f_close,
            'dyn_close':   d_close,
            'fixed_dur':   f_dur,
            'dyn_dur':     d_dur,
        })

if mismatches:
    print(f"  MISMATCHES FOUND: {len(mismatches)}")
    for m in mismatches[:10]:
        print(f"  {m['key']}: fixed_close={m['fixed_close']} vs dyn_close={m['dyn_close']}")
else:
    print(f"  ALL {len(common_keys)} shared trades have IDENTICAL close dates and durations.")
    print(f"  Conclusion: stake size does NOT affect exit timing.")

# ── 3. For 10 trades skipped in dynamic run: what occupied the slot? ─────────
print(f"\n=== SLOT OCCUPANCY FOR 10 SKIPPED ENTRIES (in fixed, not in dynamic) ===")

skipped_sample = list(only_in_fixed)[:10]

for sk_key in skipped_sample:
    row = fixed_df[fixed_df['key'] == sk_key].iloc[0]
    sk_pair    = row['pair']
    sk_open    = row['open_date']
    sk_close   = row['close_date']
    sk_profit  = row['profit_pct']

    # Find which trades in DYN run overlapped with this entry moment
    # A slot is "occupied" if: dyn_trade.open_date <= sk_open < dyn_trade.close_date
    overlapping = dyn_df[
        (dyn_df['open_date'] <= sk_open) &
        (dyn_df['close_date'] >  sk_open)
    ]

    print(f"\n  Skipped: {sk_pair} entry={sk_open.strftime('%Y-%m-%d %H:%M')} "
          f"exit={sk_close.strftime('%Y-%m-%d %H:%M')} profit={sk_profit:.2f}%")
    if overlapping.empty:
        print(f"    -> No occupying trades found at this timestamp.")
    else:
        for _, ov in overlapping.iterrows():
            print(f"    -> Slot occupied by: {ov['pair']} "
                  f"entered={ov['open_date'].strftime('%Y-%m-%d %H:%M')} "
                  f"exited={ov['close_date'].strftime('%Y-%m-%d %H:%M')} "
                  f"stake={ov['stake_amount']:.1f} USDT")
        n_open = len(overlapping)
        print(f"    -> Open slots occupied: {n_open}/2 "
              f"({'FULL — slot contention' if n_open >= 2 else 'partial — other mechanism'})")

# ── 4. Summary: duration equality confirmed + gap explanation ────────────────
print(f"\n=== SUMMARY ===")
# Check average trade duration in each run
fixed_df['dur_hours'] = fixed_df['trade_duration'] / 60
dyn_df['dur_hours']   = dyn_df['trade_duration'] / 60

print(f"Fixed-stake avg trade duration:   {fixed_df['dur_hours'].mean():.1f} hours")
print(f"Dynamic-stake avg trade duration: {dyn_df['dur_hours'].mean():.1f} hours")
print(f"Shared trades duration identical: {'YES' if not mismatches else 'NO'}")

# Categorise skipped trades by slot occupancy
print(f"\nClassifying all {len(only_in_fixed)} skipped entries by slot occupancy at moment of signal:")
full_both  = 0
one_open   = 0
none_open  = 0
for sk_key in only_in_fixed:
    row = fixed_df[fixed_df['key'] == sk_key].iloc[0]
    sk_open = row['open_date']
    overlapping = dyn_df[
        (dyn_df['open_date'] <= sk_open) &
        (dyn_df['close_date'] >  sk_open)
    ]
    n = len(overlapping)
    if n >= 2:   full_both += 1
    elif n == 1: one_open  += 1
    else:        none_open += 1

print(f"  Both slots full (2/2 occupied):  {full_both} skipped entries")
print(f"  One slot open  (1/2 occupied):   {one_open}  skipped entries")
print(f"  No slots open  (0/2 occupied):   {none_open} skipped entries")
print(f"\nIf none_open > 0, there is an additional mechanism beyond slot contention.")
