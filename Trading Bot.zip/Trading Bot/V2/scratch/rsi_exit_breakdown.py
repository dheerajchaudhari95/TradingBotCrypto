import json
import zipfile
import glob
from pathlib import Path
import pandas as pd

def main():
    results_dir = Path('user_data/backtest_results')
    
    zips = glob.glob(str(results_dir / '*.zip'))
    if not zips:
        print('No zip found')
        return
    latest_zip = max(zips, key=lambda x: Path(x).stat().st_mtime)

    with zipfile.ZipFile(latest_zip, 'r') as z:
        names = z.namelist()
        for name in names:
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    break

    strat_name = 'RSIMeanReversion'
    strat_data = data.get('strategy', {}).get(strat_name)
    trades = strat_data.get('trades', [])
    
    df = pd.DataFrame(trades)
    
    if df.empty:
        print("No trades found.")
        return

    df['profit_pct'] = df['profit_ratio'] * 100
    df['is_win'] = df['profit_ratio'] > 0
    
    breakdown = df.groupby('exit_reason').agg(
        count=('exit_reason', 'size'),
        avg_profit_pct=('profit_pct', 'mean'),
        wins=('is_win', 'sum')
    )
    
    breakdown['win_rate'] = (breakdown['wins'] / breakdown['count']) * 100
    
    print(f"Data Source: {latest_zip}")
    print("\nExit Reason Breakdown:")
    print(breakdown[['count', 'avg_profit_pct', 'win_rate']].to_string())

if __name__ == "__main__":
    main()
