"""
Updated mechanism check: for skipped trades with 0 total slots occupied,
check if the SAME PAIR already had an open trade in the dynamic run.
This is the per-pair position lock (Freqtrade won't open a second
position in the same pair unless position_adjustment_enable=True).
Also checks the 13 trades that are only in the dynamic run.
"""
import json
import zipfile
from pathlib import Path
import pandas as pd

def load_trades(zpath):
    with zipfile.ZipFile(zpath, 'r') as z:
        for name in z.namelist():
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    key = list(data.get('strategy', {}).keys())[0]
                    return pd.DataFrame(data['strategy'][key]['trades'])
    return pd.DataFrame()

RESULTS_DIR = Path('/freqtrade/user_data/v2_root/user_data/backtest_results')
FIXED_ZIP = str(RESULTS_DIR / 'backtest-result-2026-09-17_06-28-22.zip')
DYN_ZIP   = str(RESULTS_DIR / 'backtest-result-2026-09-17_11-07-45.zip')

fixed_df = load_trades(FIXED_ZIP)
dyn_df   = load_trades(DYN_ZIP)

for df in [fixed_df, dyn_df]:
    df['open_date']  = pd.to_datetime(df['open_date'],  utc=True)
    df['close_date'] = pd.to_datetime(df['close_date'], utc=True)
    df['key'] = df['pair'] + '|' + df['open_date'].astype(str)

common_keys   = set(fixed_df['key']) & set(dyn_df['key'])
only_in_fixed = set(fixed_df['key']) - set(dyn_df['key'])
only_in_dyn   = set(dyn_df['key'])  - set(fixed_df['key'])

print(f"Source: {FIXED_ZIP.split('/')[-1]} vs {DYN_ZIP.split('/')[-1]}")
print(f"Shared: {len(common_keys)} | Only-fixed: {len(only_in_fixed)} | Only-dynamic: {len(only_in_dyn)}")

# ── PRIMARY QUESTION: for the 107 skipped, classify by SAME-PAIR lock ───────
print(f"\n=== RECLASSIFY 107 SKIPS: per-pair lock vs slot contention ===")
print(f"(Freqtrade refuses a second position on the same pair without position_adjustment_enable)")

same_pair_lock  = 0
both_slots_full = 0
one_slot_open   = 0
none_open       = 0  # residual unexplained

detail_none_open = []
for sk_key in only_in_fixed:
    row = fixed_df[fixed_df['key'] == sk_key].iloc[0]
    sk_pair  = row['pair']
    sk_open  = row['open_date']

    # All dyn trades open at this moment (any pair)
    overlapping_any = dyn_df[
        (dyn_df['open_date'] <= sk_open) &
        (dyn_df['close_date'] >  sk_open)
    ]
    # Same-pair trade open in dyn at this moment
    overlapping_same = overlapping_any[overlapping_any['pair'] == sk_pair]

    n_any  = len(overlapping_any)
    n_same = len(overlapping_same)

    if n_same > 0:
        same_pair_lock  += 1
    elif n_any >= 2:
        both_slots_full += 1
    elif n_any == 1:
        one_slot_open   += 1
    else:
        none_open += 1
        detail_none_open.append(row)

print(f"  Same-pair lock (pair already open in dyn):  {same_pair_lock}")
print(f"  Both slots full, different pairs:            {both_slots_full}")
print(f"  One slot open, different pair:               {one_slot_open}")
print(f"  Truly unexplained (0 open trades anywhere):  {none_open}")

if none_open > 0:
    print(f"\n  Sample of {min(5, none_open)} unexplained skips (no trades open anywhere):")
    for row in list(detail_none_open)[:5]:
        print(f"    {row['pair']} entry={row['open_date'].strftime('%Y-%m-%d %H:%M')} "
              f"close={row['close_date'].strftime('%Y-%m-%d %H:%M')} "
              f"profit={row['profit_ratio']*100:.2f}%")

# ── WHY 13 TRADES ONLY IN DYNAMIC? ──────────────────────────────────────────
print(f"\n=== 13 TRADES ONLY IN DYNAMIC RUN (not in fixed) ===")
print(f"These are entries the dynamic run took that the fixed run did NOT.")
print(f"{'Pair':<12} {'Dynamic Entry':<25} {'Dynamic Exit':<25} {'Fixed run: same pair open at that time?'}")
for dk in sorted(only_in_dyn):
    drow = dyn_df[dyn_df['key'] == dk].iloc[0]
    dk_pair = drow['pair']
    dk_open = drow['open_date']
    # Check what was open in FIXED run at this moment for the same pair
    fixed_same_open = fixed_df[
        (fixed_df['pair'] == dk_pair) &
        (fixed_df['open_date'] <= dk_open) &
        (fixed_df['close_date'] > dk_open)
    ]
    if not fixed_same_open.empty:
        blocker = fixed_same_open.iloc[0]
        status = f"YES — fixed had {dk_pair} open from {blocker['open_date'].strftime('%m-%d %H:%M')} to {blocker['close_date'].strftime('%m-%d %H:%M')}"
    else:
        fixed_any_open = fixed_df[
            (fixed_df['open_date'] <= dk_open) &
            (fixed_df['close_date'] > dk_open)
        ]
        n = len(fixed_any_open)
        status = f"No same-pair. Fixed had {n} total slots open."
    print(f"  {dk_pair:<12} {str(dk_open)[:19]:<25} {str(drow['close_date'])[:19]:<25} {status}")

# ── DETAILED SLOT OCCUPANCY FOR 10 SKIPS WITH SAME-PAIR LOCK ───────────────
print(f"\n=== DETAILED VIEW: 5 SAME-PAIR-LOCK SKIPS ===")
count = 0
for sk_key in only_in_fixed:
    if count >= 5: break
    row = fixed_df[fixed_df['key'] == sk_key].iloc[0]
    sk_pair = row['pair']
    sk_open = row['open_date']

    overlapping_same = dyn_df[
        (dyn_df['pair'] == sk_pair) &
        (dyn_df['open_date'] <= sk_open) &
        (dyn_df['close_date'] > sk_open)
    ]
    if overlapping_same.empty:
        continue

    print(f"\n  Skipped: {sk_pair} @ {sk_open.strftime('%Y-%m-%d %H:%M')} "
          f"(would exit {row['close_date'].strftime('%Y-%m-%d %H:%M')}, profit={row['profit_ratio']*100:.2f}%)")
    for _, occ in overlapping_same.iterrows():
        print(f"    Blocked by: {occ['pair']} open={occ['open_date'].strftime('%Y-%m-%d %H:%M')} "
              f"close={occ['close_date'].strftime('%Y-%m-%d %H:%M')} stake={occ['stake_amount']:.1f} USDT")
        # Was this blocker also in the fixed run?
        blocker_in_fixed = fixed_df[fixed_df['key'] == occ['key']]
        if not blocker_in_fixed.empty:
            print(f"    (This blocker IS also in the fixed run — same trade, same entry date)")
        else:
            print(f"    (This blocker is UNIQUE to the dynamic run — different entry was chosen)")
    count += 1
