import json
import zipfile
import glob
from pathlib import Path
import pandas as pd

def main():
    results_dir = Path('user_data/backtest_results')
    
    zips = glob.glob(str(results_dir / '*.zip'))
    if not zips:
        print('No zip found')
        return
    # The most recent backtest zip
    latest_zip = max(zips, key=lambda x: Path(x).stat().st_mtime)

    with zipfile.ZipFile(latest_zip, 'r') as z:
        names = z.namelist()
        for name in names:
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    break

    strat_name = 'BreakoutV1_stop30'
    strat_data = data.get('strategy', {}).get(strat_name)
    if not strat_data:
        print(f"Metrics not found for {strat_name} in {latest_zip}")
        return
        
    trades = strat_data.get('trades', [])
    if not trades:
        print("No trades found.")
        return
        
    # Build dataframe for easy analysis
    df = pd.DataFrame(trades)
    df['open_date'] = pd.to_datetime(df['open_date'])
    df['close_date'] = pd.to_datetime(df['close_date'])
    df['profit_pct'] = df['profit_ratio'] * 100
    
    # 2. Report full trade list (will print to stdout)
    print("--- Full Trade List (All 112 Trades) ---")
    print(f"{'Entry Date':<25} | {'Exit Date':<25} | {'Pair':<10} | {'Profit %':<8} | {'Profit USDT':<10}")
    print("-" * 85)
    for _, row in df.iterrows():
        print(f"{str(row['open_date']):<25} | {str(row['close_date']):<25} | {row['pair']:<10} | {row['profit_pct']:>7.2f}% | {row['profit_abs']:>9.3f}")
    
    # 3. Top 5 winning trades
    top5 = df.nlargest(5, 'profit_pct')
    print("\n--- Top 5 Largest Winning Trades ---")
    print(f"{'Rank':<4} | {'Entry Date':<25} | {'Exit Date':<25} | {'Pair':<10} | {'Profit %':<8} | {'Profit USDT':<10}")
    print("-" * 90)
    rank = 1
    for _, row in top5.iterrows():
        print(f"{rank:<4} | {str(row['open_date']):<25} | {str(row['close_date']):<25} | {row['pair']:<10} | {row['profit_pct']:>7.2f}% | {row['profit_abs']:>9.3f}")
        rank += 1
        
    # 4. Total profit contribution: Top 5 vs Rest
    total_profit_usdt = df['profit_abs'].sum()
    top5_profit_usdt = top5['profit_abs'].sum()
    rest_profit_usdt = total_profit_usdt - top5_profit_usdt
    
    start_balance = 1000
    top5_pct_of_account = (top5_profit_usdt / start_balance) * 100
    rest_pct_of_account = (rest_profit_usdt / start_balance) * 100
    total_pct_of_account = (total_profit_usdt / start_balance) * 100
    
    print("\n--- Profit Contribution (Top 5 vs Rest) ---")
    print(f"Total Profit: {total_profit_usdt:.3f} USDT ({total_pct_of_account:.2f}%)")
    print(f"Top 5 Trades Contribution: {top5_profit_usdt:.3f} USDT ({top5_pct_of_account:.2f}%)")
    print(f"Remaining 107 Trades Contribution: {rest_profit_usdt:.3f} USDT ({rest_pct_of_account:.2f}%)")

    # 5. Peak Mania Check: 2017-08-17 to 2018-02-01
    mania_start = pd.to_datetime('2017-08-17', utc=True)
    mania_end = pd.to_datetime('2018-02-01', utc=True)
    
    mania_trades = df[(df['open_date'] >= mania_start) & (df['open_date'] < mania_end)]
    post_mania_trades = df[df['open_date'] >= mania_end]
    
    mania_profit_usdt = mania_trades['profit_abs'].sum()
    post_mania_profit_usdt = post_mania_trades['profit_abs'].sum()
    
    mania_pct_of_account = (mania_profit_usdt / start_balance) * 100
    post_mania_pct_of_account = (post_mania_profit_usdt / start_balance) * 100
    
    print("\n--- Period Contribution: Peak Mania vs Post-Mania ---")
    print(f"Period 1: Peak Mania (2017-08-17 to 2018-02-01)")
    print(f"  Number of trades: {len(mania_trades)}")
    print(f"  Profit Contribution: {mania_profit_usdt:.3f} USDT ({mania_pct_of_account:.2f}%)")
    print(f"\nPeriod 2: Post-Mania (2018-02-01 to 2021-01-01)")
    print(f"  Number of trades: {len(post_mania_trades)}")
    print(f"  Profit Contribution: {post_mania_profit_usdt:.3f} USDT ({post_mania_pct_of_account:.2f}%)")

if __name__ == "__main__":
    main()
