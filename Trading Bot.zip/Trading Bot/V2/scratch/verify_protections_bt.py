import json
import zipfile
import glob
from pathlib import Path
import pandas as pd

def main():
    results_dir = Path('/freqtrade/user_data/v2_root/user_data/backtest_results')
    zips = sorted(glob.glob(str(results_dir / '*.zip')), key=lambda x: Path(x).stat().st_mtime)
    latest_zip = zips[-1]
    prior_zip = zips[-2] if len(zips) >= 2 else None

    print(f"New backtest file: {latest_zip}")

    def load_trades(zpath):
        with zipfile.ZipFile(zpath, 'r') as z:
            for name in z.namelist():
                if name.endswith('.json') and 'meta' not in name:
                    with z.open(name) as f:
                        data = json.load(f)
                        strat_key = list(data.get('strategy', {}).keys())[0]
                        return pd.DataFrame(data['strategy'][strat_key]['trades'])
        return pd.DataFrame()

    new_df = load_trades(latest_zip)
    new_df['open_date'] = pd.to_datetime(new_df['open_date'], utc=True)
    new_df['close_date'] = pd.to_datetime(new_df['close_date'], utc=True)
    new_df['profit_pct'] = new_df['profit_ratio'] * 100

    # --- 1. Stake amounts: first 5 and last 5 trades
    print("\n=== VERIFICATION 1: Actual Stake Amounts (first 10 trades) ===")
    print(f"{'#':<4} {'Open Date':<30} {'Pair':<12} {'Stake (USDT)':<15} {'Profit %'}")
    for i, (_, row) in enumerate(new_df.head(10).iterrows()):
        print(f"{i+1:<4} {str(row['open_date']):<30} {row['pair']:<12} {row['stake_amount']:<15.3f} {row['profit_pct']:.2f}%")

    min_stake = new_df['stake_amount'].min()
    max_stake = new_df['stake_amount'].max()
    mean_stake = new_df['stake_amount'].mean()
    std_stake = new_df['stake_amount'].std()
    print(f"\nStake distribution across {len(new_df)} trades:")
    print(f"  Min: {min_stake:.3f} USDT  |  Max: {max_stake:.3f} USDT  |  Mean: {mean_stake:.3f} USDT  |  StdDev: {std_stake:.3f}")
    print(f"  Dynamic sizing confirmed: {'YES' if std_stake > 0.5 else 'NO - likely fixed fallback'}")

    # --- 2. Compare entry dates with prior run
    if prior_zip:
        print(f"\n=== VERIFICATION 2: Entry Date Comparison vs. Prior Run ({Path(prior_zip).name}) ===")
        old_df = load_trades(prior_zip)
        old_df['open_date'] = pd.to_datetime(old_df['open_date'], utc=True)

        new_dates = set(new_df['open_date'].astype(str) + '|' + new_df['pair'])
        old_dates = set(old_df['open_date'].astype(str) + '|' + old_df['pair'])

        in_new_not_old = new_dates - old_dates
        in_old_not_new = old_dates - new_dates

        print(f"  Trades in NEW but not OLD: {len(in_new_not_old)}")
        for x in sorted(in_new_not_old)[:10]:
            print(f"    + {x}")

        print(f"  Trades in OLD but not NEW: {len(in_old_not_new)}")
        for x in sorted(in_old_not_new)[:10]:
            print(f"    - {x}")

        if not in_new_not_old and not in_old_not_new:
            print("  MATCH: Entry dates and pairs are identical to prior run.")
        else:
            print("  MISMATCH detected — some entries differ (see above).")

    # --- 3. Rejected signals count (protections triggered)
    print(f"\n=== VERIFICATION 3: Trade Count Difference (proxy for protection triggers) ===")
    if prior_zip:
        old_df = load_trades(prior_zip)
        print(f"  Prior run (no protections): {len(old_df)} trades")
        print(f"  This run (with protections): {len(new_df)} trades")
        print(f"  Difference: {len(old_df) - len(new_df)} trades suppressed by protections")

if __name__ == "__main__":
    main()
