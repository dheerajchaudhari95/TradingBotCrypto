import json
import zipfile
import glob
from pathlib import Path
import pandas as pd
import pandas_ta as ta

def main():
    data_dir = Path('/freqtrade/user_data/v2_root/user_data/data/binance')
    pairs = ['BTC_USDT', 'ETH_USDT']
    
    dfs = {}
    for pair_filename in pairs:
        pair_real = pair_filename.replace('_', '/')
        feather_path = data_dir / f"{pair_filename}-4h.feather"
        df = pd.read_feather(feather_path)
        
        df['rsi'] = ta.rsi(df['close'], length=14)
        df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=14)
        
        df['date'] = pd.to_datetime(df['date'], utc=True)
        dfs[pair_real] = df.set_index('date')

    results_dir = Path('/freqtrade/user_data/v2_root/user_data/backtest_results')
    zips = glob.glob(str(results_dir / '*.zip'))
    latest_zip = max(zips, key=lambda x: Path(x).stat().st_mtime)

    with zipfile.ZipFile(latest_zip, 'r') as z:
        for name in z.namelist():
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    break

    strat_name = 'RSIMeanReversion'
    trades = data.get('strategy', {}).get(strat_name).get('trades', [])
    trade_df = pd.DataFrame(trades)
    trade_df['open_date'] = pd.to_datetime(trade_df['open_date'], utc=True)
    
    results = {
        2.0: {'survived_total': 0, 'survived_to_60': 0, 'profit_sum_60': 0.0, 'profit_sum_all': 0.0},
        2.5: {'survived_total': 0, 'survived_to_60': 0, 'profit_sum_60': 0.0, 'profit_sum_all': 0.0},
        3.0: {'survived_total': 0, 'survived_to_60': 0, 'profit_sum_60': 0.0, 'profit_sum_all': 0.0}
    }
    
    for idx, row in trade_df.iterrows():
        pair = row['pair']
        open_dt = row['open_date']
        open_rate = row['open_rate']
        
        df = dfs[pair]
        
        signal_dt = open_dt - pd.Timedelta(hours=4)
        if signal_dt not in df.index:
            continue
        
        atr_val = df.loc[signal_dt, 'atr']
        if pd.isna(atr_val) or atr_val <= 0:
            continue
            
        end_dt = open_dt + pd.Timedelta(hours=4*19) # 20 candles inclusive
        window = df.loc[open_dt:end_dt]
        
        if window.empty:
            continue
            
        rsi_hit_idx = None
        profit_at_60 = 0.0
        
        for cur_dt, candle in window.iterrows():
            if candle['rsi'] >= 60:
                rsi_hit_idx = cur_dt
                profit_at_60 = (candle['close'] / open_rate - 1) * 100
                break
                
        if rsi_hit_idx is not None:
            eval_window = window.loc[:rsi_hit_idx]
        else:
            eval_window = window
            
        lowest_low = eval_window['low'].min()
        adverse_move_abs = open_rate - lowest_low
        adverse_move_atr = adverse_move_abs / atr_val
        
        profit_at_end = (window.iloc[-1]['close'] / open_rate - 1) * 100
        
        for stop_mult in [2.0, 2.5, 3.0]:
            if adverse_move_atr < stop_mult:
                results[stop_mult]['survived_total'] += 1
                if rsi_hit_idx is not None:
                    results[stop_mult]['survived_to_60'] += 1
                    results[stop_mult]['profit_sum_60'] += profit_at_60
                    results[stop_mult]['profit_sum_all'] += profit_at_60
                else:
                    results[stop_mult]['profit_sum_all'] += profit_at_end

    print(f"Data Source: Trades from {latest_zip}, price/ATR from binance 4h feather files")
    print(f"Methodology: Checked up to 20 candles forward from exact entry timestamp.")
    print(f"Lowest low before RSI>=60 (or over full 20 candles) was used to measure MAE.")
    print(f"Original trade count: 126\n")
    print(f"{'Stop Width':<12} | {'Surv to RSI-60':<15} | {'Avg Profit % (RSI-60 only)':<28} | {'Total Survived (Any)':<22} | {'Avg Profit % (All Survivors)':<28}")
    print("-" * 115)
    for stop_mult in [2.0, 2.5, 3.0]:
        s60 = results[stop_mult]['survived_to_60']
        avg60 = results[stop_mult]['profit_sum_60'] / s60 if s60 > 0 else 0.0
        
        stot = results[stop_mult]['survived_total']
        avgtot = results[stop_mult]['profit_sum_all'] / stot if stot > 0 else 0.0
        
        print(f"{stop_mult:.1f}x ATR     | {s60:<15} | {avg60:>6.2f}%                       | {stot:<22} | {avgtot:>6.2f}%")

if __name__ == "__main__":
    main()
