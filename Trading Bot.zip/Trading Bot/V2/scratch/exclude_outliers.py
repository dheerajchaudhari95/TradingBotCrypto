import json
import zipfile
import glob
from pathlib import Path
import pandas as pd

def main():
    results_dir = Path('user_data/backtest_results')
    
    zips = glob.glob(str(results_dir / '*.zip'))
    if not zips:
        print('No zip found')
        return
    latest_zip = max(zips, key=lambda x: Path(x).stat().st_mtime)

    with zipfile.ZipFile(latest_zip, 'r') as z:
        names = z.namelist()
        for name in names:
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    break

    strat_name = 'BreakoutV1_stop30'
    strat_data = data.get('strategy', {}).get(strat_name)
    trades = strat_data.get('trades', [])
    
    df = pd.DataFrame(trades)
    df['open_date'] = pd.to_datetime(df['open_date'])
    df['close_date'] = pd.to_datetime(df['close_date'])
    df['profit_pct'] = df['profit_ratio'] * 100
    
    # 1. Identify the top 5
    top5 = df.nlargest(5, 'profit_pct')
    
    # Exclude top 5 based on their exact indices
    remaining_df = df.drop(top5.index)
    
    # 2. Compute metrics for remaining 107
    total_trades = len(remaining_df)
    total_profit_usdt = remaining_df['profit_abs'].sum()
    start_balance = 1000
    total_profit_pct = (total_profit_usdt / start_balance) * 100
    
    wins = len(remaining_df[remaining_df['profit_abs'] > 0])
    win_rate = (wins / total_trades) * 100 if total_trades > 0 else 0
    
    gross_profit = remaining_df[remaining_df['profit_abs'] > 0]['profit_abs'].sum()
    gross_loss = abs(remaining_df[remaining_df['profit_abs'] < 0]['profit_abs'].sum())
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
    
    # 3. Mean profit % per trade
    mean_profit_pct = remaining_df['profit_pct'].mean()
    
    print("--- METHODOLOGY DISCLOSURE ---")
    print(f"Data Source: Exact raw JSON from {latest_zip}")
    print("Script Logic:")
    print("  1. Load all trades into pandas DataFrame.")
    print("  2. Identify top 5 using df.nlargest(5, 'profit_pct').")
    print("  3. Drop these 5 indices from the DataFrame, leaving 107 trades.")
    print("  4. Calculate Total Profit %: (sum of remaining 'profit_abs' / 1000) * 100")
    print("  5. Calculate Win Rate: (wins / 107) * 100")
    print("  6. Calculate Profit Factor: sum of positive 'profit_abs' / abs(sum of negative 'profit_abs')")
    print("  7. Calculate Mean Profit %: mean of 'profit_ratio' * 100")
    
    print("\n--- RESULTS FOR REMAINING 107 TRADES ---")
    print(f"Total Trades: {total_trades}")
    print(f"Total Profit %: {total_profit_pct:.2f}% (Absolute: {total_profit_usdt:.3f} USDT)")
    print(f"Win Rate: {win_rate:.2f}%")
    print(f"Profit Factor: {profit_factor:.2f}")
    print(f"Mean Profit % per trade: {mean_profit_pct:.3f}%")

if __name__ == "__main__":
    main()
