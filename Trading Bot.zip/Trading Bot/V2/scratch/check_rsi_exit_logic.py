import json
import zipfile
import glob
from pathlib import Path
import pandas as pd
import pandas_ta as ta

def main():
    data_dir = Path('/freqtrade/user_data/v2_root/user_data/data/binance')
    pairs = ['BTC_USDT', 'ETH_USDT']
    
    dfs = {}
    total_raw_signals = 0
    
    for pair_filename in pairs:
        pair_real = pair_filename.replace('_', '/')
        feather_path = data_dir / f"{pair_filename}-4h.feather"
        if not feather_path.exists():
            print(f"File not found: {feather_path}")
            continue
            
        df = pd.read_feather(feather_path)
        # In newer pandas/freqtrade, feather might have the index or specific columns.
        # Freqtrade feather columns: date, open, high, low, close, volume
        
        # Calculate RSI before slicing to ensure proper warmup
        df['rsi'] = ta.rsi(df['close'], length=14)
        
        # Date filtering (inclusive for the range)
        df['date'] = pd.to_datetime(df['date'], utc=True)
        mask = (df['date'] >= '2021-01-01') & (df['date'] < '2026-09-14')
        df_sliced = df[mask].copy()
        
        # Raw exit signal condition
        condition = (df_sliced['rsi'] > 60) & (df_sliced['rsi'].shift(1) <= 60)
        num_signals = condition.sum()
        total_raw_signals += num_signals
        print(f"[{pair_real}] Individual 4h candles where RSI crossed above 60 (2021-2026): {num_signals}")
        
        dfs[pair_real] = df # Store unsliced DF for trade lookups (to include exact boundary conditions)

    print(f"\nTotal raw exit signals across both pairs: {total_raw_signals}\n")

    # Load trades
    results_dir = Path('/freqtrade/user_data/v2_root/user_data/backtest_results')
    zips = glob.glob(str(results_dir / '*.zip'))
    latest_zip = max(zips, key=lambda x: Path(x).stat().st_mtime)

    with zipfile.ZipFile(latest_zip, 'r') as z:
        for name in z.namelist():
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    break

    strat_name = 'RSIMeanReversion'
    trades = data.get('strategy', {}).get(strat_name).get('trades', [])
    
    if not trades:
        print("No trades found in backtest.")
        return
        
    trade_df = pd.DataFrame(trades)
    trade_df['open_date'] = pd.to_datetime(trade_df['open_date'], utc=True)
    trade_df['close_date'] = pd.to_datetime(trade_df['close_date'], utc=True)
    
    rsi_reached_60_count = 0
    total_candles = 0

    for idx, row in trade_df.iterrows():
        pair = row['pair']
        open_dt = row['open_date']
        close_dt = row['close_date']
        
        duration_candles = (close_dt - open_dt).total_seconds() / (4 * 3600)
        total_candles += duration_candles
        
        pair_df = dfs[pair]
        # Check from open_date to close_date
        trade_mask = (pair_df['date'] >= open_dt) & (pair_df['date'] <= close_dt)
        trade_window = pair_df[trade_mask]
        
        if (trade_window['rsi'] >= 60).any():
            rsi_reached_60_count += 1
            
    avg_duration = total_candles / len(trade_df)
    
    print(f"--- Trade Holding Period Analysis ---")
    print(f"Total Trades Analyzed: {len(trade_df)}")
    print(f"Average Trade Duration: {avg_duration:.2f} candles")
    print(f"Trades where RSI reached >= 60 at any point during holding: {rsi_reached_60_count} out of {len(trade_df)}")

if __name__ == "__main__":
    main()
