import json
import zipfile
import glob
from pathlib import Path
import numpy as np

def main():
    results_dir = Path('user_data/backtest_results')
    
    # We want BreakoutV1, BreakoutV1_stop25, BreakoutV1_stop30
    targets = ['BreakoutV1', 'BreakoutV1_stop25', 'BreakoutV1_stop30']
    metrics = {t: {} for t in targets}
    
    zips = glob.glob(str(results_dir / '*.zip'))
    for zip_path in zips:
        with zipfile.ZipFile(zip_path, 'r') as z:
            names = z.namelist()
            for name in names:
                if name.endswith('.json') and 'meta' not in name:
                    with z.open(name) as f:
                        data = json.load(f)
                        strat_dict = data.get('strategy', {})
                        if isinstance(strat_dict, dict):
                            for strat_name, strat_data in strat_dict.items():
                                if strat_name in targets and not metrics[strat_name]:
                                    metrics[strat_name] = strat_data
                                
    # Extract the requested fields
    for name in targets:
        d = metrics[name]
        if not d:
            print(f"Metrics not found for {name}")
            continue
            
        trades = d.get('trades', [])
        winners = [t['profit_ratio'] for t in trades if t['profit_ratio'] > 0]
        avg_win = np.mean(winners) * 100 if winners else 0
        
        profit_total_pct = d.get('profit_total_pct', 0)
        # Freqtrade displays total profit % as profit_total_abs / starting_balance.
        # But we can just use the provided summary field
        profit_total_abs = d.get('profit_total_abs', 0)
        start_balance = 1000 # Since we know the run started with 1000
        total_profit_pct = (profit_total_abs / start_balance) * 100
        
        win_rate = (len(winners) / len(trades) * 100) if trades else 0
        profit_factor = d.get('profit_factor', 0)
        max_drawdown = d.get('max_drawdown_account', 0) * 100
        sharpe = d.get('sharpe', 0)
        trade_count = len(trades)
        expectancy = d.get('expectancy_ratio', 0)
        
        print(f"--- {name} ---")
        print(f"Total Profit %  : {total_profit_pct:.2f}%")
        print(f"Win Rate        : {win_rate:.2f}%")
        print(f"Profit Factor   : {profit_factor:.2f}")
        print(f"Max Drawdown    : {max_drawdown:.2f}%")
        print(f"Sharpe          : {sharpe:.2f}")
        print(f"Trade Count     : {trade_count}")
        print(f"Expectancy Ratio: {expectancy:.2f}")
        print(f"Avg Winning Trade: {avg_win:.2f}%")
        print()

if __name__ == "__main__":
    main()
