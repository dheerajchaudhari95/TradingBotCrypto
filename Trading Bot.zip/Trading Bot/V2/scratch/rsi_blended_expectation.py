import json
import zipfile
import glob
from pathlib import Path
import pandas as pd
import pandas_ta as ta
import numpy as np

def main():
    data_dir = Path('/freqtrade/user_data/v2_root/user_data/data/binance')
    pairs = ['BTC_USDT', 'ETH_USDT']
    
    dfs = {}
    for pair_filename in pairs:
        pair_real = pair_filename.replace('_', '/')
        feather_path = data_dir / f"{pair_filename}-4h.feather"
        df = pd.read_feather(feather_path)
        df['rsi'] = ta.rsi(df['close'], length=14)
        df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=14)
        df['date'] = pd.to_datetime(df['date'], utc=True)
        dfs[pair_real] = df.set_index('date')

    results_dir = Path('/freqtrade/user_data/v2_root/user_data/backtest_results')
    zips = glob.glob(str(results_dir / '*.zip'))
    latest_zip = max(zips, key=lambda x: Path(x).stat().st_mtime)

    with zipfile.ZipFile(latest_zip, 'r') as z:
        for name in z.namelist():
            if name.endswith('.json') and 'meta' not in name:
                with z.open(name) as f:
                    data = json.load(f)
                    break

    strat_name = 'RSIMeanReversion'
    trades = data.get('strategy', {}).get(strat_name).get('trades', [])
    trade_df = pd.DataFrame(trades)
    trade_df['open_date'] = pd.to_datetime(trade_df['open_date'], utc=True)
    
    results = {
        2.0: {'rsi60': [], 'survivor_end': [], 'stopped': []},
        3.0: {'rsi60': [], 'survivor_end': [], 'stopped': []}
    }
    
    for idx, row in trade_df.iterrows():
        pair = row['pair']
        open_dt = row['open_date']
        open_rate = row['open_rate']
        
        df = dfs[pair]
        
        signal_dt = open_dt - pd.Timedelta(hours=4)
        if signal_dt not in df.index:
            continue
        atr_val = df.loc[signal_dt, 'atr']
        if pd.isna(atr_val) or atr_val <= 0:
            continue
            
        end_dt = open_dt + pd.Timedelta(hours=4*19) # 20 candles inclusive
        window = df.loc[open_dt:end_dt]
        if window.empty:
            continue
            
        for stop_mult in [2.0, 3.0]:
            stop_price = open_rate - (stop_mult * atr_val)
            
            exit_profit = None
            exit_type = None
            
            for cur_dt, candle in window.iterrows():
                # Freqtrade executes stop loss before exit signal typically if they both happen in same candle,
                # unless price opened above stop and hit RSI 60 immediately, but let's assume stop hits if low <= stop.
                if candle['low'] <= stop_price:
                    actual_exit = candle['open'] if candle['open'] < stop_price else stop_price
                    exit_profit = (actual_exit / open_rate - 1) * 100
                    exit_type = 'stopped'
                    break
                
                if candle['rsi'] >= 60:
                    exit_profit = (candle['close'] / open_rate - 1) * 100
                    exit_type = 'rsi60'
                    break
                    
            if exit_type is None:
                # Survived full 20 candles without hitting stop or RSI 60
                exit_profit = (window.iloc[-1]['close'] / open_rate - 1) * 100
                exit_type = 'survivor_end'
                
            results[stop_mult][exit_type].append(exit_profit)

    for stop_mult in [3.0, 2.0]:
        print(f"\n=======================================================")
        print(f"--- Blended Analysis for {stop_mult}x ATR Stop Width ---")
        print(f"=======================================================")
        
        rsi60_list = results[stop_mult]['rsi60']
        survivor_end_list = results[stop_mult]['survivor_end']
        stopped_list = results[stop_mult]['stopped']
        
        if stop_mult == 3.0:
            print("\n[Stopped Trades Statistics (3.0x ATR)]")
            if stopped_list:
                stopped_arr = np.array(stopped_list)
                print(f"  Count: {len(stopped_arr)}")
                print(f"  Avg Loss: {np.mean(stopped_arr):.2f}%")
                print(f"  Worst Single Loss: {np.min(stopped_arr):.2f}%")
                print(f"  Full Distribution:")
                print(f"    Min:             {np.min(stopped_arr):.2f}%")
                print(f"    25th Percentile: {np.percentile(stopped_arr, 25):.2f}%")
                print(f"    Median:          {np.median(stopped_arr):.2f}%")
                print(f"    75th Percentile: {np.percentile(stopped_arr, 75):.2f}%")
                print(f"    Max (Best Loss): {np.max(stopped_arr):.2f}%")
            else:
                print("  No stopped trades.")
                
        total_trades = len(rsi60_list) + len(survivor_end_list) + len(stopped_list)
        sum_rsi60 = sum(rsi60_list)
        sum_surv = sum(survivor_end_list)
        sum_stopped = sum(stopped_list)
        
        # Portfolio profit % assumes stake=100 on 1000 starting balance (10% allocation per trade).
        # Therefore, a 1% move on the trade is a 0.1% move on the overall portfolio.
        # Freqtrade Total Profit % is sum(profit_ratio * stake) / starting_balance.
        # sum(trade_profit_pct) * (100/1000) = sum(trade_profit_pct) / 10
        total_portfolio_profit = (sum_rsi60 + sum_surv + sum_stopped) / 10.0
        
        print("\n[Blended Portfolio-Level Arithmetic]")
        print(f"  1. Reached RSI-60:       Count = {len(rsi60_list):>3}, Avg = {np.mean(rsi60_list) if rsi60_list else 0:>6.2f}%, Trade % Sum = {sum_rsi60:>7.2f}%")
        print(f"  2. Survived 20 candles:  Count = {len(survivor_end_list):>3}, Avg = {np.mean(survivor_end_list) if survivor_end_list else 0:>6.2f}%, Trade % Sum = {sum_surv:>7.2f}%")
        print(f"  3. Stopped Out:          Count = {len(stopped_list):>3}, Avg = {np.mean(stopped_list) if stopped_list else 0:>6.2f}%, Trade % Sum = {sum_stopped:>7.2f}%")
        print(f"  -------------------------------------------------------------")
        print(f"  Blended Expected Portfolio Total Profit %: {total_portfolio_profit:.2f}% (from {total_trades} evaluated trades)")

if __name__ == "__main__":
    main()
