import pandas as pd
import pandas_ta as ta
from freqtrade.strategy import IStrategy, informative, stoploss_from_absolute
from pandas import DataFrame


class RSIMeanReversion(IStrategy):
    """
    RSIMeanReversion
    ================
    Timeframe: 4h
    Higher-TF filter: Daily EMA200 (via @informative decorator)

    ENTRY — ALL of:
      1. rsi.shift(1) < 30 (oversold on previous candle)
      2. rsi >= 30 (recovered back above 30, confirmed on close)
      3. close > daily_ema200 (broader uptrend macro filter)

    EXIT:
      rsi crosses above 60 (rsi > 60 AND rsi.shift(1) <= 60)

    STOPLOSS:
      Custom trailing: 1.5x ATR below current_rate.
      Hard floor: -10%
    """

    INTERFACE_VERSION = 3

    timeframe = "4h"
    can_short = False

    # ROI: effectively disabled — exits governed by signal or custom stop
    minimal_roi = {"0": 1.0}

    # Hard-floor stoploss; real stop is ATR-based via custom_stoploss
    stoploss = -0.10
    use_custom_stoploss = True
    trailing_stop = False

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    # Conservatively covers daily EMA200 warm-up
    startup_candle_count: int = 250

    # ── Informative: daily EMA200 ──────────────────────────────────────────────
    @informative('1d')
    def populate_indicators_1d(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Daily timeframe: compute EMA200. Merged into 4h df as 'ema200_1d'."""
        dataframe['ema200'] = ta.ema(dataframe['close'], length=200)
        return dataframe

    # ── 4H Indicators ──────────────────────────────────────────────────────────
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Compute all 4h indicators. The daily EMA200 is already merged into
        the dataframe as 'ema200_1d' by the @informative decorator.
        """
        dataframe['rsi'] = ta.rsi(dataframe['close'], length=14)

        # ATR(14) — used for custom stop
        dataframe['atr'] = ta.atr(
            dataframe['high'], dataframe['low'], dataframe['close'], length=14
        )

        return dataframe

    # ── Entry signal ───────────────────────────────────────────────────────────
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Long entry when ALL conditions are true:
        - rsi was < 30 on previous candle
        - rsi is now >= 30
        - close > daily ema200
        """
        dataframe.loc[
            (
                (dataframe['rsi'].shift(1) < 30) &
                (dataframe['rsi'] >= 30) &
                (dataframe['close'] > dataframe['ema200_1d']) &
                (dataframe['volume'] > 0)
            ),
            'enter_long'
        ] = 1
        return dataframe

    # ── Exit signal ────────────────────────────────────────────────────────────
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Exit long when RSI crosses above 60.
        """
        dataframe.loc[
            (
                (dataframe['rsi'] > 60) &
                (dataframe['rsi'].shift(1) <= 60)
            ),
            'exit_long'
        ] = 1
        return dataframe

    # ── Custom stoploss: 1.5x ATR trailing ──────────────────────────────────────
    def custom_stoploss(
        self, pair: str, trade: 'Trade', current_time: 'datetime',
        current_rate: float, current_profit: float, **kwargs
    ) -> float:
        """
        ATR-based trailing stop: stop = current_rate - 1.5 * ATR(14).
        Hard floor fallback: -10% (self.stoploss).
        """
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is not None and not dataframe.empty:
            last_candle = dataframe.iloc[-1].squeeze()
            if 'atr' in last_candle and not pd.isna(last_candle['atr']):
                atr_val = last_candle['atr']
                stop_price = current_rate - (1.5 * atr_val)
                return stoploss_from_absolute(stop_price, current_rate)
        return self.stoploss
