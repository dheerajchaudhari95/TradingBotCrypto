# V2 Archive — Retired Strategy Files

This directory contains strategy files that are **no longer active**. They are retained for reference and audit purposes only. Do not run backtests against these files as the canonical, final configuration.

---

## BreakoutV1_stop25.py — Superseded

**Status:** Superseded by `BreakoutV1.py`.

This was a test variant of the BreakoutV1 strategy using a **2.5x ATR custom stoploss** (increased from the original 2.0x). It was created specifically for the evidence-based stop-width comparison experiment (2021–2026 backtest range). The 3.0x ATR variant showed superior performance in direct comparison, so 2.5x was not carried forward.

---

## BreakoutV1_stop30.py — Superseded

**Status:** Superseded by `BreakoutV1.py`. Its **exact content** (logic, stop width, all parameters) now lives in the canonical `V2/user_data/strategies/BreakoutV1.py`, with the class name updated from `BreakoutV1_stop30` to `BreakoutV1` to match the filename.

**Why 3.0x ATR became the canonical stop:**
The original `BreakoutV1.py` used a **2.0x ATR** custom stoploss, which was the initial design choice. A rigorous MFE/MAE analysis on the 278 trailing-stop-loss exits from the 2021–2026 in-sample backtest found that:
- 75% of stopped-out trades saw only modest further adverse moves (<1.5x additional ATR) before recovering.
- A 3.0x ATR stop would have saved a meaningful proportion of trades that went on to profit, without creating catastrophic tail exposure.
- The 3.0x ATR width was selected over 2.5x based on the direct comparison backtest results.

This is an **evidence-based correction** from the original flawed 2.0x design, not an arbitrary tuning change.

---

## RSIMeanReversion.py — Retired (Evidence-Based Rejection)

**Status:** Permanently retired. Do not resurrect without a fundamentally different entry logic.

**Background:** RSIMeanReversion was tested with the same methodological rigor applied to BreakoutV1:
- Full in-sample backtest (2021–2026, BTC/USDT + ETH/USDT, 4h timeframe).
- Exit reason analysis confirming 100% of 126 trades were stopped out — the RSI-60 exit signal never fired once before the stop was hit.
- Raw signal frequency check confirming the exit condition (RSI crossing above 60) occurs ~1,004 times in the dataset, ruling out a coding bug.
- Trade holding period analysis confirming that in 121 of 126 trades (96%), the asset's RSI never reached 60 during the entire holding period; average trade duration before stop-out was 4.79 candles (~19 hours).
- Full MAE analysis across 2.0x, 2.5x, and 3.0x ATR stop widths, computing the blended portfolio-level expected return under each scenario with exact per-trade arithmetic.

**Blended portfolio result under best-case hindsight stop widths:**
| Stop Width | Reached RSI-60 | Avg Win | Survived (No RSI-60) | Avg | Stopped Out | Avg Loss | **Blended Total %** |
|---|---|---|---|---|---|---|---|
| 2.0x ATR | 23 trades | +6.85% | 51 trades | +0.63% | 52 trades | -4.66% | **-5.27%** |
| 3.0x ATR | 26 trades | +6.54% | 69 trades | -0.28% | 31 trades | -6.31% | **-4.44%** |

**Root cause:** The entry logic itself is fundamentally flawed for crypto at 4h resolution. An RSI recovery from below 30 back to 30+ is not a reliable signal of absolute price recovery — it frequently occurs inside genuine, sustained declines. The strategy is **catching falling knives**: entering on the first sign of RSI recovery in a downswing, but a 4h candle RSI bounce from <30 to ≥30 is often just a dead-cat bounce within an ongoing bearish impulse. The 1.5x ATR stop (tighter than BreakoutV1's 3.0x, justified by "mean-reversion resolves faster") proved to be inadequate against the actual volatility and drawdown profile of these entry events.

**This is a legitimate, evidence-based rejection, not an incomplete result.** The strategy was given a full and fair test. The data clearly shows negative expected return that persists even under the most favorable stop-width assumptions available via hindsight. No further testing of this specific entry mechanism is warranted unless the entry logic is redesigned from first principles (e.g., requiring a minimum RSI recovery duration, adding a volatility contraction filter, or requiring confirmation from a higher timeframe momentum indicator).
