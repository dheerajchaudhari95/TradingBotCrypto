import pandas as pd
import pandas_ta as ta
from freqtrade.strategy import IStrategy, informative, stoploss_from_absolute
from pandas import DataFrame


class BreakoutV1_stop25(IStrategy):
    """
    BreakoutV1 — 4H Donchian Channel Breakout Strategy (V2)
    =========================================================
    Timeframe: 4h
    Higher-TF filter: Daily EMA200 (via @informative decorator, confirmed against
                      official Freqtrade docs for version 2026.8)

    ENTRY — ALL of:
      1. close > donchian_upper_20  (confirmed close above 20-candle high)
      2. close > donchian_upper_20 + 0.5 * ATR  (ATR buffer against marginal breaks)
      3. volume > volume_avg_20  (volume confirmation)
      4. close > ema200_1d  (daily EMA200 regime filter)

    EXIT:
      close < donchian_lower_10  (10-candle Donchian lower band)

    STOPLOSS:
      Custom trailing: 2.5x ATR below current_rate.
      Hard floor: -10% (stoploss = -0.10)
      Pattern copied fresh from EmaAtrTrend.py (V1), no cross-file reference.

    INFORMATIVE PAIR SYNTAX (verified from freqtrade.io/en/stable/strategy-customization/):
      @informative('1d') on same-pair method → columns suffixed with '_1d'
      e.g. 'ema200' in the 1d frame → 'ema200_1d' in the 4h dataframe.
      No informative_pairs() override needed when using the decorator.
    """

    INTERFACE_VERSION = 3

    timeframe = "4h"
    can_short = False

    # ROI: effectively disabled — exits governed by signal or custom stop
    minimal_roi = {"0": 1.0}

    # Hard-floor stoploss; real stop is ATR-based via custom_stoploss
    stoploss = -0.10
    use_custom_stoploss = True
    trailing_stop = False

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    # 200 daily candles for EMA200 warmup + 20 4h candles for Donchian warmup
    # The effective 4h equivalent of 200 daily candles is 1200 4h candles,
    # but Freqtrade handles the informative timeframe separately.
    # For the 4h frame itself, 50 candles covers Donchian(20) + ATR(14) warmup.
    startup_candle_count: int = 250  # conservatively covers daily EMA200 warm-up

    # ── Informative: daily EMA200 ──────────────────────────────────────────────
    # Confirmed syntax from official docs:
    # @informative('1d') on same-pair method → column becomes 'ema200_1d' in 4h df.
    # ffill=True (default) forward-fills the daily value into every 4h candle.
    @informative('1d')
    def populate_indicators_1d(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Daily timeframe: compute EMA200. Merged into 4h df as 'ema200_1d'."""
        dataframe['ema200'] = ta.ema(dataframe['close'], length=200)
        return dataframe

    # ── 4H Indicators ──────────────────────────────────────────────────────────
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Compute all 4h indicators. The daily EMA200 is already merged into
        the dataframe as 'ema200_1d' by the @informative decorator before
        this method is called.
        """
        # Donchian upper: highest high of last 20 candles, shift(1) excludes current candle
        dataframe['donchian_upper_20'] = dataframe['high'].shift(1).rolling(window=20).max()

        # Donchian lower: lowest low of last 10 candles, shift(1) excludes current candle
        dataframe['donchian_lower_10'] = dataframe['low'].shift(1).rolling(window=10).min()

        # ATR(14) — used for entry buffer and custom stop
        dataframe['atr'] = ta.atr(
            dataframe['high'], dataframe['low'], dataframe['close'], length=14
        )

        # 20-period volume average — for volume confirmation filter
        dataframe['volume_avg_20'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    # ── Entry signal ───────────────────────────────────────────────────────────
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Long entry when ALL four conditions are true simultaneously:
          1. Close broke above the 20-candle Donchian upper (confirmed close)
          2. Close is at least 0.5 ATR above the upper band (filters marginal breaks)
          3. Volume exceeds its 20-period average (participation confirmation)
          4. Close is above the daily EMA200 (macro uptrend regime filter)
        """
        dataframe.loc[
            (
                (dataframe['close'] > dataframe['donchian_upper_20']) &
                (dataframe['close'] > dataframe['donchian_upper_20'] + 0.5 * dataframe['atr']) &
                (dataframe['volume'] > dataframe['volume_avg_20']) &
                (dataframe['close'] > dataframe['ema200_1d']) &
                (dataframe['volume'] > 0)  # guard against zero-volume candles
            ),
            'enter_long'
        ] = 1
        return dataframe

    # ── Exit signal ────────────────────────────────────────────────────────────
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Exit long when price closes below the 10-candle Donchian lower band.
        This acts as a trailing mean-reversion / range breakdown exit.
        """
        dataframe.loc[
            (dataframe['close'] < dataframe['donchian_lower_10']),
            'exit_long'
        ] = 1
        return dataframe

    # ── Custom stoploss: 2.5x ATR trailing ──────────────────────────────────────
    # Pattern copied fresh from V1's EmaAtrTrend.py. No cross-file reference.
    # Logic: place stop 2.5 ATR below current_rate. If ATR unavailable, fall
    # back to the hard-floor stoploss (-10%).
    def custom_stoploss(
        self, pair: str, trade: 'Trade', current_time: 'datetime',
        current_rate: float, current_profit: float, **kwargs
    ) -> float:
        """
        ATR-based trailing stop: stop = current_rate - 2.5 * ATR(14).
        Hard floor fallback: -10% (self.stoploss).
        """
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is not None and not dataframe.empty:
            last_candle = dataframe.iloc[-1].squeeze()
            if 'atr' in last_candle and not pd.isna(last_candle['atr']):
                atr_val = last_candle['atr']
                stop_price = current_rate - (2.5 * atr_val)
                return stoploss_from_absolute(stop_price, current_rate)
        return self.stoploss
