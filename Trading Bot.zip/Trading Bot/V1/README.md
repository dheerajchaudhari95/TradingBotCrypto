# EmaAtrTrend Trading Bot

## 1. Overview
This project is an automated cryptocurrency trading system designed to capture medium-to-long term trends in high-liquidity assets like Bitcoin and Ethereum. It operates completely autonomously, scanning live market data daily for favorable momentum shifts, calculating precise risk-adjusted position sizes, and managing exits with trailing stops. The system has been rigorously backtested across nine years of historical data (including multiple bear and bull cycles) to ensure robust performance before live deployment.

## 2. Architecture
The system is built on **Freqtrade**, a leading open-source crypto trading framework written in Python. Freqtrade was chosen over a custom-built solution because it provides a battle-tested execution engine, seamless exchange connectivity via CCXT, extensive backtesting and dry-run capabilities, and native safety mechanisms (like cooldowns and drawdown protection).

**Folder Structure:**
- `user_data/strategies/`: Contains `EmaAtrTrend.py`, the core strategy file containing all logic, indicators, and risk management.
- `user_data/config.json`: The global configuration file, managing API keys, exchange connections, pair whitelists, and live/dry-run toggles.
- `docs/`: Project documentation, including the manual kill-switch procedure and architectural notes.
- `.env`: Environment variables used for securely injecting API keys and credentials without committing them to version control.

## 3. Strategy
The core strategy, `EmaAtrTrend`, is a trend-following system consisting of four primary components:
- **EMA20/50 Crossover:** The primary entry signal. It triggers a buy when the faster 20-day Exponential Moving Average (EMA) crosses above the slower 50-day EMA, indicating short-term momentum is accelerating upward. It triggers an exit when the fast EMA crosses back below the slow EMA.
- **SMA200 Regime Filter:** A strict requirement that long entries can only occur when the price is above the 200-day Simple Moving Average. This ensures the bot only attempts to buy during macro uptrends and stays safely out of the market during prolonged crypto winters.
- **ATR-Based Trailing Stop:** Once in a trade, a hard stoploss is set at 2 × ATR (Average True Range) below the current price. ATR measures market volatility; this allows the stop distance to dynamically expand during turbulent times and tighten during quiet periods, keeping the bot from being prematurely shaken out of good trades.
- **Fixed-Fractional 1% Risk Sizing:** Instead of betting a flat dollar amount on every trade, the bot risks exactly 1% of the total account equity per trade. It achieves this by calculating the distance to the ATR stoploss and sizing the position so that hitting the stoploss would exactly equal a 1% loss of total capital. This protects the account from ruin while scaling automatically as the account grows.

## 4. Validation Journey
Our validation process prioritized rigorous, honest evaluation over curve-fitting:
- **In-Sample Testing (2021-2024):** The initial ruleset was formulated and iterated on this window. We refined the EMA pairs and established the 200-day SMA filter to bypass the brutal 2022 bear market.
- **Out-of-Sample Testing (2024-2026):** We locked the ruleset and tested it on untouched recent data. The strategy successfully navigated the period, maintaining its edge without needing parameter tweaks.
- **Independent 2018 Bear-Market Test:** To ensure the SMA200 filter genuinely prevented catastrophic losses in deep bear markets, we tested the locked strategy on 2017-2021 data (which was entirely excluded from the initial design phase). The bot successfully avoided the 2018 crypto winter, executing zero trades during the massive drawdown.
- **Broad Market 8-Pair Test:** We attempted to broaden the scope from just BTC/ETH to a basket of 8 high-liquidity altcoins (SOL, ADA, DOT, etc.). This failed to generalize; the strategy suffered massive drawdowns on the altcoins, proving that the trend-following edge was specific to the established liquidity of BTC and ETH. The pair scope was responsibly reverted back to only BTC and ETH.
- **Outlier Robustness Check:** To measure reliance on luck, we simulated the backtest explicitly blocking the two largest profitable trades (ETH in mid-2021). Removing just those two trades from the 20-trade sequence dropped the 9-year profit to near breakeven (0.07% total). This proved the strategy's historical success is heavily concentrated in a few massive macro trends rather than a steady daily grind.

![Cumulative profit across all 20 validated trades (2017-2026). Note the concentration of net gains in trades 4-8 (2020-2021), consistent with the outlier finding in Known Limitations (b).](docs/equity_curve.png)

## 5. Current Status
The bot is currently running live in **dry-run mode** since 2026-09-15. It is actively polling live market data and simulating trades against the Binance exchange. Native Freqtrade protections (CooldownPeriod, StoplossGuard, MaxDrawdown) are actively monitoring the simulated portfolio, and the manual kill-switch REST API is fully operational and documented.

## 6. Known Limitations & Next Steps
- **(a)** Statistical significance not yet reached at any test window, p-values 0.24-0.68 throughout.
- **(b)** Outlier concentration means repeatability of the edge is not yet confirmed, only live time will tell.
- **(c)** Trade frequency is low (~2/year on BTC/ETH), broadening to more pairs was tested and failed to generalize, remains open for future work.
- **(d)** Cross-pair exposure protection uses Freqtrade's native global guards (StoplossGuard, MaxDrawdown) rather than a bespoke correlation-aware cap, a reasonable v1 substitute, flagged for future refinement.
- **(e)** Not yet validated with real capital, dry-run is the current and ongoing validation stage.
- **(f)** Websocket-based data streaming was found to fail silently under Freqtrade's current async layer (a known upstream issue, confirmed against live GitHub reports for this version) and has been disabled in favor of REST polling, verified stable over an extended observation window. Documented here as an example of operational verification, not just strategy validation.
