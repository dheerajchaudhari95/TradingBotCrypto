import json
import zipfile
import glob
import os

# Find latest zip
files = glob.glob('user_data/backtest_results/*.zip')
files.sort()
latest_zip = files[-1]

with zipfile.ZipFile(latest_zip, 'r') as z:
    for filename in z.namelist():
        if filename.endswith('.json') and 'meta' not in filename:
            with z.open(filename) as f:
                data = json.load(f)
                
                trades = data['strategy']['DiagnosticCrossoverOnly']['trades']
                
                btc_trades = sum(1 for t in trades if t['pair'] == 'BTC/USDT')
                eth_trades = sum(1 for t in trades if t['pair'] == 'ETH/USDT')
                
                print(f'Total BTC/USDT trades: {btc_trades}')
                print(f'Total ETH/USDT trades: {eth_trades}')
                print('\nEntry Dates:')
                
                for t in trades:
                    print(f"{t['pair']}: {t['open_date']}")
