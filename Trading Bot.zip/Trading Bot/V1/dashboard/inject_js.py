import sys

with open('dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Replace refreshData to include the new logic
old_refresh = """        async function refreshData() {
            const loader = document.getElementById('sync-loader');
            loader.classList.add('active');
            
            try {
                const [health, status, profit, balance, daily, trades, locks] = await Promise.all([
                    fetchApi('health'),
                    fetchApi('status'),
                    fetchApi('profit'),
                    fetchApi('balance'),
                    fetchApi('daily'),
                    fetchApi('trades?limit=20'),
                    fetchApi('locks')
                ]);

                updateHealth(health);
                updateBalance(balance);
                updateProfit(profit);
                updateOpenPositions(status);
                updateChart(daily);
                updateClosedTrades(trades);
                updateLocks(locks);

            } catch (e) {
                console.error("Refresh failed", e);
                updateStatusOffline();
            } finally {
                setTimeout(() => loader.classList.remove('active'), 500);
            }
        }"""

new_refresh = """        // NEW JS STATE
        let candleCache = {};
        let lwChart = null;
        let lineSeriesMap = {};

        async function fetchCandles(pair) {
            const encodedPair = encodeURIComponent(pair);
            return await fetchApi(`pair_candles?pair=${encodedPair}&timeframe=1d`);
        }

        async function refreshData() {
            const loader = document.getElementById('sync-loader');
            loader.classList.add('active');
            const now = new Date();
            document.getElementById('last-updated').textContent = `Last updated: ${now.toLocaleTimeString()}`;
            
            try {
                const [health, status, profit, balance, daily, tradesObj, locks] = await Promise.all([
                    fetchApi('health'),
                    fetchApi('status'),
                    fetchApi('profit'),
                    fetchApi('balance'),
                    fetchApi('daily'),
                    fetchApi('trades?limit=20'),
                    fetchApi('locks')
                ]);

                updateHealth(health);
                updateBalance(balance);
                updateProfit(profit);
                updateOpenPositions(status);
                updateChart(daily);
                updateClosedTrades(tradesObj);
                updateLocks(locks);

                // --- NEW LOGIC FOR CHART AND BREAKDOWN ---
                const selectedPair = document.getElementById('chart-pair-select').value;
                const chartCandles = await fetchCandles(selectedPair);
                
                const trades = tradesObj.trades || [];
                const openTrades = status || [];
                const allTrades = [...openTrades, ...trades];
                
                // Render LW Chart
                renderLWChart(chartCandles, allTrades, selectedPair);
                
                // Fetch candles for all pairs in trades to do decision breakdown
                const uniquePairs = [...new Set(allTrades.map(t => t.pair))];
                for(let p of uniquePairs) {
                    if (p === selectedPair) {
                        candleCache[p] = chartCandles;
                    } else {
                        candleCache[p] = await fetchCandles(p).catch(() => null);
                    }
                }
                
                renderDecisionBreakdown(allTrades);

            } catch (e) {
                console.error("Refresh failed", e);
                updateStatusOffline();
            } finally {
                setTimeout(() => loader.classList.remove('active'), 500);
            }
        }
"""
html = html.replace(old_refresh, new_refresh)

new_js = """
        // ==========================================
        // LW CHART & DECISION BREAKDOWN & MANUAL VIEW
        // ==========================================

        document.getElementById('chart-pair-select').addEventListener('change', () => refreshData());

        function renderLWChart(candleData, trades, selectedPair) {
            const container = document.getElementById('price-chart-container');
            if (!lwChart) {
                lwChart = LightweightCharts.createChart(container, {
                    layout: { background: { color: 'transparent' }, textColor: '#94a3b8' },
                    grid: { vertLines: { color: '#334155' }, horzLines: { color: '#334155' } },
                    timeScale: { timeVisible: true }
                });
                lineSeriesMap.candles = lwChart.addCandlestickSeries();
                lineSeriesMap.ema20 = lwChart.addLineSeries({ color: '#f59e0b', lineWidth: 2, title: 'EMA20' }); // amber
                lineSeriesMap.ema50 = lwChart.addLineSeries({ color: '#3b82f6', lineWidth: 2, title: 'EMA50' }); // blue
                lineSeriesMap.sma200 = lwChart.addLineSeries({ color: '#a855f7', lineWidth: 2, title: 'SMA200' }); // purple
            }

            if (!candleData || !candleData.data) return;

            const cols = candleData.columns;
            const idxDate = cols.indexOf('date');
            const idxOpen = cols.indexOf('open');
            const idxHigh = cols.indexOf('high');
            const idxLow = cols.indexOf('low');
            const idxClose = cols.indexOf('close');
            const idxEmaFast = cols.indexOf('ema_fast');
            const idxEmaSlow = cols.indexOf('ema_slow');
            const idxSma200 = cols.indexOf('sma200');

            const cData = [];
            const ema20 = [];
            const ema50 = [];
            const sma200 = [];

            candleData.data.forEach(row => {
                const t = new Date(row[idxDate]).getTime() / 1000;
                cData.push({ time: t, open: row[idxOpen], high: row[idxHigh], low: row[idxLow], close: row[idxClose] });
                if (row[idxEmaFast] != null && !isNaN(row[idxEmaFast])) ema20.push({ time: t, value: row[idxEmaFast] });
                if (row[idxEmaSlow] != null && !isNaN(row[idxEmaSlow])) ema50.push({ time: t, value: row[idxEmaSlow] });
                if (row[idxSma200] != null && !isNaN(row[idxSma200])) sma200.push({ time: t, value: row[idxSma200] });
            });

            lineSeriesMap.candles.setData(cData);
            lineSeriesMap.ema20.setData(ema20);
            lineSeriesMap.ema50.setData(ema50);
            lineSeriesMap.sma200.setData(sma200);

            // Add markers
            const markers = [];
            trades.filter(t => t.pair === selectedPair).forEach(t => {
                const entryTime = new Date(t.open_date).getTime() / 1000;
                markers.push({
                    time: entryTime,
                    position: 'belowBar',
                    color: '#10b981',
                    shape: 'arrowUp',
                    text: `Entry @ ${t.open_rate}`
                });
                if (t.close_date) {
                    const exitTime = new Date(t.close_date).getTime() / 1000;
                    markers.push({
                        time: exitTime,
                        position: 'aboveBar',
                        color: '#ef4444',
                        shape: 'arrowDown',
                        text: `Exit: ${t.exit_reason || '-'} @ ${t.close_rate}`
                    });
                }
            });
            // Sort markers by time as required by Lightweight Charts
            markers.sort((a,b) => a.time - b.time);
            lineSeriesMap.candles.setMarkers(markers);
        }

        function renderDecisionBreakdown(trades) {
            const container = document.getElementById('decision-breakdown-container');
            if (trades.length === 0) {
                container.innerHTML = '<div class="empty-state">No trades to analyze</div>';
                return;
            }

            // Sort trades newest first
            const sorted = [...trades].sort((a,b) => new Date(b.open_date) - new Date(a.open_date));
            
            let html = '';
            sorted.forEach(t => {
                const pData = candleCache[t.pair];
                let breakdown = "Indicator data unavailable.";
                
                if (pData && pData.data) {
                    const cols = pData.columns;
                    const idxDate = cols.indexOf('date');
                    const idxEmaFast = cols.indexOf('ema_fast');
                    const idxEmaSlow = cols.indexOf('ema_slow');
                    const idxSma200 = cols.indexOf('sma200');
                    const idxClose = cols.indexOf('close');

                    // Find candle matching entry date (or just before)
                    const entryTime = new Date(t.open_date).getTime();
                    let matchedRow = null;
                    for (let i = pData.data.length - 1; i >= 0; i--) {
                        const rowTime = new Date(pData.data[i][idxDate]).getTime();
                        if (rowTime <= entryTime) {
                            matchedRow = pData.data[i];
                            break;
                        }
                    }

                    if (matchedRow) {
                        const ema20 = matchedRow[idxEmaFast];
                        const ema50 = matchedRow[idxEmaSlow];
                        const sma200 = matchedRow[idxSma200];
                        const price = matchedRow[idxClose];
                        
                        breakdown = `Entered ${t.is_short ? 'short' : 'long'}: EMA20 (${formatNumber(ema20)}) crossed above EMA50 (${formatNumber(ema50)}); price (${formatNumber(price)}) was above the 200-day trend filter (${formatNumber(sma200)}).`;
                    }
                }

                let trailingInfo = '';
                if (!t.close_date) {
                    // Open position trailing stop info
                    const dist = ((t.current_rate - t.stop_loss_abs) / t.current_rate) * 100;
                    trailingInfo = `<div style="margin-top:0.5rem; color:var(--text-secondary); font-size:0.85rem;">Distance to trailing stop: ${dist.toFixed(2)}%</div>`;
                }

                const statusColor = t.close_date ? '#94a3b8' : '#10b981';
                const statusBadge = t.close_date ? 'CLOSED' : 'OPEN';

                html += `
                    <div style="padding: 1rem; border-bottom: 1px solid var(--border);">
                        <div style="display:flex; justify-content:space-between; margin-bottom: 0.5rem;">
                            <strong style="color:var(--text-primary);">${t.pair}</strong>
                            <span style="font-size:0.75rem; background: ${statusColor}; color: #000; padding: 0.1rem 0.4rem; border-radius: 0.25rem;">${statusBadge}</span>
                        </div>
                        <div style="font-size:0.85rem; color:var(--text-secondary); margin-bottom: 0.5rem;">${formatDate(t.open_date)}</div>
                        <div style="font-size:0.9rem; line-height: 1.4;">${breakdown}</div>
                        ${trailingInfo}
                    </div>
                `;
            });
            container.innerHTML = html;
        }

        // Manual View logic
        function loadManualNotes() {
            const notes = JSON.parse(localStorage.getItem('manual_notes') || '[]');
            const tbody = document.getElementById('manual-tbody');
            if (notes.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="empty-state">No manual notes yet</td></tr>';
                return;
            }
            let html = '';
            notes.forEach((n, idx) => {
                html += `
                    <tr>
                        <td>${n.date}</td>
                        <td><span class="pair-badge">${n.pair}</span></td>
                        <td>${n.view}</td>
                        <td>${n.action || '-'}</td>
                        <td>${n.note}</td>
                        <td><button style="background:transparent; color:var(--danger); border:none; cursor:pointer;" onclick="deleteManualNote(${idx})">X</button></td>
                    </tr>
                `;
            });
            tbody.innerHTML = html;
        }

        window.deleteManualNote = function(idx) {
            let notes = JSON.parse(localStorage.getItem('manual_notes') || '[]');
            notes.splice(idx, 1);
            localStorage.setItem('manual_notes', JSON.stringify(notes));
            loadManualNotes();
        };

        document.getElementById('manual-save-btn').addEventListener('click', () => {
            const pair = document.getElementById('manual-pair').value;
            const view = document.getElementById('manual-view').value;
            const action = document.getElementById('manual-action').value;
            const note = document.getElementById('manual-note').value;
            
            if (!note.trim()) {
                alert('Please enter a note'); return;
            }

            const notes = JSON.parse(localStorage.getItem('manual_notes') || '[]');
            notes.unshift({
                date: formatDate(new Date().toISOString()),
                pair, view, action, note
            });
            
            localStorage.setItem('manual_notes', JSON.stringify(notes));
            document.getElementById('manual-action').value = '';
            document.getElementById('manual-note').value = '';
            loadManualNotes();
        });

        // Load initially
        loadManualNotes();
"""
html = html.replace('</script>\n</body>', new_js + '\n</script>\n</body>')

with open('dashboard.html', 'w', encoding='utf-8') as f:
    f.write(html)
