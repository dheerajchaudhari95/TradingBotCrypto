import sys

with open('dashboard.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Add lightweight-charts script
html = html.replace('<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>', '<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>\n    <script src="https://unpkg.com/lightweight-charts/dist/lightweight-charts.standalone.production.js"></script>')

# Add 'last updated'
html = html.replace('<div class="status-dot"></div>', '<div class="status-dot"></div>')
html = html.replace('<span id="status-text">Connecting...</span>\n                </div>', '<span id="status-text">Connecting...</span>\n                </div>\n                <div id="last-updated" style="font-size: 0.85rem; color: var(--text-secondary); margin-left: 1rem;"></div>')

# Add Chart and Decision Breakdown cards
chart_html = """
        <div class="grid">
            <!-- Price Chart -->
            <div class="card col-span-8">
                <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
                    <span>Price Chart (1d)</span>
                    <select id="chart-pair-select" style="background:var(--bg-base); color:var(--text-primary); border:1px solid var(--border); padding:0.25rem; border-radius:0.25rem;">
                        <option value="BTC/USDT">BTC/USDT</option>
                        <option value="ETH/USDT">ETH/USDT</option>
                    </select>
                </div>
                <div id="price-chart-container" style="height: 400px; width: 100%;"></div>
            </div>

            <!-- Decision Breakdown -->
            <div class="card col-span-4">
                <div class="card-header">Decision Breakdown</div>
                <div class="table-container" style="max-height: 400px; overflow-y: auto;">
                    <div id="decision-breakdown-container">
                        <div class="empty-state">Waiting for data...</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid">
            <!-- Manual Analyst View -->
            <div class="card col-span-12" style="border: 2px solid #a855f7; background: rgba(168, 85, 247, 0.05);">
                <div class="card-header" style="color: #d8b4fe;">MANUAL VIEW — Not Automated, Not Bot Output</div>
                <div style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 1rem;">Notes are saved locally in your browser (localStorage). They are not synced to the bot or any backend.</div>
                
                <div style="display:flex; gap: 1rem; margin-bottom: 1rem; align-items:flex-start;">
                    <select id="manual-pair" style="padding:0.5rem; background:var(--bg-base); color:var(--text-primary); border:1px solid var(--border); border-radius:0.5rem;">
                        <option value="BTC/USDT">BTC/USDT</option>
                        <option value="ETH/USDT">ETH/USDT</option>
                    </select>
                    <select id="manual-view" style="padding:0.5rem; background:var(--bg-base); color:var(--text-primary); border:1px solid var(--border); border-radius:0.5rem;">
                        <option value="Neutral">Neutral</option>
                        <option value="Uptrend">Uptrend</option>
                        <option value="Downtrend">Downtrend</option>
                    </select>
                    <input type="text" id="manual-action" placeholder="Suggested Action (Optional)" style="padding:0.5rem; background:var(--bg-base); color:var(--text-primary); border:1px solid var(--border); border-radius:0.5rem; flex:1;">
                </div>
                <div style="display:flex; gap: 1rem; margin-bottom: 1rem;">
                    <textarea id="manual-note" placeholder="Analyst note..." style="padding:0.5rem; background:var(--bg-base); color:var(--text-primary); border:1px solid var(--border); border-radius:0.5rem; flex:1; min-height: 60px;"></textarea>
                    <button class="btn" id="manual-save-btn" style="width:auto; padding: 0 2rem; background:#a855f7;">Save Note</button>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Pair</th>
                                <th>View</th>
                                <th>Action</th>
                                <th>Note</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="manual-tbody">
                            <tr><td colspan="6" class="empty-state">No manual notes yet</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
"""

html = html.replace('<div class="grid">\n            <!-- Open Positions -->', chart_html + '\n        <div class="grid">\n            <!-- Open Positions -->')

with open('dashboard.html', 'w', encoding='utf-8') as f:
    f.write(html)
