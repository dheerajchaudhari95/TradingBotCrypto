import urllib.request, json, base64

s = '${FREQTRADE_API_USERNAME}:${FREQTRADE_API_PASSWORD}'
creds = base64.b64encode(s.encode()).decode()
req = urllib.request.Request('http://localhost:8080/api/v1/token/login',
    method='POST', headers={'Authorization': f'Basic {creds}', 'Content-Type': 'application/json'})
try:
    r = urllib.request.urlopen(req, timeout=3)
    data = json.loads(r.read().decode())
    token = data.get('access_token','')
    
    for ep in ['/api/v1/status', '/api/v1/profit', '/api/v1/balance', '/api/v1/daily', '/api/v1/trades', '/api/v1/health']:
        try:
            req2 = urllib.request.Request(f'http://localhost:8080{ep}',
                headers={'Authorization': f'Bearer {token}'})
            r2 = urllib.request.urlopen(req2, timeout=3)
            raw = json.loads(r2.read().decode())
            if isinstance(raw, list):
                if len(raw) > 0:
                    print(f'{ep}: LIST of {len(raw)}, first item keys: {list(raw[0].keys())}')
                else:
                    print(f'{ep}: EMPTY LIST')
            else:
                if 'data' in raw and isinstance(raw['data'], list) and len(raw['data']) > 0:
                     print(f'{ep}: keys={list(raw.keys())}, data item keys: {list(raw["data"][0].keys())}')
                else:
                     print(f'{ep}: keys={list(raw.keys())}')
        except Exception as e2:
            print(f'{ep}: ERROR {e2}')
except Exception as e:
    print('LOGIN FAILED:', e)
