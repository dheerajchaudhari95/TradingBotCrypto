import pandas as pd
import pandas_ta as ta
from freqtrade.strategy import IStrategy, stoploss_from_absolute
from pandas import DataFrame


class EmaAtrTrend(IStrategy):
    INTERFACE_VERSION = 3

    # ROI table:
    minimal_roi = {
        "0": 1.0
    }

    # Stoploss:
    stoploss = -0.10

    # Custom stoploss
    use_custom_stoploss = True
    trailing_stop = False

    # Optional timeframes
    timeframe = '1d'
    can_short = False

    @property
    def protections(self):
        return [
            {"method": "CooldownPeriod", "stop_duration_candles": 1},
            {"method": "StoplossGuard", "lookback_period_candles": 90, "trade_limit": 2,
             "stop_duration_candles": 14, "only_per_pair": False},
            {"method": "MaxDrawdown", "lookback_period_candles": 90, "trade_limit": 2,
             "stop_duration_candles": 30, "max_allowed_drawdown": 0.10}
        ]

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Calculates EMA20, EMA50, ATR14, and SMA200."""
        dataframe['ema_fast'] = ta.ema(dataframe['close'], length=20)
        dataframe['ema_slow'] = ta.ema(dataframe['close'], length=50)
        dataframe['atr'] = ta.atr(dataframe['high'], dataframe['low'], dataframe['close'], length=14)
        dataframe['sma200'] = ta.sma(dataframe['close'], length=200)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Enters Long when ema_fast crosses above ema_slow and close > sma200."""
        dataframe.loc[
            (
                (dataframe['ema_fast'] > dataframe['ema_slow']) &
                (dataframe['ema_fast'].shift(1) <= dataframe['ema_slow'].shift(1)) &
                (dataframe['close'] > dataframe['sma200'])
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Exits Long when ema_fast crosses below ema_slow."""
        dataframe.loc[
            (
                (dataframe['ema_fast'] < dataframe['ema_slow']) &
                (dataframe['ema_fast'].shift(1) >= dataframe['ema_slow'].shift(1))
            ),
            'exit_long'] = 1
        return dataframe

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: 'datetime', current_rate: float, current_profit: float, **kwargs) -> float:
        """Calculates a trailing stop at 2 * ATR below the current rate, returning the hard floor if ATR is unavailable."""
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is not None and not dataframe.empty:
            last_candle = dataframe.iloc[-1].squeeze()
            if 'atr' in last_candle and not pd.isna(last_candle['atr']):
                atr_val = last_candle['atr']
                stop_price = current_rate - (2 * atr_val)
                return stoploss_from_absolute(stop_price, current_rate)
        return self.stoploss

    def custom_stake_amount(self, pair: str, current_time: 'datetime', current_rate: float,
                            proposed_stake: float, min_stake: float, max_stake: float,
                            leverage: float, entry_tag: str, side: str, **kwargs) -> float:
        """Fixed-fractional risk sizing: 1% of equity per trade, sized by ATR-based stop distance."""
        risk_pct = 0.01
        account_equity = self.wallets.get_total_stake_amount()
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is None or dataframe.empty:
            return proposed_stake
        last_candle = dataframe.iloc[-1].squeeze()
        if 'atr' not in last_candle or pd.isna(last_candle['atr']):
            return proposed_stake
        atr = last_candle['atr']
        stop_distance_fraction = (2 * atr) / current_rate
        risk_amount = account_equity * risk_pct
        stake = risk_amount / stop_distance_fraction
        return stake

