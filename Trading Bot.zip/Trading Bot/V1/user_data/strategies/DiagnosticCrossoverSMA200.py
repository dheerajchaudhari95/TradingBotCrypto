import pandas as pd
import pandas_ta as ta
from freqtrade.strategy import IStrategy, stoploss_from_absolute
from pandas import DataFrame


class DiagnosticCrossoverSMA200(IStrategy):
    INTERFACE_VERSION = 3

    # ROI table:
    minimal_roi = {
        "0": 1.0
    }

    # Stoploss:
    stoploss = -0.10

    # Custom stoploss
    use_custom_stoploss = True
    trailing_stop = False

    # Optional timeframes
    timeframe = '1d'
    can_short = False

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Calculates EMA20, EMA50, ATR14, ATR percent, and a 50-candle rolling median of ATR percent."""
        dataframe['ema_fast'] = ta.ema(dataframe['close'], length=20)
        dataframe['ema_slow'] = ta.ema(dataframe['close'], length=50)
        dataframe['atr'] = ta.atr(dataframe['high'], dataframe['low'], dataframe['close'], length=14)
        dataframe['atr_pct'] = dataframe['atr'] / dataframe['close']
        dataframe['atr_pct_median50'] = dataframe['atr_pct'].rolling(window=50).median()
        
        dataframe['sma200'] = ta.sma(dataframe['close'], length=200)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Enters Long when ema_fast crosses above ema_slow and close > sma200."""
        dataframe.loc[
            (
                (dataframe['ema_fast'] > dataframe['ema_slow']) &
                (dataframe['ema_fast'].shift(1) <= dataframe['ema_slow'].shift(1)) &
                (dataframe['close'] > dataframe['sma200'])
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Exits Long when ema_fast crosses below ema_slow."""
        dataframe.loc[
            (
                (dataframe['ema_fast'] < dataframe['ema_slow']) &
                (dataframe['ema_fast'].shift(1) >= dataframe['ema_slow'].shift(1))
            ),
            'exit_long'] = 1
        return dataframe

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: 'datetime', current_rate: float, current_profit: float, **kwargs) -> float:
        """Calculates a trailing stop at 2 * ATR below the current rate, returning the hard floor if ATR is unavailable."""
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is not None and not dataframe.empty:
            last_candle = dataframe.iloc[-1].squeeze()
            if 'atr' in last_candle and not pd.isna(last_candle['atr']):
                atr_val = last_candle['atr']
                stop_price = current_rate - (2 * atr_val)
                return stoploss_from_absolute(stop_price, current_rate)
        return self.stoploss
