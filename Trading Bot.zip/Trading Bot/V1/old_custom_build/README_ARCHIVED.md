# ARCHIVED — Custom Build (Superseded by Freqtrade)

**Archive date:** 2026-09-15  
**Status:** Inactive reference only. Not part of the active codebase.

---

These files represent the first-pass custom implementation of the BTC/ETH swing trading bot, built before the pivot to the Freqtrade framework. They are kept here for reference — architectural notes, gap detection logic, and exchange research may still be useful context.

**Why superseded:** Freqtrade already implements exchange connectivity (ccxt), OHLCV fetching, gap management, order execution with filter compliance, backtesting with walk-forward capability, and dry-run paper trading out of the box. Building equivalent reliability from scratch would have taken weeks and still lagged Freqtrade's maturity. The pivot saves that time for strategy and risk work, which is the actual value-add.

**Do not run or import any code from this archive.** The active codebase is in `user_data/` and the project root.

## Contents

```
old_custom_build/
├── src/
│   ├── data_pipeline/   # ccxt-based OHLCV fetcher, gap detector (10 tests passing), CSV storage
│   ├── strategy/        # signals.py stub (not implemented)
│   ├── risk/            # sizing.py stub (not implemented)
│   ├── execution/       # broker.py + symbol_rules.py stubs (not implemented)
│   └── backtest/        # vectorbt engine stub (not implemented)
├── config/
│   └── settings.py      # .env loader, centralised config
├── tests/
│   ├── conftest.py
│   └── test_gap_detector.py  # 10 passing unit tests for gap detection
└── pytest.ini
```

## What Was Working

- `src/data_pipeline/gap_detector.py` — 10/10 tests passing, correctly detects missing daily candles
- Logging infrastructure (`src/logger.py`) — rotating file + console, `get_logger(__name__)` pattern
- Project scaffolding, `.env.example`, `.gitignore`

## What Was Not Yet Implemented

- Strategy signal generation (EMA/ATR)
- Position sizing (fixed-fractional)
- Live order execution
- Backtesting engine
