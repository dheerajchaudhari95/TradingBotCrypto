"""
src/backtest/engine.py — STUB

vectorbt-based backtest engine.

THIS MODULE IS A STUB. Backtest logic is implemented in the NEXT prompt.

CONTRACT:
- Imports compute_signals() from src/strategy/signals.py — no duplicated signal logic.
- Imports size_position() from src/risk/sizing.py — no duplicated sizing logic.
"""

from __future__ import annotations
import pandas as pd
from src.logger import get_logger

logger = get_logger(__name__)


def run_backtest(
    ohlcv: dict[str, pd.DataFrame],
    initial_equity: float = 10_000.0,
) -> None:
    """
    Run a full backtest over historical OHLCV data.

    Args:
        ohlcv: Dict mapping symbol → OHLCV DataFrame (from src/data_pipeline)
        initial_equity: Starting equity in USDT

    NOT YET IMPLEMENTED.
    """
    raise NotImplementedError(
        "Backtest engine not yet implemented. "
        "Implement in the next prompt after scaffolding is verified."
    )
