"""
src/risk/sizing.py — STUB

Fixed-fractional position sizing, exposure caps, and circuit breaker logic.

THIS MODULE IS A STUB. Risk logic is implemented in the NEXT prompt.

CONTRACT:
- size_position() accepts account equity, per-trade risk %, stop distance,
  and symbol filter rules (stepSize, minNotional) — returns a quantity float.
- The same function is used by both src/backtest/engine.py and src/execution/broker.py.
"""

from __future__ import annotations
import pandas as pd


def size_position(
    equity: float,
    risk_pct: float,
    stop_distance: float,
    price: float,
    step_size: float,
    min_notional: float,
) -> float:
    """
    Calculate order quantity using fixed-fractional sizing.

    Args:
        equity:       Total account equity in quote currency (USDT)
        risk_pct:     Fraction of equity to risk per trade (e.g. 0.01 = 1%)
        stop_distance: Price distance from entry to stop-loss
        price:        Current/entry price
        step_size:    Minimum quantity increment from exchange rules
        min_notional: Minimum order value in USDT from exchange rules

    Returns:
        Rounded-down quantity satisfying stepSize and minNotional constraints.
        Returns 0.0 if position would be below minNotional.

    NOT YET IMPLEMENTED — raises NotImplementedError until next prompt.
    """
    raise NotImplementedError(
        "Position sizing not yet implemented. "
        "Implement in the next prompt after scaffolding is verified."
    )
