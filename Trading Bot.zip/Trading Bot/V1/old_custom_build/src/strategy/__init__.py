"""src/strategy/__init__.py"""
