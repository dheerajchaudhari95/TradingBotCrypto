"""
src/strategy/signals.py — STUB

Signal generation for EMA crossover + ATR trend-following strategy.

THIS MODULE IS A STUB. Strategy logic is implemented in the NEXT prompt.

CONTRACT (do not break when implementing):
- Functions in this module must accept a pandas DataFrame of OHLCV data
  and return a pandas Series of signals (or a signals DataFrame).
- The SAME functions are imported by src/backtest/engine.py AND src/execution/broker.py.
- No logic duplication allowed: if this file changes, both backtest and live
  execution automatically use the updated logic.
"""

from __future__ import annotations
import pandas as pd


def compute_signals(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute EMA crossover + ATR signals on daily OHLCV data.

    Args:
        df: DataFrame with columns [timestamp, open, high, low, close, volume]

    Returns:
        DataFrame with additional columns:
          - ema_fast:  Fast EMA values
          - ema_slow:  Slow EMA values
          - atr:       Average True Range
          - signal:    1 = long, 0 = flat (no short selling in v1)

    NOT YET IMPLEMENTED — raises NotImplementedError until next prompt.
    """
    raise NotImplementedError(
        "Strategy signals not yet implemented. "
        "Implement in the next prompt after scaffolding is verified."
    )
