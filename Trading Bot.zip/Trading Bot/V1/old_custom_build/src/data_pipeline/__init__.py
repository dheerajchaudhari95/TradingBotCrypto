"""
src/data_pipeline/__init__.py

Public API for the data pipeline package.

Imports are intentionally lazy (not at module level) so that unit tests
for gap_detector.py and storage.py do not require ccxt to be installed.
ccxt is only needed when actually calling fetch_ohlcv().
"""

__all__ = ["fetch_ohlcv", "detect_gaps", "save_ohlcv", "load_ohlcv"]


def fetch_ohlcv(*args, **kwargs):
    from .fetcher import fetch_ohlcv as _fetch
    return _fetch(*args, **kwargs)


def detect_gaps(*args, **kwargs):
    from .gap_detector import detect_gaps as _detect
    return _detect(*args, **kwargs)


def save_ohlcv(*args, **kwargs):
    from .storage import save_ohlcv as _save
    return _save(*args, **kwargs)


def load_ohlcv(*args, **kwargs):
    from .storage import load_ohlcv as _load
    return _load(*args, **kwargs)
