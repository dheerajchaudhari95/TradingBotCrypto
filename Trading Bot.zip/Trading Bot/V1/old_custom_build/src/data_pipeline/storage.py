"""
src/data_pipeline/storage.py

Local persistence for OHLCV data.

Storage backend: CSV (see README.md § Design Decisions for rationale).

Each symbol is stored in a separate file:
    data/BTCUSDT_1d.csv
    data/ETHUSDT_1d.csv

The file format is:
    timestamp (ISO 8601, UTC),open,high,low,close,volume

Append semantics: save_ohlcv() intelligently merges new data with existing,
deduplicates by timestamp, and re-sorts before writing. This allows incremental
updates without loading the full history into memory for small datasets.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.logger import get_logger

logger = get_logger(__name__)

_TIMESTAMP_COL = "timestamp"
_CSV_TIMESTAMP_FORMAT = "ISO8601"   # pandas 2.x: full UTC ISO 8601


def _symbol_to_filename(symbol: str, timeframe: str) -> str:
    """Convert 'BTC/USDT' + '1d' → 'BTCUSDT_1d.csv'"""
    return symbol.replace("/", "") + f"_{timeframe}.csv"


def save_ohlcv(
    df: pd.DataFrame,
    symbol: str,
    timeframe: str = "1d",
    data_dir: Path | None = None,
) -> Path:
    """
    Persist OHLCV DataFrame to CSV.

    If a file for this symbol+timeframe already exists, the new data is merged
    with the existing data (deduplication by timestamp, ascending sort).

    Args:
        df:        DataFrame with columns [timestamp, open, high, low, close, volume]
                   Timestamp must be UTC timezone-aware.
        symbol:    ccxt-format symbol string, e.g. "BTC/USDT"
        timeframe: ccxt timeframe string, e.g. "1d"
        data_dir:  Override data directory (defaults to config/settings.DATA_DIR)

    Returns:
        Path to the written CSV file.
    """
    if data_dir is None:
        from config.settings import DATA_DIR
        data_dir = DATA_DIR

    data_dir = Path(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)

    filepath = data_dir / _symbol_to_filename(symbol, timeframe)

    if df.empty:
        logger.warning("save_ohlcv called with empty DataFrame for %s — nothing written.", symbol)
        return filepath

    new_df = df.copy()

    # Merge with existing data if file exists
    if filepath.exists():
        existing_df = _read_csv_safe(filepath, symbol)
        if not existing_df.empty:
            combined = pd.concat([existing_df, new_df], ignore_index=True)
            combined = combined.drop_duplicates(subset=_TIMESTAMP_COL).sort_values(
                _TIMESTAMP_COL
            ).reset_index(drop=True)
            new_df = combined
            logger.debug(
                "Merged %d existing + %d new rows for %s → %d unique rows",
                len(existing_df), len(df), symbol, len(new_df),
            )

    new_df.to_csv(filepath, index=False)
    logger.info("Saved %d rows to %s", len(new_df), filepath)
    return filepath


def load_ohlcv(
    symbol: str,
    timeframe: str = "1d",
    data_dir: Path | None = None,
) -> pd.DataFrame:
    """
    Load OHLCV data from CSV for a given symbol.

    Args:
        symbol:    ccxt-format symbol string, e.g. "BTC/USDT"
        timeframe: ccxt timeframe string, e.g. "1d"
        data_dir:  Override data directory (defaults to config/settings.DATA_DIR)

    Returns:
        DataFrame with UTC timezone-aware timestamps, sorted ascending.
        Returns an empty DataFrame if no file exists (caller should handle).
    """
    if data_dir is None:
        from config.settings import DATA_DIR
        data_dir = DATA_DIR

    filepath = Path(data_dir) / _symbol_to_filename(symbol, timeframe)

    if not filepath.exists():
        logger.warning(
            "No local data found for %s (%s) at %s. Run data pipeline to fetch.",
            symbol, timeframe, filepath,
        )
        return _empty_df()

    df = _read_csv_safe(filepath, symbol)
    logger.info("Loaded %d rows for %s from %s", len(df), symbol, filepath)
    return df


# ── Helpers ────────────────────────────────────────────────────────────────────

def _read_csv_safe(filepath: Path, symbol: str) -> pd.DataFrame:
    """Read a CSV and parse timestamps safely, returning empty DF on error."""
    try:
        df = pd.read_csv(
            filepath,
            parse_dates=[_TIMESTAMP_COL],
        )
        # Ensure timestamp is UTC timezone-aware (CSV may strip tz on write)
        if df[_TIMESTAMP_COL].dt.tz is None:
            df[_TIMESTAMP_COL] = df[_TIMESTAMP_COL].dt.tz_localize("UTC")
        else:
            df[_TIMESTAMP_COL] = df[_TIMESTAMP_COL].dt.tz_convert("UTC")

        df = df.sort_values(_TIMESTAMP_COL).reset_index(drop=True)
        return df
    except Exception as exc:  # noqa: BLE001
        logger.error("Failed to read OHLCV CSV for %s at %s: %s", symbol, filepath, exc)
        return _empty_df()


def _empty_df() -> pd.DataFrame:
    """Return an empty DataFrame with the correct OHLCV schema."""
    from src.data_pipeline.fetcher import OHLCV_COLUMNS
    df = pd.DataFrame(columns=OHLCV_COLUMNS)
    df[_TIMESTAMP_COL] = pd.to_datetime(df[_TIMESTAMP_COL], utc=True)
    return df
