"""
src/data_pipeline/fetcher.py

Fetches daily OHLCV candles for configured symbols from Binance via ccxt.

Design notes:
- Uses Binance production endpoint for historical data (testnet has limited history).
- All timestamps are normalised to UTC timezone-aware pandas Timestamps.
- After fetching, gap detection is run automatically; callers get clean data or
  an explicit warning — never silently incomplete data.
- No API keys are required for public OHLCV endpoints; auth is only needed for
  order placement (src/execution/).

Usage:
    from src.data_pipeline import fetch_ohlcv
    df = fetch_ohlcv("BTC/USDT", lookback_days=365)
"""

from __future__ import annotations

import time
from datetime import datetime, timezone, timedelta
from typing import Optional

import ccxt
import pandas as pd

from src.logger import get_logger
from src.data_pipeline.gap_detector import detect_gaps

logger = get_logger(__name__)

# ── Column names used throughout the project ──────────────────────────────────
OHLCV_COLUMNS = ["timestamp", "open", "high", "low", "close", "volume"]

# Binance production REST (for historical data; testnet has sparse history)
_BINANCE_PRODUCTION_REST = "https://api.binance.com"

# Max candles per ccxt fetch call (Binance limit: 1000 per request)
_MAX_FETCH_LIMIT = 1000


def _build_exchange(use_testnet: bool = False) -> ccxt.binance:
    """
    Build and return a ccxt Binance exchange instance.

    Args:
        use_testnet: If True, targets testnet.binance.vision (limited OHLCV history).
                     If False (default), targets production API for historical data.
                     No API keys are needed for public OHLCV endpoints.
    """
    options: dict = {
        "defaultType": "spot",
    }
    if use_testnet:
        options["urls"] = {
            "api": {
                "public": "https://testnet.binance.vision/api",
                "private": "https://testnet.binance.vision/api",
            }
        }
        logger.debug("Exchange configured for Binance Spot Testnet")
    else:
        logger.debug("Exchange configured for Binance production (OHLCV only, no auth)")

    return ccxt.binance({"options": options})


def fetch_ohlcv(
    symbol: str,
    timeframe: str = "1d",
    lookback_days: int = 365,
    since: Optional[datetime] = None,
    use_testnet: bool = False,
) -> pd.DataFrame:
    """
    Fetch OHLCV candles for a single symbol.

    Args:
        symbol:       ccxt-format symbol, e.g. "BTC/USDT"
        timeframe:    ccxt timeframe string, e.g. "1d"
        lookback_days: Number of calendar days to look back from now (ignored if `since` given)
        since:        Optional explicit UTC start datetime; overrides lookback_days
        use_testnet:  If True, fetches from testnet (sparse history; for integration testing only)

    Returns:
        DataFrame with columns [timestamp, open, high, low, close, volume]
        - timestamp is a UTC timezone-aware pandas Timestamp (not a plain integer)
        - Rows are sorted ascending by timestamp
        - DataFrame is NEVER returned with known gaps; gaps trigger a logged WARNING

    Raises:
        ccxt.NetworkError: On connectivity failures (not caught here; propagate to caller)
        ccxt.ExchangeError: On API-level errors
    """
    exchange = _build_exchange(use_testnet=use_testnet)

    # Determine start time
    if since is not None:
        since_ms = int(since.timestamp() * 1000)
    else:
        start_dt = datetime.now(tz=timezone.utc) - timedelta(days=lookback_days)
        since_ms = int(start_dt.timestamp() * 1000)

    logger.info(
        "Fetching OHLCV | symbol=%s | timeframe=%s | since=%s",
        symbol,
        timeframe,
        datetime.fromtimestamp(since_ms / 1000, tz=timezone.utc).isoformat(),
    )

    all_candles: list[list] = []
    fetch_since_ms = since_ms

    while True:
        try:
            candles = exchange.fetch_ohlcv(
                symbol,
                timeframe=timeframe,
                since=fetch_since_ms,
                limit=_MAX_FETCH_LIMIT,
            )
        except ccxt.NetworkError as exc:
            logger.error("Network error fetching %s OHLCV: %s", symbol, exc)
            raise
        except ccxt.ExchangeError as exc:
            logger.error("Exchange error fetching %s OHLCV: %s", symbol, exc)
            raise

        if not candles:
            break

        all_candles.extend(candles)

        # If fewer than the limit were returned, we've reached the present
        if len(candles) < _MAX_FETCH_LIMIT:
            break

        # Advance cursor to just after the last returned candle
        fetch_since_ms = candles[-1][0] + 1

        # Polite rate-limit pause (Binance weight budget)
        time.sleep(0.25)

    if not all_candles:
        logger.warning("No OHLCV data returned for %s (timeframe=%s)", symbol, timeframe)
        return _empty_ohlcv_df()

    df = _candles_to_dataframe(all_candles, symbol)

    logger.info(
        "Fetched %d candles for %s | range: %s → %s",
        len(df),
        symbol,
        df["timestamp"].iloc[0].isoformat(),
        df["timestamp"].iloc[-1].isoformat(),
    )

    # ── Gap detection (always run; never silently skip) ───────────────────────
    gaps = detect_gaps(df, timeframe=timeframe, symbol=symbol)
    if gaps:
        logger.warning(
            "GAP DETECTED in %s OHLCV data: %d missing candle(s). "
            "Inspect gaps before proceeding. Details: %s",
            symbol,
            len(gaps),
            gaps,
        )
    else:
        logger.info("No gaps detected in %s OHLCV data.", symbol)

    return df


def fetch_all_symbols(
    symbols: list[str],
    timeframe: str = "1d",
    lookback_days: int = 365,
) -> dict[str, pd.DataFrame]:
    """
    Fetch OHLCV for multiple symbols. Returns a dict keyed by symbol.

    Args:
        symbols: List of ccxt-format symbols, e.g. ["BTC/USDT", "ETH/USDT"]
        timeframe: ccxt timeframe string
        lookback_days: Calendar days of history to fetch

    Returns:
        Dict mapping symbol → DataFrame (same format as fetch_ohlcv)
    """
    result: dict[str, pd.DataFrame] = {}
    for symbol in symbols:
        result[symbol] = fetch_ohlcv(symbol, timeframe=timeframe, lookback_days=lookback_days)
    return result


# ── Helpers ────────────────────────────────────────────────────────────────────

def _candles_to_dataframe(candles: list[list], symbol: str) -> pd.DataFrame:
    """
    Convert raw ccxt OHLCV list-of-lists into a clean, UTC-normalised DataFrame.

    ccxt returns timestamps as Unix milliseconds (int). We convert to
    timezone-aware UTC pandas Timestamps so that all downstream code is
    unambiguously in UTC — no silent local-time bugs.
    """
    df = pd.DataFrame(candles, columns=OHLCV_COLUMNS)

    # Convert ms int → UTC Timestamp
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)

    # Enforce correct dtypes
    for col in ["open", "high", "low", "close", "volume"]:
        df[col] = df[col].astype(float)

    # Remove any duplicate timestamps (rare but possible with pagination edge cases)
    before = len(df)
    df = df.drop_duplicates(subset="timestamp").reset_index(drop=True)
    after = len(df)
    if before != after:
        logger.warning(
            "%s: Dropped %d duplicate timestamp(s) during OHLCV normalisation",
            symbol,
            before - after,
        )

    df = df.sort_values("timestamp").reset_index(drop=True)
    return df


def _empty_ohlcv_df() -> pd.DataFrame:
    """Return an empty DataFrame with the correct OHLCV schema."""
    df = pd.DataFrame(columns=OHLCV_COLUMNS)
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    return df
