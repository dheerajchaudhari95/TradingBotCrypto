"""
src/data_pipeline/gap_detector.py

Detects missing candles in OHLCV DataFrames.

A "gap" is any expected candle timestamp that is absent from the data.
For daily data, we expect exactly one candle per UTC calendar day (00:00:00Z).

Design contract:
- This function NEVER silently proceeds. It returns a list of missing timestamps
  (empty list = no gaps). The CALLER is responsible for deciding what to do
  (log warning, abort, attempt backfill, etc.).
- The fetcher always calls this after a fetch; tests can call it directly.
"""

from __future__ import annotations

from typing import Union

import pandas as pd

from src.logger import get_logger

logger = get_logger(__name__)

# Mapping from ccxt/Binance timeframe strings to pandas frequency aliases
_TIMEFRAME_TO_PANDAS_FREQ: dict[str, str] = {
    "1m": "1min",
    "3m": "3min",
    "5m": "5min",
    "15m": "15min",
    "30m": "30min",
    "1h": "1h",
    "2h": "2h",
    "4h": "4h",
    "6h": "6h",
    "8h": "8h",
    "12h": "12h",
    "1d": "1D",
    "3d": "3D",
    "1w": "1W",
}


def detect_gaps(
    df: pd.DataFrame,
    timeframe: str = "1d",
    symbol: str = "",
) -> list[pd.Timestamp]:
    """
    Detect missing candles in an OHLCV DataFrame.

    Args:
        df:        DataFrame with a 'timestamp' column (UTC timezone-aware Timestamps).
                   Must be sorted ascending and have no NaN timestamps.
        timeframe: ccxt/Binance timeframe string (e.g. "1d", "4h").
                   Used to determine the expected interval between candles.
        symbol:    Symbol name for log messages (optional, improves log readability).

    Returns:
        List of missing UTC Timestamps. Empty list means no gaps found.

    Notes:
        - Weekly ("1w") candles are resampled from Monday to Monday; Binance weekly
          candles open on Monday 00:00 UTC. A small tolerance is applied.
        - The last candle in the sequence is the current (potentially open/incomplete)
          candle and is excluded from gap checking (it may not have closed yet).
        - If df has fewer than 2 rows, gap detection cannot run; returns empty list
          with an INFO log.
    """
    if "timestamp" not in df.columns:
        logger.error("[%s] Gap detector: DataFrame has no 'timestamp' column.", symbol)
        return []

    if len(df) < 2:
        logger.info(
            "[%s] Gap detector: Only %d row(s) — cannot detect gaps, need at least 2.",
            symbol,
            len(df),
        )
        return []

    freq = _TIMEFRAME_TO_PANDAS_FREQ.get(timeframe)
    if freq is None:
        logger.warning(
            "[%s] Gap detector: Unknown timeframe '%s'. Supported: %s. "
            "Skipping gap detection.",
            symbol,
            timeframe,
            list(_TIMEFRAME_TO_PANDAS_FREQ.keys()),
        )
        return []

    timestamps: pd.Series = df["timestamp"].sort_values().reset_index(drop=True)

    # Build the ideal sequence of timestamps over the same date range
    # We exclude the last actual timestamp from the expected range because the
    # current (open) candle might not have closed yet on the exchange.
    ideal_range = pd.date_range(
        start=timestamps.iloc[0],
        end=timestamps.iloc[-2],   # stop at second-to-last; last may be live
        freq=freq,
        tz="UTC",
    )

    # Normalise to UTC (should already be, but guard against naive timestamps)
    actual_set: set[pd.Timestamp] = set(timestamps[:-1].dt.normalize() if timeframe == "1d"
                                        else timestamps[:-1])
    ideal_set: set[pd.Timestamp] = set(ideal_range.normalize() if timeframe == "1d"
                                       else ideal_range)

    missing = sorted(ideal_set - actual_set)

    if missing:
        logger.warning(
            "[%s] %d missing candle(s) detected for timeframe '%s': %s",
            symbol,
            len(missing),
            timeframe,
            [str(ts) for ts in missing[:10]] + (["..."] if len(missing) > 10 else []),
        )
    else:
        logger.debug("[%s] Gap detection complete — no missing candles.", symbol)

    return missing
