"""
src/execution/symbol_rules.py — STUB

Fetch and cache symbol filter rules (tickSize, stepSize, minNotional) from
Binance at startup. See docs/exchange_notes.md Section 3 and 6 for background.

THIS MODULE IS A STUB. Full implementation in the NEXT prompt.
"""

from __future__ import annotations
from src.logger import get_logger

logger = get_logger(__name__)


def fetch_and_cache_rules(symbols: list[str]) -> dict:
    """
    Fetch symbol rules from Binance and cache to config/symbol_rules_cache.json.

    Must be called before any order is placed.
    NOT YET IMPLEMENTED.
    """
    raise NotImplementedError(
        "Symbol rules fetcher not yet implemented. "
        "Implement in the next prompt after scaffolding is verified."
    )
