"""
src/execution/broker.py — STUB

Order placement and reconciliation with Binance Spot Testnet.

THIS MODULE IS A STUB. Execution logic is implemented in the NEXT prompt.

CONTRACT:
- Uses src/strategy/ and src/risk/ for decisions — no independent logic here.
- Must call fetch_symbol_rules() at startup before any order placement.
- API keys are loaded from config/settings.py (which reads .env) — never hardcoded.
"""

from __future__ import annotations
from src.logger import get_logger

logger = get_logger(__name__)


def run_live_bot() -> None:
    """
    Main entry point for live execution on Binance Testnet.
    NOT YET IMPLEMENTED.
    """
    raise NotImplementedError(
        "Live execution not yet implemented. "
        "Implement in the next prompt after scaffolding is verified."
    )
