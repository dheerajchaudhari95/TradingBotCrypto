"""
src/logger.py — Shared logging configuration for all modules.

Usage in any module:
    from src.logger import get_logger
    logger = get_logger(__name__)

This sets up:
  - Console handler (INFO+)
  - Rotating file handler writing to logs/trading_bot.log (INFO+)
Both handlers use a consistent structured format.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path


def _build_formatter() -> logging.Formatter:
    return logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)-30s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%SZ",
    )


def _configure_root_logger(log_level: str, log_file: Path, max_bytes: int, backup_count: int) -> None:
    """
    Configure the root logger with a console handler and a rotating file handler.
    Called once at import time from the top-level entry point.
    Subsequent calls to get_logger() inherit this configuration.
    """
    root = logging.getLogger()

    # Don't reconfigure if already set up (e.g., during pytest runs)
    if root.handlers:
        return

    root.setLevel(log_level)
    formatter = _build_formatter()

    # ── Console handler ──────────────────────────────────────────────────────
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_handler.setFormatter(formatter)
    root.addHandler(console_handler)

    # ── Rotating file handler ────────────────────────────────────────────────
    log_file.parent.mkdir(parents=True, exist_ok=True)
    file_handler = RotatingFileHandler(
        filename=str(log_file),
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    file_handler.setLevel(log_level)
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)


def get_logger(name: str) -> logging.Logger:
    """
    Return a named logger. The logger inherits handlers from the root logger.

    If the root logger has not been configured yet (e.g., in tests or scripts
    that don't call setup_logging()), a NullHandler is added to suppress
    'No handlers could be found' warnings.
    """
    logger = logging.getLogger(name)
    if not logging.getLogger().handlers:
        logger.addHandler(logging.NullHandler())
    return logger


def setup_logging() -> None:
    """
    Convenience function to initialise logging from config/settings.py.
    Call once at the entry point of any script or the live bot.

    Example:
        from src.logger import setup_logging
        setup_logging()
    """
    # Import here to avoid circular imports at module level
    from config.settings import LOG_LEVEL, LOG_FILE, LOG_MAX_BYTES, LOG_BACKUP_COUNT

    _configure_root_logger(
        log_level=LOG_LEVEL,
        log_file=LOG_FILE,
        max_bytes=LOG_MAX_BYTES,
        backup_count=LOG_BACKUP_COUNT,
    )
