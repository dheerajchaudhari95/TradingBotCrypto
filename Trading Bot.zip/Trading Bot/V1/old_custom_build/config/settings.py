"""
config/settings.py — Centralised configuration loaded from .env

All other modules import from here; no module should call os.getenv() directly.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Locate and load the .env file (searches upward from this file's location)
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_ENV_FILE = _PROJECT_ROOT / ".env"

load_dotenv(dotenv_path=_ENV_FILE)


def _require(key: str) -> str:
    """Return an env var or raise a clear error at startup."""
    value = os.getenv(key)
    if not value:
        raise EnvironmentError(
            f"Required environment variable '{key}' is not set. "
            f"Copy .env.example to .env and fill in the value."
        )
    return value


# ── Binance Testnet ────────────────────────────────────────────────────────
BINANCE_TESTNET_API_KEY: str = _require("BINANCE_TESTNET_API_KEY")
BINANCE_TESTNET_SECRET: str = _require("BINANCE_TESTNET_SECRET")

BINANCE_TESTNET_REST_URL: str = "https://testnet.binance.vision"
BINANCE_TESTNET_WS_URL: str = "wss://ws-api.testnet.binance.vision/ws-api/v3"

# ── Instruments ────────────────────────────────────────────────────────────
_raw_symbols = os.getenv("SYMBOLS", "BTC/USDT,ETH/USDT")
SYMBOLS: list[str] = [s.strip() for s in _raw_symbols.split(",")]

TIMEFRAME: str = os.getenv("TIMEFRAME", "1d")
INITIAL_LOOKBACK_DAYS: int = int(os.getenv("INITIAL_LOOKBACK_DAYS", "365"))

# ── Storage ────────────────────────────────────────────────────────────────
DATA_BACKEND: str = os.getenv("DATA_BACKEND", "csv")  # "csv" or "sqlite"
DATA_DIR: Path = _PROJECT_ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)

CONFIG_DIR: Path = _PROJECT_ROOT / "config"
SYMBOL_RULES_CACHE: Path = CONFIG_DIR / "symbol_rules_cache.json"

# ── Logging ────────────────────────────────────────────────────────────────
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_DIR: Path = _PROJECT_ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE: Path = LOG_DIR / "trading_bot.log"
LOG_MAX_BYTES: int = 10 * 1024 * 1024  # 10 MB
LOG_BACKUP_COUNT: int = 5
