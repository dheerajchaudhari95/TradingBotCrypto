"""tests/conftest.py

Shared pytest fixtures and test configuration.
"""

import logging
import pandas as pd
import pytest


# Silence chatty loggers during tests (gaps produce expected WARNINGs in tests)
@pytest.fixture(autouse=True)
def configure_test_logging():
    """Reduce log noise during tests — WARNING+ only."""
    logging.getLogger("src").setLevel(logging.WARNING)
    yield


# ── Shared sample data fixtures ────────────────────────────────────────────────

def make_daily_ohlcv(dates: list[str]) -> pd.DataFrame:
    """
    Build a minimal OHLCV DataFrame from a list of ISO date strings.
    Timestamps are UTC timezone-aware at 00:00:00Z (midnight, as Binance daily candles are).
    """
    timestamps = pd.to_datetime(dates, utc=True)
    n = len(timestamps)
    return pd.DataFrame({
        "timestamp": timestamps,
        "open":   [100.0] * n,
        "high":   [110.0] * n,
        "low":    [90.0]  * n,
        "close":  [105.0] * n,
        "volume": [1000.0] * n,
    })


@pytest.fixture
def complete_7day_ohlcv() -> pd.DataFrame:
    """Seven consecutive daily candles with no gaps."""
    return make_daily_ohlcv([
        "2024-01-01", "2024-01-02", "2024-01-03",
        "2024-01-04", "2024-01-05", "2024-01-06", "2024-01-07",
    ])


@pytest.fixture
def gapped_ohlcv_single_gap() -> tuple[pd.DataFrame, list[str]]:
    """Six candles with 2024-01-04 deliberately missing."""
    df = make_daily_ohlcv([
        "2024-01-01", "2024-01-02", "2024-01-03",
        # 2024-01-04 is missing
        "2024-01-05", "2024-01-06", "2024-01-07",
    ])
    return df, ["2024-01-04"]


@pytest.fixture
def gapped_ohlcv_multiple_gaps() -> tuple[pd.DataFrame, list[str]]:
    """Five candles with 2024-01-03 and 2024-01-05 both missing."""
    df = make_daily_ohlcv([
        "2024-01-01", "2024-01-02",
        # 2024-01-03 missing
        "2024-01-04",
        # 2024-01-05 missing
        "2024-01-06", "2024-01-07",
    ])
    return df, ["2024-01-03", "2024-01-05"]
