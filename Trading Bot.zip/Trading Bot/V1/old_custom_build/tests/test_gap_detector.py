"""
tests/test_gap_detector.py

Unit tests for src/data_pipeline/gap_detector.py

Tests verify:
1. No gaps are detected on a complete dataset (no false positives)
2. A single deliberately missing day is correctly identified
3. Multiple missing days are all correctly identified
4. The function handles edge cases gracefully (< 2 rows, unknown timeframe)
5. Timestamps must be UTC timezone-aware (not naive)
"""

from __future__ import annotations

import pandas as pd
import pytest

from src.data_pipeline.gap_detector import detect_gaps


class TestDetectGaps:
    """Tests for the detect_gaps() function."""

    # ── Happy path ─────────────────────────────────────────────────────────────

    def test_no_gaps_returns_empty_list(self, complete_7day_ohlcv):
        """Complete consecutive dataset should return no gaps."""
        gaps = detect_gaps(complete_7day_ohlcv, timeframe="1d", symbol="BTC/USDT")
        assert gaps == [], (
            f"Expected no gaps in complete dataset but got: {gaps}"
        )

    def test_single_gap_detected(self, gapped_ohlcv_single_gap):
        """A single missing candle must be identified."""
        df, expected_missing = gapped_ohlcv_single_gap
        gaps = detect_gaps(df, timeframe="1d", symbol="BTC/USDT")

        assert len(gaps) == 1, f"Expected 1 gap, got {len(gaps)}: {gaps}"

        gap_dates = [str(g.date()) for g in gaps]
        assert gap_dates == expected_missing, (
            f"Wrong gap dates. Expected {expected_missing}, got {gap_dates}"
        )

    def test_multiple_gaps_all_detected(self, gapped_ohlcv_multiple_gaps):
        """All missing candles in a multi-gap dataset must be detected."""
        df, expected_missing = gapped_ohlcv_multiple_gaps
        gaps = detect_gaps(df, timeframe="1d", symbol="ETH/USDT")

        assert len(gaps) == len(expected_missing), (
            f"Expected {len(expected_missing)} gaps, got {len(gaps)}: {gaps}"
        )

        gap_dates = sorted([str(g.date()) for g in gaps])
        assert gap_dates == sorted(expected_missing), (
            f"Wrong gap dates. Expected {expected_missing}, got {gap_dates}"
        )

    # ── Edge cases ─────────────────────────────────────────────────────────────

    def test_single_row_returns_empty(self):
        """Only one row: cannot determine gaps, should return empty list without error."""
        df = pd.DataFrame({
            "timestamp": pd.to_datetime(["2024-01-01"], utc=True),
            "open": [100.0], "high": [110.0], "low": [90.0],
            "close": [105.0], "volume": [1000.0],
        })
        gaps = detect_gaps(df, timeframe="1d")
        assert gaps == [], "Single-row DataFrame should return empty gaps list"

    def test_empty_dataframe_returns_empty(self):
        """Empty DataFrame should return empty list without raising."""
        df = pd.DataFrame(columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        gaps = detect_gaps(df, timeframe="1d")
        assert gaps == [], "Empty DataFrame should return empty gaps list"

    def test_missing_timestamp_column(self):
        """DataFrame without 'timestamp' column should return empty list, not raise."""
        df = pd.DataFrame({"close": [100.0, 101.0]})
        gaps = detect_gaps(df, timeframe="1d")
        assert gaps == [], "Missing timestamp column should return empty list"

    def test_unknown_timeframe_returns_empty(self, complete_7day_ohlcv):
        """Unsupported timeframe string should return empty list with a warning."""
        gaps = detect_gaps(complete_7day_ohlcv, timeframe="1y")
        assert gaps == [], "Unknown timeframe should return empty list"

    def test_two_row_no_gap(self):
        """Exactly two consecutive days: second row is the 'live' candle, no gap possible."""
        df = pd.DataFrame({
            "timestamp": pd.to_datetime(["2024-01-01", "2024-01-02"], utc=True),
            "open": [100.0, 100.0], "high": [110.0, 110.0],
            "low": [90.0, 90.0], "close": [105.0, 105.0], "volume": [1000.0, 1000.0],
        })
        gaps = detect_gaps(df, timeframe="1d")
        assert gaps == [], "Two consecutive rows should not produce a gap"

    # ── Data integrity ─────────────────────────────────────────────────────────

    def test_utc_aware_timestamps_accepted(self):
        """UTC timezone-aware timestamps should work without errors."""
        df = pd.DataFrame({
            "timestamp": pd.to_datetime(
                ["2024-01-01", "2024-01-02", "2024-01-03", "2024-01-04", "2024-01-05"],
                utc=True
            ),
            "open": [100.0] * 5, "high": [110.0] * 5,
            "low": [90.0] * 5, "close": [105.0] * 5, "volume": [1000.0] * 5,
        })
        # Should not raise; result is an empty list (no gaps)
        gaps = detect_gaps(df, timeframe="1d")
        assert isinstance(gaps, list)

    def test_gap_in_middle_of_large_dataset(self):
        """Regression: gap in middle of a larger sequence is not missed."""
        # Build 30 days, remove day 15
        dates = pd.date_range("2024-01-01", periods=30, freq="1D", tz="UTC")
        dates_with_gap = dates.delete(14)  # Remove index 14 = 2024-01-15

        df = pd.DataFrame({
            "timestamp": dates_with_gap,
            "open": [100.0] * len(dates_with_gap),
            "high": [110.0] * len(dates_with_gap),
            "low": [90.0]  * len(dates_with_gap),
            "close": [105.0] * len(dates_with_gap),
            "volume": [1000.0] * len(dates_with_gap),
        })

        gaps = detect_gaps(df, timeframe="1d", symbol="BTC/USDT")
        assert len(gaps) == 1, f"Expected exactly 1 gap, got {len(gaps)}: {gaps}"
        assert str(gaps[0].date()) == "2024-01-15", (
            f"Expected gap on 2024-01-15, got {gaps[0].date()}"
        )
