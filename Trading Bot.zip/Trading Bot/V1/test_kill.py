import urllib.request, json, base64

def run():
    creds = base64.b64encode(b'freqtrade:change_before_live').decode()
    req = urllib.request.Request('http://localhost:8080/api/v1/token/login', method='POST', headers={'Authorization': f'Basic {creds}'})
    r = urllib.request.urlopen(req)
    token = json.loads(r.read())['access_token']

    print('--- STOPBUY ---')
    try:
        req2 = urllib.request.Request('http://localhost:8080/api/v1/stopbuy', method='POST', headers={'Authorization': f'Bearer {token}'})
        print(urllib.request.urlopen(req2).read().decode())
    except Exception as e:
        print('Error:', e)

    print('--- FORCEEXIT ---')
    try:
        req3 = urllib.request.Request('http://localhost:8080/api/v1/forceexit', method='POST', headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}, data=b'{"tradeid":"all"}')
        print(urllib.request.urlopen(req3).read().decode())
    except Exception as e:
        print('Error:', e)

    print('--- RELOAD CONFIG (TO RESUME) ---')
    try:
        req4 = urllib.request.Request('http://localhost:8080/api/v1/reload_config', method='POST', headers={'Authorization': f'Bearer {token}'})
        print(urllib.request.urlopen(req4).read().decode())
    except Exception as e:
        print('Error:', e)

run()
