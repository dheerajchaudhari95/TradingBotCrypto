# Binance Spot Testnet — Exchange Notes

**Research date:** 2026-09-15  
**Source:** Live API call to `https://testnet.binance.vision/api/v3/exchangeInfo?symbols=["BTCUSDT","ETHUSDT"]`  
**Testnet base URL:** `https://testnet.binance.vision`  
**Testnet WS base URL:** `wss://ws-api.testnet.binance.vision/ws-api/v3`

All findings below are based on direct HTTP responses from the testnet endpoint — not assumed from production docs.

---

## 1. OCO Order Support

**Status: CONFIRMED SUPPORTED on Spot Testnet.**

The `exchangeInfo` response for both BTCUSDT and ETHUSDT includes:

```json
"ocoAllowed": true,
"otoAllowed": true,
"opoAllowed": true
```

### OCO Endpoint Changes (Important)

The old endpoint `POST /api/v3/order/oco` is **deprecated and may be removed**. The current endpoint is:

- **`POST /api/v3/orderList/oco`** — standard OCO (stop-loss + take-profit pair)
- **`POST /api/v3/orderList/oto`** — One-Triggers-the-Other (OTO)
- **`POST /api/v3/orderList/otoco`** — One-Triggers-a-One-Cancels-the-Other (OTOCO)

### OCO Order Structure

An OCO requires **two linked orders**:
- **"Above" order:** `LIMIT_MAKER`, `TAKE_PROFIT`, or `TAKE_PROFIT_LIMIT`
- **"Below" order:** `STOP_LOSS` or `STOP_LOSS_LIMIT`

Price constraint (SELL OCO):
- `LIMIT_MAKER` / `TAKE_PROFIT_LIMIT` price > Last Traded Price > `STOP_LOSS` stopPrice

---

## 2. Supported Order Types (Both Symbols)

Confirmed from the `orderTypes` array in the live `exchangeInfo` response:

| Order Type | Supported |
|---|---|
| `LIMIT` | ✅ Yes |
| `LIMIT_MAKER` | ✅ Yes |
| `MARKET` | ✅ Yes |
| `STOP_LOSS` | ✅ Yes |
| `STOP_LOSS_LIMIT` | ✅ Yes |
| `TAKE_PROFIT` | ✅ Yes |
| `TAKE_PROFIT_LIMIT` | ✅ Yes |

Additional flags confirmed on both symbols:
- `allowTrailingStop: true`
- `cancelReplaceAllowed: true`
- `isMarginTradingAllowed: false` (Spot only, as expected)

---

## 3. Symbol Filter Rules

Rules fetched directly from testnet `exchangeInfo` on 2026-09-15.

> ⚠️ **Do NOT hardcode these values.** Binance updates filter values periodically.  
> The bot must call `GET /api/v3/exchangeInfo?symbols=["BTCUSDT","ETHUSDT"]` at startup  
> and cache results for the session. See `src/execution/` for the runtime fetcher.

### BTCUSDT

| Filter | Parameter | Value |
|---|---|---|
| `PRICE_FILTER` | `tickSize` | `0.01` |
| `PRICE_FILTER` | `minPrice` | `0.01` |
| `PRICE_FILTER` | `maxPrice` | `1,000,000.00` |
| `LOT_SIZE` | `stepSize` | `0.00001` (i.e., 5 decimal places) |
| `LOT_SIZE` | `minQty` | `0.00001` |
| `LOT_SIZE` | `maxQty` | `9,000.00` |
| `NOTIONAL` | `minNotional` | `5.00 USDT` |
| `NOTIONAL` | `maxNotional` | `9,000,000.00 USDT` |
| `NOTIONAL` | `applyMinToMarket` | `true` |

### ETHUSDT

| Filter | Parameter | Value |
|---|---|---|
| `PRICE_FILTER` | `tickSize` | `0.01` |
| `PRICE_FILTER` | `minPrice` | `0.01` |
| `PRICE_FILTER` | `maxPrice` | `1,000,000.00` |
| `LOT_SIZE` | `stepSize` | `0.0001` (i.e., 4 decimal places) |
| `LOT_SIZE` | `minQty` | `0.0001` |
| `LOT_SIZE` | `maxQty` | `9,000.00` |
| `NOTIONAL` | `minNotional` | `5.00 USDT` |
| `NOTIONAL` | `maxNotional` | `9,000,000.00 USDT` |
| `NOTIONAL` | `applyMinToMarket` | `true` |

**Key difference:** BTC has 5 decimal places for quantity, ETH has 4. Do not assume they are the same.

### Filter Notes

- The old `MIN_NOTIONAL` filter type has been replaced by `NOTIONAL` on these symbols. The `minNotional` field still exists within it but the filter type name changed. Always parse by `filterType` key, not by position in the array.
- Use Python's `decimal.Decimal` (not `float`) when applying tick/step rounding to avoid floating-point precision bugs.
- Rounding rule: quantity = `floor(raw_qty / stepSize) * stepSize` (always round **down** to avoid over-ordering).

---

## 4. Rate Limits (from testnet response)

| Type | Interval | Limit |
|---|---|---|
| `REQUEST_WEIGHT` | 1 minute | 6,000 |
| `ORDERS` | 10 seconds | 50 |
| `ORDERS` | 1 day | 160,000 |
| `RAW_REQUESTS` | 5 minutes | 300,000 |

`GET /api/v3/exchangeInfo` costs **weight 20** per call. Cache the result at startup; do not call per-order.

---

## 5. Open Questions / Uncertainties

1. **NOTIONAL filter `avgPriceMins: 5`** — minNotional is evaluated against the 5-minute average price, not the last price, for market orders. Exact behavior when avgPrice is unavailable (market open gap) is not confirmed. The bot should add a small safety buffer above the absolute minimum.

2. **OCO endpoint version parity** — The deprecated `POST /api/v3/order/oco` endpoint may still work on testnet as of this writing but is not guaranteed. The bot will use only the current `POST /api/v3/orderList/oco` endpoint. If `ccxt` sends requests to the old endpoint internally, this must be patched via ccxt's `options` override. **Verify the version of ccxt used and whether it has been updated to use the new endpoint before implementing order placement.**

3. **Testnet liquidity** — The testnet order book may have thin or synthetic liquidity. For daily-candle swing trading this is unlikely to matter (we'll use close-price MARKET orders or LIMIT orders at prior close), but large simulated positions could have unrealistic fills. Flag this as a known limitation in backtest reports.

4. **`MAX_NUM_ORDER_LISTS: 20`** — Maximum concurrent OCO/OTO lists per symbol. For a 2-instrument bot this is unlikely to be hit, but should be enforced as a circuit breaker guard.

---

## 6. Programmatic Fetch Snippet (reference)

```python
# src/execution/symbol_rules.py  (skeleton — do not implement yet)
# Fetch at startup, cache in config/symbol_rules_cache.json

import ccxt

def fetch_symbol_rules(exchange: ccxt.Exchange, symbols: list[str]) -> dict:
    """
    Returns parsed filter rules for each symbol.
    Must be called at startup before any order placement.
    """
    markets = exchange.load_markets()
    rules = {}
    for symbol in symbols:
        market = markets[symbol]
        rules[symbol] = {
            "tick_size":     market["precision"]["price"],
            "step_size":     market["precision"]["amount"],
            "min_notional":  market["limits"]["cost"]["min"],
            "min_qty":       market["limits"]["amount"]["min"],
            "max_qty":       market["limits"]["amount"]["max"],
        }
    return rules
```

> **Note:** ccxt abstracts the raw filter parsing. Verify that the values ccxt returns match the raw `exchangeInfo` values shown in Section 3 during integration testing.
