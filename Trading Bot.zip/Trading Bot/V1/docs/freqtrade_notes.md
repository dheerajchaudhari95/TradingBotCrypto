# Freqtrade — Implementation Notes

**Research date:** 2026-09-15  
**Sources:** Live reads of freqtrade.io/en/stable/ (strategy-customization, strategy-callbacks, stoploss, installation pages) + verified against official GitHub repo examples.  
**Standard:** Same as exchange_notes.md — no fabricated answers; uncertainties are flagged explicitly.

---

## 1. IStrategy Interface — Current Version and Required Methods

### Interface Version

**`INTERFACE_VERSION = 3`** is the current required version (as of Freqtrade stable 2024–2025).

Setting `INTERFACE_VERSION = 3` is **mandatory** in every strategy class. It enables modern features including the `enter_long`/`exit_long` column naming convention. Older versions used `buy`/`sell` column names which are no longer supported in current Freqtrade.

### Required Strategy Class Attributes

```python
class MyStrategy(IStrategy):
    INTERFACE_VERSION = 3      # mandatory
    timeframe = "1d"           # candle timeframe
    stoploss = -0.10           # mandatory fallback (even when using custom_stoploss)
    minimal_roi = {"0": 0.10}  # mandatory; can disable with {"0": 100} if using custom exits
    use_custom_stoploss = True  # set True to enable custom_stoploss callback
```

### Required Methods

All three methods below **must** be implemented. Freqtrade will error at startup if any is missing.

#### `populate_indicators(dataframe: DataFrame, metadata: dict) -> DataFrame`

- Add technical indicator columns to `dataframe`
- Use `ta-lib`, `pandas-ta`, or plain pandas math
- Only add indicators you actually use (performance)
- Returns the modified `dataframe`

#### `populate_entry_trend(dataframe: DataFrame, metadata: dict) -> DataFrame`

- Sets `dataframe['enter_long'] = 1` where entry condition is met, else `0`
- Optionally sets `dataframe['enter_tag']` = string label for the signal
- No short entries in this v1 strategy (long-only)
- Returns the modified `dataframe`

#### `populate_exit_trend(dataframe: DataFrame, metadata: dict) -> DataFrame`

- Sets `dataframe['exit_long'] = 1` where exit condition is met, else `0`
- Optionally sets `dataframe['exit_tag']` = string label
- Returns the modified `dataframe`

---

## 2. `custom_stoploss` Callback

### Enabling

Must set class attribute:
```python
use_custom_stoploss = True
```

The class-level `stoploss` attribute (e.g., `stoploss = -0.20`) must still be defined even when `use_custom_stoploss = True`. It acts as a **hard floor** — if the custom callback returns a value looser than the class-level stoploss, Freqtrade uses the class-level value. If the callback fails or returns `None`, the class-level stoploss is used as fallback.

### Method Signature

```python
def custom_stoploss(
    self,
    pair: str,
    trade: "Trade",
    current_time: datetime,
    current_rate: float,
    current_profit: float,
    **kwargs,              # mandatory — ensures forward compatibility
) -> float:
```

**Parameters:**
- `pair` — symbol string, e.g. `"BTC/USDT"`
- `trade` — Trade object (see `freqtrade.persistence.Trade`)
- `current_time` — `datetime` object (use this, never `datetime.now()`, for backtest compatibility)
- `current_rate` — current close price
- `current_profit` — current unrealised profit as a ratio (e.g., 0.05 = +5%)

**Return value:**
- A **negative float** representing the stoploss as a ratio **relative to `current_rate`**
- Example: return `-0.05` to place stop 5% below current price
- **Stoploss can only move upward (trail)** — if you return a value that would lower the existing stoploss, Freqtrade ignores it
- Return `self.stoploss` (the class-level value) if you want to fall back to the static stop

### Accessing ATR in the Callback

```python
def custom_stoploss(self, pair, trade, current_time, current_rate, current_profit, **kwargs):
    dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
    if dataframe.empty:
        return self.stoploss  # fallback to static stop
    last_candle = dataframe.iloc[-1].squeeze()
    atr = last_candle["atr"]
    # e.g., stop = 2 × ATR below current price
    atr_stop = -(atr * 2.0) / current_rate
    return max(atr_stop, self.stoploss)  # never loosen below class-level floor
```

**Important constraints confirmed from docs:**
- `self.dp` (DataProvider) is required — it's injected by Freqtrade at runtime
- `get_analyzed_dataframe()` returns the last complete candle's DataFrame; in backtesting, it correctly returns only data available at `current_time` (no lookahead)
- Do NOT use `datetime.now()` anywhere in callbacks — always use `current_time`

### `trailing_stop` vs `custom_stoploss`

Do **not** combine `trailing_stop = True` (config) with `use_custom_stoploss = True` — they conflict. Use one or the other.

---

## 3. `minimal_roi` — Best Practice with Custom Exits

### What it does

`minimal_roi` is a time-based take-profit table. Format:
```python
minimal_roi = {
    "0":   0.10,   # exit if profit ≥ 10% at any point
    "1440": 0.05,  # exit if profit ≥ 5% after 1440 minutes (1 day)
    "2880": 0.02,  # exit if profit ≥ 2% after 2 days
}
```
Keys are **minutes since trade open** (as strings).

### When using custom exits via `populate_exit_trend`

- `minimal_roi` acts **independently** of `populate_exit_trend` — either condition can trigger an exit
- Both can be active simultaneously; whichever fires first wins
- **Best practice:** Define `minimal_roi` even if you rely primarily on signal exits. It provides a safety net for trades that go profitable but then stall without generating an exit signal
- To **effectively disable** ROI exits (rely only on signals + stoploss): `minimal_roi = {"0": 100}` — a 10,000% ROI target that will never be hit in practice

### Recommendation for this strategy

Since we use ATR-based custom_stoploss (trailing) and EMA crossover exits, the `minimal_roi` acts as a time-based safety net. Set it conservatively (e.g., exit any trade profitable by ≥15% after 30 days) to avoid holding large gains that then reverse past the EMA exit.

---

## 4. Installation on Windows — Decision

### Summary

| Method | Freqtrade Recommendation | Notes |
|---|---|---|
| **Docker** | ✅ **Primary recommended** | Pre-built image, all deps (ta-lib) bundled, production-consistent |
| WSL2 | Secondary option | Good but more setup steps |
| Native venv | Not recommended | ta-lib binary compilation issues, Python version conflicts |

### Decision: **Docker**

**Rationale specific to this project:**

1. **Python version incompatibility:** The system Python is 3.14.3. Freqtrade officially supports Python 3.10–3.12. Native installation would fail immediately due to dependency constraints (especially `ta-lib` which requires compiled C libraries).

2. **Docker is available:** `docker --version` → `Docker version 29.4.2` is installed and accessible. No additional infrastructure cost.

3. **ta-lib:** Freqtrade depends on `ta-lib` (a C library for technical indicators). On Windows, compiling ta-lib natively requires MSVC build tools and is a common failure point. The official Docker image has ta-lib pre-compiled.

4. **Backtesting consistency:** Freqtrade's Docker image exactly matches the production environment. Any backtest result is reproducible in the same container.

5. **The official Freqtrade install script** (`install_freqtrade.sh`) targets Linux/macOS. Windows users are explicitly directed to Docker in the docs.

**Limitation:** Docker adds a small overhead for CLI commands (container startup ~2-5s). For daily-candle backtesting this is completely negligible.

### Installation Commands Used

```bash
# Pull official image
docker pull freqtradeorg/freqtrade:stable

# Create userdir (run from project root)
docker run --rm -v "${PWD}/user_data:/freqtrade/user_data" freqtradeorg/freqtrade:stable create-userdir --userdir /freqtrade/user_data

# New config
docker run --rm -it -v "${PWD}/user_data:/freqtrade/user_data" freqtradeorg/freqtrade:stable new-config --config /freqtrade/user_data/config.json
```

---

## 5. `stake_amount` Reasoning

### Fixed-Fractional Position Sizing in Freqtrade

Freqtrade's `stake_amount` config is the amount of stake currency (USDT) **per trade**, not a fraction of equity. It does not natively perform fixed-fractional risk-based sizing that accounts for stop-loss distance.

Two approaches:

**Option A — Static stake per trade (simpler, used for v1):**
- `stake_amount = 495` (≈ half of 1000 USDT wallet, 2 open trades, slight buffer)
- With 2 max open trades and 1000 USDT dry-run wallet: each trade gets ~495 USDT
- **Risk at stop:** With a 2×ATR stop (historically ~4–8% on BTC daily), max loss per trade is ~20–40 USDT (2–4% of wallet). Acceptable for v1.

**Option B — Dynamic sizing (requires `custom_stake_amount` callback):**
- Implement `custom_stake_amount()` in the strategy to compute `equity × risk_pct / stop_distance`
- More precise but adds complexity for v1

**Decision for v1:** Use static `stake_amount = 480` (leave ~4% buffer in wallet for fees/slippage), document that true fixed-fractional sizing is deferred to the `custom_stake_amount` callback in v2.

**Calculation:**
- Wallet: 1000 USDT
- Max open trades: 2
- Per-trade allocation: 1000 / 2 = 500 USDT theoretical max
- Reserve buffer (fees, rounding): 500 × 0.96 = 480 USDT
- Effective risk per trade: if stoploss = -10% (2×ATR floor), max loss = 48 USDT = 4.8% of wallet

---

## 6. Open Questions / Uncertainties

1. **`custom_stoploss` in backtesting precision:** The docs state that `get_analyzed_dataframe()` returns only data available at `current_time` in backtesting, preventing lookahead bias. However, for daily candles, there is an inherent 1-candle lag — the ATR from the close of day N is used to set the stop for trades during day N+1. This is correct behavior (you can't know the day's close until it happens), but it means the trailing stop always lags one full day. Flag this in backtest report review.

2. **`dp` (DataProvider) availability in backtesting:** The `DataProvider.get_analyzed_dataframe()` call in `custom_stoploss` is confirmed supported in backtesting as of Freqtrade stable. This is worth testing explicitly with `--export trades` and inspecting stoploss trigger prices.

3. **Freqtrade version and ta-lib in Docker:** The `freqtradeorg/freqtrade:stable` tag is used. Verify the actual Freqtrade version in the container with `freqtrade --version` after pulling. If `stable` tag is updated between sessions, behavior could change. Pin to a specific version tag (e.g., `freqtradeorg/freqtrade:2025.1`) for production.

4. **Binance dry-run data source:** In dry-run mode, Freqtrade fetches live OHLCV from the exchange's production API (not testnet) for price data, but does NOT place real orders. This is the correct configuration for paper trading.
