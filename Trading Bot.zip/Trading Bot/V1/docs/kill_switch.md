# Trading Bot Kill-Switch Procedure

This document outlines the procedure to instantly halt trading and exit all open positions in an emergency, using Freqtrade's native REST API.

**Prerequisites:** 
The REST API is currently configured in `user_data/config.json` referencing environment variables. Ensure these are set in your environment or `.env` file (see `.env.example`):
- **Username:** `${FREQTRADE_API_USERNAME}` (e.g., `freqtrade`)
- **Password:** `${FREQTRADE_API_PASSWORD}` (make sure to change this before going live)
- **Address:** `http://127.0.0.1:8080` (or your server's IP)

---

## Method 1: Using FreqUI (Recommended)
If you have FreqUI enabled and are logged into the dashboard in your browser:
1. Navigate to your Freqtrade dashboard.
2. Toggle the **"Stop Buy"** switch at the top to prevent any new trades from opening.
3. To immediately liquidate all open positions, select **"Force Exit"** -> **"All"** from the Trade view.

---

## Method 2: Command Line (REST API)
If you do not have FreqUI open and need to execute this from the server's command line, you must first authenticate, then issue the force-exit command.

### Step 1: Authenticate and get JWT Token
```bash
# Request login token
curl -s -X POST "http://127.0.0.1:8080/api/v1/token/login" \
  -H "Authorization: Basic $(echo -n "${FREQTRADE_API_USERNAME}:${FREQTRADE_API_PASSWORD}" | base64)"
```
*Copy the `access_token` string from the JSON response.*

### Step 2: Stop buying new trades
```bash
curl -X POST "http://127.0.0.1:8080/api/v1/stopbuy" \
  -H "Authorization: Bearer <YOUR_ACCESS_TOKEN>"
```

### Step 3: Force exit all open positions
```bash
curl -X POST "http://127.0.0.1:8080/api/v1/forceexit" \
  -H "Authorization: Bearer <YOUR_ACCESS_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"tradeid":"all"}'
```
*(Freqtrade will immediately issue market or limit exit orders for all open trades depending on your exit order configuration.)*

### Step 4: Resume trading (when safe)
After the emergency has passed, you can re-enable the bot's ability to enter new positions:
```bash
curl -X POST "http://127.0.0.1:8080/api/v1/start" \
  -H "Authorization: Bearer <YOUR_ACCESS_TOKEN>"
```

---

## What the Protections Property Does
In addition to this manual kill-switch, `EmaAtrTrend.py` is configured with native Freqtrade Protections to automatically halt trading under severe conditions:
- **CooldownPeriod:** Prevents re-entering a pair for 1 candle after an exit.
- **StoplossGuard:** If 2 stoplosses are hit within 90 candles, trading is locked out for 14 candles.
- **MaxDrawdown:** If the account suffers a 10% drawdown within 90 candles, trading is locked out for 30 candles.
