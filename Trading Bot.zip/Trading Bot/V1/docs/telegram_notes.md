# Telegram Integration Notes

## Overview
This document covers the verified configuration format, setup steps, and notification decisions for Freqtrade's Telegram integration.

Source: [Official Freqtrade Telegram Docs](https://www.freqtrade.io/en/stable/telegram-usage/) (verified 2026-09-15).

---

## Step 1: Create a Telegram Bot (Manual — via BotFather)

This must be done manually through the Telegram app. Antigravity cannot do this for you.

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. BotFather will ask you to choose:
   - A **display name** (e.g. `EmaAtrTrend Monitor`)
   - A **username** ending in `bot` (e.g. `emaatrtrendbot`)
4. BotFather will respond with a message containing your **API token**, in the format:
   ```
   Use this token to access the HTTP API: 1234567890:ABCDefGhIJKlmNoPQRsTUVwXyz
   ```
5. Copy this token. It becomes `TELEGRAM_BOT_TOKEN` in your `.env` file.
6. **Important:** Start a conversation with your new bot by clicking the link BotFather gives you and pressing `/START`. The bot cannot send you messages until you've initiated a conversation.

---

## Step 2: Get Your Telegram Chat ID (Manual)

1. Open Telegram and search for **@userinfobot**
2. Send any message (e.g. `/start`)
3. It will reply with your user info, including:
   ```
   Id: 123456789
   ```
4. This number becomes `TELEGRAM_CHAT_ID` in your `.env` file.

> Note: `chat_id` must be passed as a **string** (with quotes) in `config.json`, even though it looks like a number. This is confirmed in the official docs.

> If using a **Telegram group** instead of a private chat, add the bot to the group, start Freqtrade, and run `/tg_info` from within the group to get the group ID (it will be a negative number like `-1001332619709`).

---

## Step 3: Update Your .env File

Once you have the bot token and chat_id, edit the `.env` file (not `.env.example`) and set:

```
TELEGRAM_BOT_TOKEN=1234567890:ABCDefGhIJKlmNoPQRsTUVwXyz
TELEGRAM_CHAT_ID=123456789
```

---

## Step 4: Enable Telegram in config.json

Change `"enabled": false` to `"enabled": true` in the `"telegram"` section of `user_data/config.json`. Then restart the bot.

```json
"telegram": {
    "enabled": true,
    "token": "${TELEGRAM_BOT_TOKEN}",
    "chat_id": "${TELEGRAM_CHAT_ID}",
    ...
}
```

---

## Verified Config Structure (from official docs)

The complete `telegram` block currently in `config.json`:

```json
"telegram": {
    "enabled": false,
    "token": "${TELEGRAM_BOT_TOKEN}",
    "chat_id": "${TELEGRAM_CHAT_ID}",
    "notification_settings": {
        "status": "silent",
        "warning": "on",
        "startup": "silent",
        "entry": "on",
        "entry_fill": "on",
        "entry_cancel": "silent",
        "exit": {
            "roi": "on",
            "emergency_exit": "on",
            "force_exit": "on",
            "exit_signal": "on",
            "trailing_stop_loss": "on",
            "stop_loss": "on",
            "stoploss_on_exchange": "on",
            "custom_exit": "on",
            "*": "on"
        },
        "exit_cancel": "on",
        "exit_fill": "off",
        "protection_trigger": "on",
        "protection_trigger_global": "on",
        "strategy_msg": "off",
        "show_candle": "off"
    }
}
```

---

## Notification Setting Rationale

Given this strategy trades approximately **~2 times per year per pair**, the goal is maximum signal-to-noise: every real trade event should alert loudly, routine operational noise should be silent or off.

| Setting | Value | Rationale |
|---|---|---|
| `status` | `silent` | Bot running/paused messages — low priority, silent is fine |
| `warning` | `on` | Any warnings should be seen immediately |
| `startup` | `silent` | Startup confirmation is useful but not urgent |
| `entry` | `on` | Trade opened — always want to know |
| `entry_fill` | `on` | Order filled on exchange — critical confirmation |
| `entry_cancel` | `silent` | Order cancelled — notable but not urgent |
| `exit.*` | `on` | All exits (stoploss, signal, emergency) are high priority events |
| `exit_fill` | `off` | Off by default per docs; `exit` already covers this |
| `protection_trigger` | `on` | A per-pair protection fired — want to know |
| `protection_trigger_global` | `on` | Global circuit breaker fired — must know immediately |
| `strategy_msg` | `off` | Not used by EmaAtrTrend strategy |
| `show_candle` | `off` | Not needed; would add noise to each entry/exit message |

---

## FreqUI Access

FreqUI is the official Freqtrade web UI. It is **bundled with the Docker image** and served automatically alongside the REST API — no additional setup is required.

**Access URL:** `http://localhost:8080`  
(Based on `listen_ip_address: 0.0.0.0` and `listen_port: 8080` in `config.json`.)

When you navigate to this URL in a browser while the bot is running, Freqtrade serves the FreqUI interface directly. You will be prompted for the username and password configured via `FREQTRADE_API_USERNAME` and `FREQTRADE_API_PASSWORD` in your `.env` file.

> No separate `npm`, `nginx`, or additional installation step is required. The FreqUI static files are pre-bundled into the Docker image. The REST API and FreqUI share the same port 8080.
