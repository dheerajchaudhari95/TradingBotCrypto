# In-Sample Backtest Summaries (2021-01-01 to 2024-06-30)

## DiagnosticCrossoverOnly (No Regime Filter)

```text
======================================================================================================================================
| Metric                                 | Value                                     |
|----------------------------------------|-------------------------------------------|
| Backtesting from                       | 2021-01-01 00:00:00                       |
| Backtesting to                         | 2024-06-30 00:00:00                       |
| Trading Mode                           | Spot                                      |
| Max open trades                        | 2                                         |
|                                        |                                           |
| Total/Daily Avg Trades                 | 20 / 0.02                                 |
| Starting balance                       | 1000 USDT                                 |
| Final balance                          | 1081.813 USDT                             |
| Absolute profit                        | 81.813 USDT                               |
| Total profit %                         | 8.18%                                     |
| CAGR %                                 | 2.27%                                     |
| Sharpe (closed trades)                 | 0.03                                      |
| Sortino (closed trades)                | 0.11                                      |
| Calmar (closed trades)                 | 0.91                                      |
| SQN                                    | 0.38                                      |
| Mean profit p-value                    | 0.7059                                    |
| Profit factor                          | 1.33                                      |
| Expectancy (Ratio)                     | 4.09 (0.21)                               |
| Avg. daily profit                      | 0.064 USDT                                |
| Avg. stake amount                      | 479.867 USDT                              |
| Market change                          | 242.85%                                   |
| Total trade volume                     | 19315.076 USDT                            |
|                                        |                                           |
| Best Pair                              | ETH/USDT 15.06%                           |
| Worst Pair                             | BTC/USDT -6.88%                           |
| Best trade                             | ETH/USDT 35.27%                           |
| Worst trade                            | ETH/USDT -8.23%                           |
| Best day                               | 169.456 USDT                              |
| Worst day                              | -39.548 USDT                              |
| Days win/draw/lose                     | 7 / 1006 / 12                             |
| Min/Max/Avg. Duration Winners          | 2d 00:00 / 30d 00:00 / 13d 00:00          |
| Min/Max/Avg. Duration Losers           | 0d 00:00 / 11d 00:00 / 3d 20:18           |
| Max Consecutive Wins / Loss            | 5 / 5                                     |
| Rejected Entry signals                 | 0                                         |
| Entry/Exit Timeouts                    | 0 / 0                                     |
|                                        |                                           |
| Min/Max balance (closed trades)        | 962.042 USDT / 1250.92 USDT               |
| Max % of account underwater            | 13.52%                                    |
| Absolute drawdown                      | 169.107 USDT (13.52%)                     |
| Drawdown duration                      | 778 days 00:00:00                         |
| Profit at drawdown start               | 250.92 USDT                               |
| Profit at drawdown end                 | 81.813 USDT                               |
| Drawdown start                         | 2022-04-06 00:00:00                       |
| Drawdown end                           | 2024-05-23 00:00:00                       |
|                                        |                                           |
| Wallet based Metrics                   |                                           |
| Min/Max balance (wallet balance)       | 953.217 USDT / 1306.415 USDT              |
| Min/Max balance dates (wallet balance) | 2021-08-04 00:00:00 / 2022-03-30 00:00:00 |
| Max % of account underwater (balance)  | 17.19%                                    |
| Absolute drawdown (wallet balance)     | 224.601 USDT (17.19%)                     |
| Drawdown duration                      | 786 days 00:00:00                         |
| Profit at drawdown start               | 306.415 USDT                              |
| Profit at drawdown end                 | 81.813 USDT                               |
| Drawdown start                         | 2022-03-30 00:00:00                       |
| Drawdown end                           | 2024-05-24 00:00:00                       |
| Sharpe (daily wallet balance)          | 0.28                                      |
| Sortino (daily wallet balance)         | 0.16                                      |
| Calmar (daily wallet balance)          | 0.71                                      |
======================================================================================================================================
                                                                   STRATEGY SUMMARY                                                                   
┏━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┓
┃                Strategy ┃ Trades ┃ Avg Profit % ┃ Tot Profit USDT ┃ Tot Profit % ┃    Avg Duration ┃  Win  Draw  Loss  Win% ┃             Drawdown ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━┩
│ DiagnosticCrossoverOnly │     20 │         0.85 │          81.813 │         8.18 │ 7 days, 1:12:00 │    7     0    13  35.0 │ 169.107 USDT  13.52% │
└─────────────────────────┴────────┴──────────────┴─────────────────┴──────────────┴─────────────────┴────────────────────────┴──────────────────────┘
```

## DiagnosticCrossoverSMA200 (With Regime Filter)

```text
======================================================================================================================================
| Metric                                 | Value                                     |
|----------------------------------------|-------------------------------------------|
| Backtesting from                       | 2021-01-01 00:00:00                       |
| Backtesting to                         | 2024-06-30 00:00:00                       |
| Trading Mode                           | Spot                                      |
| Max open trades                        | 2                                         |
|                                        |                                           |
| Total/Daily Avg Trades                 | 10 / 0.01                                 |
| Starting balance                       | 1000 USDT                                 |
| Final balance                          | 1186.491 USDT                             |
| Absolute profit                        | 186.491 USDT                              |
| Total profit %                         | 18.65%                                    |
| CAGR %                                 | 5.01%                                     |
| Sharpe (closed trades)                 | 0.05                                      |
| Sortino (closed trades)                | 0.27                                      |
| Calmar (closed trades)                 | 4.35                                      |
| SQN                                    | 0.97                                      |
| Mean profit p-value                    | 0.3579                                    |
| Profit factor                          | 3.22                                      |
| Expectancy (Ratio)                     | 18.65 (1.33)                              |
| Avg. daily profit                      | 0.146 USDT                                |
| Avg. stake amount                      | 479.856 USDT                              |
| Market change                          | 242.85%                                   |
| Total trade volume                     | 9803.196 USDT                             |
|                                        |                                           |
| Best Pair                              | ETH/USDT 16.81%                           |
| Worst Pair                             | BTC/USDT 1.84%                            |
| Best trade                             | ETH/USDT 35.27%                           |
| Worst trade                            | ETH/USDT -6.60%                           |
| Best day                               | 169.456 USDT                              |
| Worst day                              | -31.709 USDT                              |
| Days win/draw/lose                     | 4 / 986 / 6                               |
| Min/Max/Avg. Duration Winners          | 2d 00:00 / 30d 00:00 / 18d 00:00          |
| Min/Max/Avg. Duration Losers           | 0d 00:00 / 9d 00:00 / 2d 20:00            |
| Max Consecutive Wins / Loss            | 3 / 3                                     |
| Rejected Entry signals                 | 0                                         |
| Entry/Exit Timeouts                    | 0 / 0                                     |
|                                        |                                           |
| Min/Max balance (closed trades)        | 1169.456 USDT / 1267.817 USDT             |
| Max % of account underwater            | 6.41%                                     |
| Absolute drawdown                      | 81.326 USDT (6.41%)                       |
| Drawdown duration                      | 944 days 00:00:00                         |
| Profit at drawdown start               | 267.817 USDT                              |
| Profit at drawdown end                 | 186.491 USDT                              |
| Drawdown start                         | 2021-10-22 00:00:00                       |
| Drawdown end                           | 2024-05-23 00:00:00                       |
|                                        |                                           |
| Wallet based Metrics                   |                                           |
| Min/Max balance (wallet balance)       | 991.175 USDT / 1301.39 USDT               |
| Min/Max balance dates (wallet balance) | 2021-08-04 00:00:00 / 2021-10-21 00:00:00 |
| Max % of account underwater (balance)  | 8.83%                                     |
| Absolute drawdown (wallet balance)     | 114.9 USDT (8.83%)                        |
| Drawdown duration                      | 946 days 00:00:00                         |
| Profit at drawdown start               | 301.39 USDT                               |
| Profit at drawdown end                 | 186.491 USDT                              |
| Drawdown start                         | 2021-10-21 00:00:00                       |
| Drawdown end                           | 2024-05-24 00:00:00                       |
| Sharpe (daily wallet balance)          | 0.65                                      |
| Sortino (daily wallet balance)         | 0.32                                      |
| Calmar (daily wallet balance)          | 3.17                                      |
======================================================================================================================================
                                                                   STRATEGY SUMMARY                                                                    
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃                  Strategy ┃ Trades ┃ Avg Profit % ┃ Tot Profit USDT ┃ Tot Profit % ┃     Avg Duration ┃  Win  Draw  Loss  Win% ┃           Drawdown ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ DiagnosticCrossoverSMA200 │     10 │         3.88 │         186.491 │        18.65 │ 8 days, 21:36:00 │    4     0     6  40.0 │ 81.326 USDT  6.41% │
└───────────────────────────┴────────┴──────────────┴─────────────────┴──────────────┴──────────────────┴────────────────────────┴────────────────────┘
```

## Specific Metric Comparison

| Metric | DiagnosticCrossoverOnly | DiagnosticCrossoverSMA200 |
| :--- | :--- | :--- |
| **Total Profit %** | 8.18% | 18.65% |
| **Win Rate** | 35.00% | 40.00% |
| **Profit Factor** | 1.33 | 3.22 |
| **Absolute Drawdown %** | 13.52% (closed) / 17.19% (wallet) | 6.41% (closed) / 8.83% (wallet) |
| **Total Trade Count** | 20 | 10 |
