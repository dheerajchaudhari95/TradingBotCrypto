# Diagnostic Backtest Results: Crossover Only

Here are the results of the `DiagnosticCrossoverOnly` backtest (EMA20/50 crossover with no ATR volatility filter):

### 1. Total Trade Count by Pair
- **BTC/USDT**: 8 trades
- **ETH/USDT**: 9 trades
- **Total**: 17 trades

### 2. Full Backtest Summary Table
```text
                                   SUMMARY METRICS                                    
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Metric                                 ┃ Value                                     ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ Backtesting from                       │ 2023-12-19 00:00:00                       │
│ Backtesting to                         │ 2026-09-13 00:00:00                       │
│ Trading Mode                           │ Spot                                      │
│ Max open trades                        │ 2                                         │
│                                        │                                           │
│ Total/Daily Avg Trades                 │ 17 / 0.02                                 │
│ Starting balance                       │ 1000 USDT                                 │
│ Final balance                          │ 902.909 USDT                              │
│ Absolute profit                        │ -97.091 USDT                              │
│ Total profit %                         │ -9.71%                                    │
│ CAGR %                                 │ -3.66%                                    │
│ Sharpe (closed trades)                 │ -0.08                                     │
│ Sortino (closed trades)                │ -0.17                                     │
│ Calmar (closed trades)                 │ -1.31                                     │
│ SQN                                    │ -0.98                                     │
│ Mean profit p-value                    │ 0.3406                                    │
│ Profit factor                          │ 0.55                                      │
│ Expectancy (Ratio)                     │ -5.71 (-0.31)                             │
│ Avg. daily profit                      │ -0.097 USDT                               │
│ Avg. stake amount                      │ 479.723 USDT                              │
│ Market change                          │ 47.75%                                    │
│ Total trade volume                     │ 16245.938 USDT                            │
│                                        │                                           │
│ Best Pair                              │ BTC/USDT 4.77%                            │
│ Worst Pair                             │ ETH/USDT -14.48%                          │
│ Best trade                             │ BTC/USDT 10.24%                           │
│ Worst trade                            │ ETH/USDT -7.40%                           │
│ Best day                               │ 49.177 USDT                               │
│ Worst day                              │ -35.557 USDT                              │
│ Days win/draw/lose                     │ 5 / 905 / 12                              │
│ Min/Max/Avg. Duration Winners          │ 2d 00:00 / 16d 00:00 / 7d 19:12           │
│ Min/Max/Avg. Duration Losers           │ 0d 00:00 / 14d 00:00 / 4d 10:00           │
│ Max Consecutive Wins / Loss            │ 2 / 6                                     │
│ Rejected Entry signals                 │ 0                                         │
│ Entry/Exit Timeouts                    │ 0 / 0                                     │
│                                        │                                           │
│ Min/Max balance (closed trades)        │ 902.909 USDT / 1052.185 USDT              │
│ Max % of account underwater            │ 14.19%                                    │
│ Absolute drawdown                      │ 149.276 USDT (14.19%)                     │
│ Drawdown duration                      │ 907 days 00:00:00                         │
│ Profit at drawdown start               │ 52.185 USDT                               │
│ Profit at drawdown end                 │ -97.091 USDT                              │
│ Drawdown start                         │ 2024-02-26 00:00:00                       │
│ Drawdown end                           │ 2026-08-21 00:00:00                       │
│                                        │                                           │
│ Wallet based Metrics                   │                                           │
│ Min/Max balance (wallet balance)       │ 902.909 USDT / 1055.191 USDT              │
│ Min/Max balance dates (wallet balance) │ 2026-08-22 00:00:00 / 2024-02-21 00:00:00 │
│ Max % of account underwater (balance)  │ 14.43%                                    │
│ Absolute drawdown (wallet balance)     │ 152.282 USDT (14.43%)                     │
│ Drawdown duration                      │ 913 days 00:00:00                         │
│ Profit at drawdown start               │ 55.191 USDT                               │
│ Profit at drawdown end                 │ -97.091 USDT                              │
│ Drawdown start                         │ 2024-02-21 00:00:00                       │
│ Drawdown end                           │ 2026-08-22 00:00:00                       │
│ Sharpe (daily wallet balance)          │ -0.57                                     │
│ Sortino (daily wallet balance)         │ -0.27                                     │
│ Calmar (daily wallet balance)          │ -1.29                                     │
└────────────────────────────────────────┴───────────────────────────────────────────┘

Backtested 2023-12-19 00:00:00 -> 2026-09-13 00:00:00 | Max open trades : 2
                                                                   STRATEGY SUMMARY                                                                   
┏━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┓
┃                Strategy ┃ Trades ┃ Avg Profit % ┃ Tot Profit USDT ┃ Tot Profit % ┃    Avg Duration ┃  Win  Draw  Loss  Win% ┃             Drawdown ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━┩
│ DiagnosticCrossoverOnly │     17 │        -1.19 │         -97.091 │        -9.71 │ 5 days, 9:53:00 │    5     0    12  29.4 │ 149.276 USDT  14.19% │
└─────────────────────────┴────────┴──────────────┴─────────────────┴──────────────┴─────────────────┴────────────────────────┴──────────────────────┘
```

### 3. Exact Entry Dates of Every Trade
```text
ETH/USDT: 2024-02-10 00:00:00+00:00
BTC/USDT: 2024-02-10 00:00:00+00:00
BTC/USDT: 2024-05-19 00:00:00+00:00
ETH/USDT: 2024-05-23 00:00:00+00:00
BTC/USDT: 2024-07-24 00:00:00+00:00
BTC/USDT: 2024-09-23 00:00:00+00:00
ETH/USDT: 2024-10-22 00:00:00+00:00
ETH/USDT: 2024-10-31 00:00:00+00:00
ETH/USDT: 2024-11-08 00:00:00+00:00
BTC/USDT: 2025-04-25 00:00:00+00:00
ETH/USDT: 2025-05-11 00:00:00+00:00
BTC/USDT: 2025-09-16 00:00:00+00:00
BTC/USDT: 2025-10-02 00:00:00+00:00
ETH/USDT: 2026-01-16 00:00:00+00:00
ETH/USDT: 2026-04-15 00:00:00+00:00
ETH/USDT: 2026-07-23 00:00:00+00:00
BTC/USDT: 2026-08-21 00:00:00+00:00
```
