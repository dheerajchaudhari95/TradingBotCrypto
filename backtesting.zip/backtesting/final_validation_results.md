# Final Validation: Out-of-Sample Results (2024-07-01 to 2026-09-13)

## 1. EmaAtrTrend (SMA200 Filter)

### Summary Metrics
```text
======================================================================================================================================
| Metric                                 | Value                                     |
|----------------------------------------|-------------------------------------------|
| Backtesting from                       | 2024-07-01 00:00:00                       |
| Backtesting to                         | 2026-09-12 00:00:00                       |
| Trading Mode                           | Spot                                      |
| Max open trades                        | 2                                         |
|                                        |                                           |
| Total/Daily Avg Trades                 | 4 / 0.0                                   |
| Starting balance                       | 1000 USDT                                 |
| Final balance                          | 1020.953 USDT                             |
| Absolute profit                        | 20.953 USDT                               |
| Total profit %                         | 2.10%                                     |
| CAGR %                                 | 0.95%                                     |
| Sharpe (closed trades)                 | 0.04                                      |
| Sortino (closed trades)                | 0.10                                      |
| Calmar (closed trades)                 | 4.82                                      |
| SQN                                    | 0.71                                      |
| Mean profit p-value                    | 0.5308                                    |
| Profit factor                          | 2.81                                      |
| Expectancy (Ratio)                     | 5.24 (0.91)                               |
| Avg. daily profit                      | 0.026 USDT                                |
| Avg. stake amount                      | 479.517 USDT                              |
| Market change                          | -1.88%                                    |
| Total trade volume                     | 3864.808 USDT                             |
|                                        |                                           |
| Best Pair                              | BTC/USDT 2.10%                            |
| Worst Pair                             | ETH/USDT 0.00%                            |
| Best trade                             | BTC/USDT 5.06%                            |
| Worst trade                            | BTC/USDT -2.20%                           |
| Best day                               | 24.254 USDT                               |
| Worst day                              | -10.591 USDT                              |
| Days win/draw/lose                     | 2 / 467 / 2                               |
| Min/Max/Avg. Duration Winners          | 5d 00:00 / 13d 00:00 / 9d 00:00           |
| Min/Max/Avg. Duration Losers           | 0d 00:00 / 6d 00:00 / 3d 00:00            |
| Max Consecutive Wins / Loss            | 1 / 1                                     |
| Rejected Entry signals                 | 0                                         |
| Entry/Exit Timeouts                    | 0 / 0                                     |
|                                        |                                           |
| Min/Max balance (closed trades)        | 1013.663 USDT / 1024.254 USDT             |
| Max % of account underwater            | 1.03%                                     |
| Absolute drawdown                      | 10.591 USDT (1.03%)                       |
| Drawdown duration                      | 137 days 00:00:00                         |
| Profit at drawdown start               | 24.254 USDT                               |
| Profit at drawdown end                 | 13.663 USDT                               |
| Drawdown start                         | 2025-05-08 00:00:00                       |
| Drawdown end                           | 2025-09-22 00:00:00                       |
|                                        |                                           |
| Wallet based Metrics                   |                                           |
| Min/Max balance (wallet balance)       | 998.821 USDT / 1038.16 USDT               |
| Min/Max balance dates (wallet balance) | 2025-04-28 00:00:00 / 2025-10-07 00:00:00 |
| Max % of account underwater (balance)  | 1.72%                                     |
| Absolute drawdown (wallet balance)     | 17.762 USDT (1.72%)                       |
| Drawdown duration                      | 4 days 00:00:00                           |
| Profit at drawdown start               | 31.425 USDT                               |
| Profit at drawdown end                 | 13.663 USDT                               |
| Drawdown start                         | 2025-09-19 00:00:00                       |
| Drawdown end                           | 2025-09-23 00:00:00                       |
| Sharpe (daily wallet balance)          | 0.44                                      |
| Sortino (daily wallet balance)         | 0.12                                      |
| Calmar (daily wallet balance)          | 2.90                                      |
======================================================================================================================================
```
```text
                                                            STRATEGY SUMMARY                                                            
┏━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃    Strategy ┃ Trades ┃ Avg Profit % ┃ Tot Profit USDT ┃ Tot Profit % ┃    Avg Duration ┃  Win  Draw  Loss  Win% ┃           Drawdown ┃
┡━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ EmaAtrTrend │      4 │         1.09 │          20.953 │          2.1 │ 6 days, 0:00:00 │    2     0     2  50.0 │ 10.591 USDT  1.03% │
└─────────────┴────────┴──────────────┴─────────────────┴──────────────┴─────────────────┴────────────────────────┴────────────────────┘
```

### Full Trade List
- **BTC/USDT**: 2025-04-25 00:00:00 to 2025-05-08 00:00:00 -> +5.06%
- **BTC/USDT**: 2025-09-16 00:00:00 to 2025-09-22 00:00:00 -> -2.20%
- **BTC/USDT**: 2025-10-02 00:00:00 to 2025-10-07 00:00:00 -> +1.72%
- **BTC/USDT**: 2026-08-21 00:00:00 to 2026-08-21 00:00:00 -> -0.20%

### Specific Metrics (EmaAtrTrend)
- **Total Profit %**: 2.10%
- **Market Change %**: -1.88%
- **Win Rate**: 50.0%
- **Profit Factor**: 2.81
- **Max Drawdown (Closed)**: 1.03% (10.591 USDT)
- **Max Drawdown (Wallet)**: 1.72% (17.762 USDT)

---

## 2. DiagnosticCrossoverOnly (Unfiltered)

### Summary Metrics
```text
======================================================================================================================================
| Metric                                 | Value                                     |
|----------------------------------------|-------------------------------------------|
| Backtesting from                       | 2024-07-01 00:00:00                       |
| Backtesting to                         | 2026-09-12 00:00:00                       |
| Trading Mode                           | Spot                                      |
| Max open trades                        | 2                                         |
|                                        |                                           |
| Total/Daily Avg Trades                 | 13 / 0.02                                 |
| Starting balance                       | 1000 USDT                                 |
| Final balance                          | 889.504 USDT                              |
| Absolute profit                        | -110.496 USDT                             |
| Total profit %                         | -11.05%                                   |
| CAGR %                                 | -5.18%                                    |
| Sharpe (closed trades)                 | -0.14                                     |
| Sortino (closed trades)                | -0.34                                     |
| Calmar (closed trades)                 | -2.30                                     |
| SQN                                    | -1.53                                     |
| Mean profit p-value                    | 0.1513                                    |
| Profit factor                          | 0.38                                      |
| Expectancy (Ratio)                     | -8.50 (-0.48)                             |
| Avg. daily profit                      | -0.138 USDT                               |
| Avg. stake amount                      | 479.714 USDT                              |
| Market change                          | -1.88%                                    |
| Total trade volume                     | 12386.822 USDT                            |
|                                        |                                           |
| Best Pair                              | BTC/USDT -1.44%                           |
| Worst Pair                             | ETH/USDT -9.61%                           |
| Best trade                             | ETH/USDT 7.47%                            |
| Worst trade                            | ETH/USDT -5.48%                           |
| Best day                               | 35.89 USDT                                |
| Worst day                              | -48.566 USDT                              |
| Days win/draw/lose                     | 3 / 678 / 9                               |
| Min/Max/Avg. Duration Winners          | 3d 00:00 / 13d 00:00 / 7d 00:00           |
| Min/Max/Avg. Duration Losers           | 0d 00:00 / 14d 00:00 / 4d 19:12           |
| Max Consecutive Wins / Loss            | 2 / 5                                     |
| Rejected Entry signals                 | 0                                         |
| Entry/Exit Timeouts                    | 0 / 0                                     |
|                                        |                                           |
| Min/Max balance (closed trades)        | 889.504 USDT / 1004.387 USDT              |
| Max % of account underwater            | 11.44%                                    |
| Absolute drawdown                      | 114.883 USDT (11.44%)                     |
| Drawdown duration                      | 470 days 00:00:00                         |
| Profit at drawdown start               | 4.387 USDT                                |
| Profit at drawdown end                 | -110.496 USDT                             |
| Drawdown start                         | 2025-05-08 00:00:00                       |
| Drawdown end                           | 2026-08-21 00:00:00                       |
|                                        |                                           |
| Wallet based Metrics                   |                                           |
| Min/Max balance (wallet balance)       | 889.504 USDT / 1017.185 USDT              |
| Min/Max balance dates (wallet balance) | 2026-08-22 00:00:00 / 2024-09-29 00:00:00 |
| Max % of account underwater (balance)  | 12.55%                                    |
| Absolute drawdown (wallet balance)     | 127.681 USDT (12.55%)                     |
| Drawdown duration                      | 692 days 00:00:00                         |
| Profit at drawdown start               | 17.185 USDT                               |
| Profit at drawdown end                 | -110.496 USDT                             |
| Drawdown start                         | 2024-09-29 00:00:00                       |
| Drawdown end                           | 2026-08-22 00:00:00                       |
| Sharpe (daily wallet balance)          | -0.84                                     |
| Sortino (daily wallet balance)         | -0.41                                     |
| Calmar (daily wallet balance)          | -2.10                                     |
======================================================================================================================================
```
```text
                                                                   STRATEGY SUMMARY                                                                   
┏━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┓
┃                Strategy ┃ Trades ┃ Avg Profit % ┃ Tot Profit USDT ┃ Tot Profit % ┃    Avg Duration ┃  Win  Draw  Loss  Win% ┃             Drawdown ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━┩
│ DiagnosticCrossoverOnly │     13 │        -1.77 │        -110.496 │       -11.05 │ 5 days, 7:23:00 │    3     0    10  23.1 │ 114.883 USDT  11.44% │
└─────────────────────────┴────────┴──────────────┴─────────────────┴──────────────┴─────────────────┴────────────────────────┴──────────────────────┘
```

### Full Trade List
- **BTC/USDT**: 2024-09-23 00:00:00 to 2024-10-01 00:00:00 -> -2.62%
- **ETH/USDT**: 2024-10-23 00:00:00 to 2024-10-25 00:00:00 -> -3.51%
- **ETH/USDT**: 2024-10-31 00:00:00 to 2024-11-01 00:00:00 -> -5.48%
- **ETH/USDT**: 2024-11-08 00:00:00 to 2024-11-11 00:00:00 -> +7.47%
- **BTC/USDT**: 2025-04-25 00:00:00 to 2025-05-08 00:00:00 -> +5.06%
- **ETH/USDT**: 2025-05-11 00:00:00 to 2025-05-13 00:00:00 -> -5.09%
- **BTC/USDT**: 2025-09-16 00:00:00 to 2025-09-22 00:00:00 -> -2.20%
- **BTC/USDT**: 2025-10-02 00:00:00 to 2025-10-07 00:00:00 -> +1.72%
- **ETH/USDT**: 2026-01-16 00:00:00 to 2026-01-20 00:00:00 -> -5.38%
- **BTC/USDT**: 2026-01-18 00:00:00 to 2026-01-20 00:00:00 -> -4.73%
- **ETH/USDT**: 2026-04-15 00:00:00 to 2026-04-29 00:00:00 -> -3.37%
- **ETH/USDT**: 2026-07-23 00:00:00 to 2026-08-01 00:00:00 -> -4.65%
- **BTC/USDT**: 2026-08-21 00:00:00 to 2026-08-21 00:00:00 -> -0.20%

---

## 3. Factual Comparison

Did the SMA200-filtered version (`EmaAtrTrend`) outperform the unfiltered version (`DiagnosticCrossoverOnly`) on this untouched out-of-sample period? **Yes.**

Specific metrics comparison:
- **Total profit %**: The filtered version outperformed by **13.15 percentage points** (+2.10% vs -11.05%).
- **Market change % vs Strategy**: The filtered version returned positive **+2.10%**, successfully outperforming the overall market buy-and-hold change of **-1.88%**. The unfiltered version underperformed the market significantly (-11.05%).
- **Win rate**: The filtered version outperformed by **26.9 percentage points** (50.0% vs 23.1%).
- **Profit factor**: The filtered version was substantially higher (**2.81** vs **0.38**).
- **Max drawdown (Closed)**: The filtered version reduced the maximum closed drawdown from 11.44% down to **1.03%** (an improvement of 10.41 percentage points). 
- **Max drawdown (Wallet)**: The filtered version reduced the maximum wallet drawdown from 12.55% down to **1.72%** (an improvement of 10.83 percentage points).
- **Trade count**: The filtered version successfully eliminated 9 trades (from 13 down to 4), filtering out many losing entries during down-trending market periods.
