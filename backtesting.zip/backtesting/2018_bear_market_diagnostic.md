# 2018 Bear Market Diagnostic (2017-08-17 to 2021-01-01)

## Earliest Available Data Date
The earliest available data for the pairs requested was **2017-08-17** (both BTC/USDT and ETH/USDT). This date was used as the start of the timerange for the backtests.

---

## 1. EmaAtrTrend (SMA200 Filtered)

### Summary Metrics
```text
======================================================================================================================================
| Metric                                 | Value                                     |
|----------------------------------------|-------------------------------------------|
| Backtesting from                       | 2017-08-17 00:00:00                       |
| Backtesting to                         | 2021-01-01 00:00:00                       |
| Trading Mode                           | Spot                                      |
| Max open trades                        | 2                                         |
|                                        |                                           |
| Total/Daily Avg Trades                 | 5 / 0.0                                   |
| Starting balance                       | 1000 USDT                                 |
| Final balance                          | 1050.458 USDT                             |
| Absolute profit                        | 50.458 USDT                               |
| Total profit %                         | 5.05%                                     |
| CAGR %                                 | 1.47%                                     |
| Sharpe (closed trades)                 | 0.02                                      |
| Sortino (closed trades)                | 0.10                                      |
| Calmar (closed trades)                 | 2.45                                      |
| SQN                                    | 0.61                                      |
| Mean profit p-value                    | 0.5744                                    |
| Profit factor                          | 2.04                                      |
| Expectancy (Ratio)                     | 10.09 (0.41)                              |
| Avg. daily profit                      | 0.041 USDT                                |
| Avg. stake amount                      | 479.96 USDT                               |
| Market change                          | 362.93%                                   |
| Total trade volume                     | 4859.769 USDT                             |
|                                        |                                           |
| Best Pair                              | ETH/USDT 2.83%                            |
| Worst Pair                             | BTC/USDT 2.22%                            |
| Best trade                             | BTC/USDT 11.29%                           |
| Worst trade                            | BTC/USDT -6.67%                           |
| Best day                               | 41.34 USDT                                |
| Worst day                              | -32.061 USDT                              |
| Days win/draw/lose                     | 3 / 899 / 1                               |
| Min/Max/Avg. Duration Winners          | 3d 00:00 / 10d 00:00 / 7d 16:00           |
| Min/Max/Avg. Duration Losers           | 5d 00:00 / 7d 00:00 / 6d 00:00            |
| Max Consecutive Wins / Loss            | 2 / 1                                     |
| Rejected Entry signals                 | 0                                         |
| Entry/Exit Timeouts                    | 0 / 0                                     |
|                                        |                                           |
| Min/Max balance (closed trades)        | 971.539 USDT / 1067.122 USDT              |
| Max % of account underwater            | 3.19%                                     |
| Absolute drawdown                      | 32.061 USDT (3.19%)                       |
| Drawdown duration                      | 558 days 00:00:00                         |
| Profit at drawdown start               | 3.6 USDT                                  |
| Profit at drawdown end                 | -28.461 USDT                              |
| Drawdown start                         | 2018-05-03 00:00:00                       |
| Drawdown end                           | 2019-11-12 00:00:00                       |
|                                        |                                           |
| Wallet based Metrics                   |                                           |
| Min/Max balance (wallet balance)       | 971.539 USDT / 1050.458 USDT              |
| Min/Max balance dates (wallet balance) | 2019-11-13 00:00:00 / 2020-10-22 00:00:00 |
| Max % of account underwater (balance)  | 5.18%                                     |
| Absolute drawdown (wallet balance)     | 54.299 USDT (5.18%)                       |
| Drawdown duration                      | 170 days 00:00:00                         |
| Profit at drawdown start               | 48.697 USDT                               |
| Profit at drawdown end                 | -5.602 USDT                               |
| Drawdown start                         | 2020-04-30 00:00:00                       |
| Drawdown end                           | 2020-10-17 00:00:00                       |
| Sharpe (daily wallet balance)          | 0.34                                      |
| Sortino (daily wallet balance)         | 0.10                                      |
| Calmar (daily wallet balance)          | 1.51                                      |
======================================================================================================================================
```
```text
                                                            STRATEGY SUMMARY                                                            
┏━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃    Strategy ┃ Trades ┃ Avg Profit % ┃ Tot Profit USDT ┃ Tot Profit % ┃    Avg Duration ┃  Win  Draw  Loss  Win% ┃           Drawdown ┃
┡━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ EmaAtrTrend │      5 │         2.10 │          50.458 │         5.05 │ 7 days, 0:00:00 │    3     0     2  60.0 │ 32.061 USDT  3.19% │
└─────────────┴────────┴──────────────┴─────────────────┴──────────────┴─────────────────┴────────────────────────┴────────────────────┘
```

### Full Trade List
- **ETH/USDT**: 2018-04-30 to 2018-05-03 -> +0.75%
- **BTC/USDT**: 2019-11-07 to 2019-11-12 -> -6.67%
- **ETH/USDT**: 2020-04-24 to 2020-05-04 -> +8.60%
- **BTC/USDT**: 2020-10-11 to 2020-10-21 -> +11.29%
- **ETH/USDT**: 2020-10-14 to 2020-10-21 -> -3.47%


---

## 2. DiagnosticCrossoverOnly (Unfiltered)

### Summary Metrics
```text
======================================================================================================================================
| Metric                                 | Value                                     |
|----------------------------------------|-------------------------------------------|
| Backtesting from                       | 2017-08-17 00:00:00                       |
| Backtesting to                         | 2021-01-01 00:00:00                       |
| Trading Mode                           | Spot                                      |
| Max open trades                        | 2                                         |
|                                        |                                           |
| Total/Daily Avg Trades                 | 16 / 0.01                                 |
| Starting balance                       | 1000 USDT                                 |
| Final balance                          | 935.942 USDT                              |
| Absolute profit                        | -64.058 USDT                              |
| Total profit %                         | -6.41%                                    |
| CAGR %                                 | -1.94%                                    |
| Sharpe (closed trades)                 | -0.03                                     |
| Sortino (closed trades)                | -0.10                                     |
| Calmar (closed trades)                 | -0.45                                     |
| SQN                                    | -0.43                                     |
| Mean profit p-value                    | 0.6765                                    |
| Profit factor                          | 0.78                                      |
| Expectancy (Ratio)                     | -4.00 (-0.13)                             |
| Avg. daily profit                      | -0.052 USDT                               |
| Avg. stake amount                      | 479.973 USDT                              |
| Market change                          | 362.93%                                   |
| Total trade volume                     | 15325.7 USDT                              |
|                                        |                                           |
| Best Pair                              | ETH/USDT -1.92%                           |
| Worst Pair                             | BTC/USDT -4.49%                           |
| Best trade                             | ETH/USDT 13.71%                           |
| Worst trade                            | ETH/USDT -10.18%                          |
| Best day                               | 65.849 USDT                               |
| Worst day                              | -48.904 USDT                              |
| Days win/draw/lose                     | 6 / 1091 / 9                              |
| Min/Max/Avg. Duration Winners          | 1d 00:00 / 10d 00:00 / 5d 17:09           |
| Min/Max/Avg. Duration Losers           | 0d 00:00 / 10d 00:00 / 3d 13:20           |
| Max Consecutive Wins / Loss            | 2 / 4                                     |
| Rejected Entry signals                 | 0                                         |
| Entry/Exit Timeouts                    | 0 / 0                                     |
|                                        |                                           |
| Min/Max balance (closed trades)        | 840.359 USDT / 1077.28 USDT               |
| Max % of account underwater            | 21.99%                                    |
| Absolute drawdown                      | 236.921 USDT (21.99%)                     |
| Drawdown duration                      | 626 days 00:00:00                         |
| Profit at drawdown start               | 77.28 USDT                                |
| Profit at drawdown end                 | -159.641 USDT                             |
| Drawdown start                         | 2018-05-03 00:00:00                       |
| Drawdown end                           | 2020-01-19 00:00:00                       |
|                                        |                                           |
| Wallet based Metrics                   |                                           |
| Min/Max balance (wallet balance)       | 840.359 USDT / 1103.771 USDT              |
| Min/Max balance dates (wallet balance) | 2020-01-20 00:00:00 / 2018-05-06 00:00:00 |
| Max % of account underwater (balance)  | 23.86%                                    |
| Absolute drawdown (wallet balance)     | 263.412 USDT (23.86%)                     |
| Drawdown duration                      | 624 days 00:00:00                         |
| Profit at drawdown start               | 103.771 USDT                              |
| Profit at drawdown end                 | -159.641 USDT                             |
| Drawdown start                         | 2018-05-06 00:00:00                       |
| Drawdown end                           | 2020-01-20 00:00:00                       |
| Sharpe (daily wallet balance)          | -0.17                                     |
| Sortino (daily wallet balance)         | -0.05                                     |
| Calmar (daily wallet balance)          | -0.42                                     |
======================================================================================================================================
```
```text
                                                                   STRATEGY SUMMARY                                                                    
┏━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┓
┃                Strategy ┃ Trades ┃ Avg Profit % ┃ Tot Profit USDT ┃ Tot Profit % ┃     Avg Duration ┃  Win  Draw  Loss  Win% ┃             Drawdown ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━┩
│ DiagnosticCrossoverOnly │     16 │        -0.83 │         -64.058 │        -6.41 │ 4 days, 12:00:00 │    7     0     9  43.8 │ 236.921 USDT  21.99% │
└─────────────────────────┴────────┴──────────────┴─────────────────┴──────────────┴──────────────────┴────────────────────────┴──────────────────────┘
```

### Full Trade List
- **BTC/USDT**: 2017-10-08 to 2017-10-12 -> +10.38%
- **ETH/USDT**: 2017-10-16 to 2017-10-18 -> -8.75%
- **ETH/USDT**: 2017-11-15 to 2017-11-23 -> +13.71%
- **ETH/USDT**: 2018-04-30 to 2018-05-03 -> +0.75%
- **BTC/USDT**: 2018-04-29 to 2018-05-09 -> -3.76%
- **BTC/USDT**: 2018-07-25 to 2018-07-31 -> -7.70%
- **BTC/USDT**: 2018-09-05 to 2018-09-05 -> -7.82%
- **ETH/USDT**: 2019-01-09 to 2019-01-10 -> -10.18%
- **ETH/USDT**: 2019-02-20 to 2019-02-24 -> +0.71%
- **BTC/USDT**: 2019-02-24 to 2019-02-24 -> -5.85%
- **BTC/USDT**: 2019-11-07 to 2019-11-12 -> -6.67%
- **ETH/USDT**: 2019-11-12 to 2019-11-19 -> -3.86%
- **BTC/USDT**: 2020-01-13 to 2020-01-14 -> +0.78%
- **ETH/USDT**: 2020-01-18 to 2020-01-19 -> -4.98%
- **ETH/USDT**: 2020-04-24 to 2020-05-04 -> +8.60%
- **BTC/USDT**: 2020-10-11 to 2020-10-21 -> +11.29%


---

## 3. Findings

### Key Metrics Comparison
| Metric | EmaAtrTrend | DiagnosticCrossoverOnly |
| :--- | :--- | :--- |
| **Total Profit %** | 5.05% | -6.41% |
| **Market Change %** | 362.93% | 362.93% |
| **Win Rate** | 60.0% | 43.8% |
| **Profit Factor** | 2.04 | 0.78 |
| **Max Absolute Drawdown** | 3.19% | 21.99% |
| **Mean profit p-value** | 0.5744 | 0.6765 |

### 2018 Bear Market Trade Activity
During the core of the 2018 decline (January - December 2018), `EmaAtrTrend` (the SMA200 filtered version) was kept almost entirely flat. It entered only **one** trade during this entire year:
- **ETH/USDT**: 2018-04-30 to 2018-05-03 (a short +0.75% win)

The unfiltered `DiagnosticCrossoverOnly` took 4 trades in 2018, which is naturally low because the EMA 20 rarely crosses above the EMA 50 during a sustained downtrend. However, the SMA200 filter successfully blocked the 3 losing trades the unfiltered strategy took in April, July, and September of 2018.
