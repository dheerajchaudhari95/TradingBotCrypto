# 8-Pair EmaAtrTrend Diagnostic Backtest (2017-08-17 → 2026-09-13)

## Config Changes for This Run (Diagnostic Only)
- `max_open_trades`: 2 → **8** (diagnostic only; production value TBD in Phase 3)
- `pair_whitelist`: 2 pairs → **8 pairs**
- `pair_blacklist`: cleared (removed `BNB/.*` to allow BNB/USDT)
- `ccxt_config.options.defaultType`: set to `"spot"` to suppress futures market DNS fetch

---

## Step 1: Earliest Available Data Per Pair

| Pair | Earliest Date on Binance | Data Length |
|---|---|---|
| BTC/USDT | 2017-08-17 | (existing local data) |
| ETH/USDT | 2017-08-17 | (existing local data) |
| BNB/USDT | 2017-11-06 | 3,235 candles |
| LTC/USDT | 2017-12-13 | 3,198 candles |
| ADA/USDT | 2018-04-17 | 3,073 candles |
| XRP/USDT | 2018-05-04 | 3,056 candles |
| SOL/USDT | 2020-08-11 | 2,226 candles |
| DOT/USDT | 2020-08-18 | 2,219 candles |

> **Note:** SOL and DOT have significantly shorter histories (~6 years vs ~9 years for BTC/ETH). This reduces their sample sizes and means the SMA200 warm-up period consumed a larger fraction of their tradeable window.

---

## Step 2: Full Backtest Summary Table

```
Backtested 2017-08-17 00:00:00 -> 2026-09-13 00:00:00 | Max open trades: 8

SUMMARY METRICS
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Metric                                 ┃ Value                                     ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ Backtesting from                       │ 2017-08-17 00:00:00                       │
│ Backtesting to                         │ 2026-09-13 00:00:00                       │
│ Trading Mode                           │ Spot                                      │
│ Max open trades                        │ 8                                         │
│                                        │                                           │
│ Total/Daily Avg Trades                 │ 63 / 0.02                                 │
│ Starting balance                       │ 1000 USDT                                 │
│ Final balance                          │ 862.503 USDT                              │
│ Absolute profit                        │ -137.497 USDT                             │
│ Total profit %                         │ -13.75%                                   │
│ CAGR %                                 │ -1.62%                                    │
│ Sharpe (closed trades)                 │ -0.02                                     │
│ Sortino (closed trades)                │ -0.05                                     │
│ Calmar (closed trades)                 │ -0.25                                     │
│ SQN                                    │ -0.46                                     │
│ Mean profit p-value                    │ 0.6501                                    │
│ Profit factor                          │ 0.86                                      │
│ Expectancy (Ratio)                     │ -2.18 (-0.09)                             │
│ Avg. daily profit                      │ -0.041 USDT                               │
│ Avg. stake amount                      │ 479.899 USDT                              │
│ Market change                          │ 6338.93%                                  │
│ Total trade volume                     │ 60,450.502 USDT                           │
│                                        │                                           │
│ Best Pair                              │ ETH/USDT 19.64%                           │
│ Worst Pair                             │ BNB/USDT -15.58%                          │
│ Best trade                             │ ETH/USDT 35.27%                           │
│ Worst trade                            │ DOT/USDT -10.18%                          │
│ Best day                               │ 169.456 USDT                              │
│ Worst day                              │ -68.406 USDT                              │
│ Days win/draw/lose                     │ 22 / 2984 / 32                            │
│ Min/Max/Avg. Duration Winners          │ 1d 00:00 / 30d 00:00 / 9d 00:00           │
│ Min/Max/Avg. Duration Losers           │ 0d 00:00 / 12d 00:00 / 3d 00:00           │
│ Max Consecutive Wins / Loss            │ 4 / 6                                     │
│ Rejected Entry signals                 │ 0                                         │
│ Entry/Exit Timeouts                    │ 0 / 0                                     │
│                                        │                                           │
│ Min/Max balance (closed trades)        │ 818.483 USDT / 1204.577 USDT              │
│ Max % of account underwater            │ 32.05%                                    │
│ Absolute drawdown                      │ 386.095 USDT (32.05%)                     │
│ Drawdown duration                      │ 811 days 00:00:00                         │
│ Profit at drawdown start               │ 204.577 USDT                              │
│ Profit at drawdown end                 │ -181.517 USDT                             │
│ Drawdown start                         │ 2022-10-31 00:00:00                       │
│ Drawdown end                           │ 2025-01-19 00:00:00                       │
│                                        │                                           │
│ Wallet based Metrics                   │                                           │
│ Min/Max balance (wallet balance)       │ 817.304 USDT / 1206.118 USDT              │
│ Min/Max balance dates (wallet balance) │ 2025-04-28 / 2021-10-21                   │
│ Max % of account underwater (balance)  │ 32.24%                                    │
│ Absolute drawdown (wallet balance)     │ 388.814 USDT (32.24%)                     │
│ Drawdown duration                      │ 1285 days 00:00:00                        │
│ Drawdown start                         │ 2021-10-21 00:00:00                       │
│ Drawdown end                           │ 2025-04-28 00:00:00                       │
└────────────────────────────────────────┴───────────────────────────────────────────┘

STRATEGY SUMMARY
┏━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┓
┃    Strategy ┃ Trades ┃ Avg Profit % ┃ Tot Profit USDT ┃ Tot Profit % ┃    Avg Duration ┃  Win  Draw  Loss  Win% ┃             Drawdown ┃
┡━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━┩
│ EmaAtrTrend │     63 │        -0.45 │        -137.497 │       -13.75 │ 5 days, 6:51:00 │   24     0    39  38.1 │ 386.095 USDT  32.05% │
└─────────────┴────────┴──────────────┴─────────────────┴──────────────┴─────────────────┴────────────────────────┴──────────────────────┘
```

---

## Step 3: Requested Metrics Summary

| Metric | Value |
|---|---|
| **Total trades (all 8 pairs)** | 63 |
| **Total profit %** | -13.75% |
| **Win rate** | 38.1% (24W / 39L) |
| **Profit factor** | 0.86 |
| **Max absolute drawdown** | 32.05% |
| **Mean profit p-value** | 0.6501 |
| **Rejected Entry signals** | **0** ✅ |

> **Rejected signals = 0** confirms that `max_open_trades=8` was sufficient — no valid crossover signal was ever blocked by portfolio capacity. All 8 pairs could simultaneously hold a position without queuing. This is the true unconstrained signal frequency.

---

## Step 4: Per-Pair Trade Breakdown (All 8 Pairs)

| Pair | # Trades | Win Rate | Sum Profit % | History Start | Notes |
|---|---|---|---|---|---|
| **XRP/USDT** | 15 | 40.0% | -21.35% | 2018-05-04 | Most active; multiple stoploss hits (-10.18%) |
| **BTC/USDT** | 10 | 50.0% | +12.82% | 2017-08-17 | Positive contributor |
| **BNB/USDT** | 9 | 11.1% | -32.44% | 2017-11-06 | ⚠️ Worst performer; 1 win in 9 trades |
| **ETH/USDT** | 9 | 44.4% | +40.88% | 2017-08-17 | Best contributor; big 2021 run (+35.27%, +15.82%) |
| **SOL/USDT** | 7 | 28.6% | -18.80% | 2020-08-11 | Short history; 5 losses |
| **ADA/USDT** | 5 | 60.0% | +9.98% | 2018-04-17 | Modest positive |
| **LTC/USDT** | 5 | 20.0% | -12.92% | 2017-12-13 | Weak performer |
| **DOT/USDT** | 3 | 66.7% | -6.77% | 2020-08-18 | Short history; 1 large loss (-10.18%) wipes 2 wins |
| **TOTAL** | **63** | **38.1%** | **-27.58% (sum)** | — | Combined portfolio: -13.75% abs |

### Full Trade List Per Pair

#### ADA/USDT (5 trades)
| Open | Close | P/L% |
|---|---|---|
| 2019-05-12 | 2019-05-14 | -2.21% |
| 2020-11-13 | 2020-11-20 | +0.85% |
| 2023-03-30 | 2023-04-19 | +10.56% |
| 2024-02-11 | 2024-02-21 | +4.90% |
| 2024-11-09 | 2024-11-09 | -4.13% |

#### BNB/USDT (9 trades) ⚠️
| Open | Close | P/L% |
|---|---|---|
| 2020-07-12 | 2020-07-15 | -0.40% |
| 2021-10-07 | 2021-10-12 | -9.74% |
| 2022-10-29 | 2022-10-31 | +6.67% |
| 2022-11-28 | 2022-12-10 | -7.21% |
| 2023-01-15 | 2023-01-18 | -6.18% |
| 2023-03-17 | 2023-03-22 | -3.59% |
| 2024-08-02 | 2024-08-03 | -5.80% |
| 2025-05-10 | 2025-05-12 | -1.76% |
| 2026-01-15 | 2026-01-19 | -4.42% |

#### BTC/USDT (10 trades)
| Open | Close | P/L% |
|---|---|---|
| 2019-11-07 | 2019-11-12 | -6.67% |
| 2020-10-11 | 2020-10-21 | +11.29% |
| 2021-10-04 | 2021-10-06 | +4.66% |
| 2023-01-14 | 2023-01-14 | -0.41% |
| 2023-06-23 | 2023-07-14 | +0.53% |
| 2024-05-19 | 2024-05-20 | -0.95% |
| 2025-04-25 | 2025-05-08 | +5.06% |
| 2025-09-16 | 2025-09-22 | -2.20% |
| 2025-10-02 | 2025-10-07 | +1.72% |
| 2026-08-21 | 2026-08-21 | -0.20% |

#### DOT/USDT (3 trades)
| Open | Close | P/L% |
|---|---|---|
| 2024-02-13 | 2024-02-20 | +1.20% |
| 2024-11-12 | 2024-11-12 | -10.18% |
| 2025-09-10 | 2025-09-15 | +2.21% |

#### ETH/USDT (9 trades)
| Open | Close | P/L% |
|---|---|---|
| 2018-04-30 | 2018-05-03 | +0.75% |
| 2020-04-24 | 2020-05-04 | +8.60% |
| 2020-10-14 | 2020-10-21 | -3.47% |
| 2021-08-02 | 2021-09-01 | +35.27% |
| 2021-10-03 | 2021-10-22 | +15.82% |
| 2023-05-30 | 2023-06-05 | -4.79% |
| 2023-06-28 | 2023-07-07 | -2.65% |
| 2023-10-26 | 2023-10-27 | -2.05% |
| 2024-05-23 | 2024-05-23 | -6.60% |

#### LTC/USDT (5 trades)
| Open | Close | P/L% |
|---|---|---|
| 2020-10-24 | 2020-10-29 | -1.87% |
| 2023-03-30 | 2023-04-19 | +3.37% |
| 2023-05-24 | 2023-05-25 | -6.59% |
| 2023-05-29 | 2023-06-05 | -2.28% |
| 2026-08-22 | 2026-08-22 | -5.55% |

#### SOL/USDT (7 trades)
| Open | Close | P/L% |
|---|---|---|
| 2021-06-04 | 2021-06-04 | -10.18% |
| 2023-07-09 | 2023-07-13 | +10.27% |
| 2023-10-04 | 2023-10-09 | -7.60% |
| 2024-05-19 | 2024-05-23 | -3.70% |
| 2024-07-20 | 2024-07-25 | -2.29% |
| 2025-01-19 | 2025-01-19 | -9.83% |
| 2026-08-20 | 2026-08-21 | +4.52% |

#### XRP/USDT (15 trades) ⚠️
| Open | Close | P/L% |
|---|---|---|
| 2019-05-15 | 2019-05-15 | -0.60% |
| 2020-10-25 | 2020-10-29 | -6.35% |
| 2020-11-12 | 2020-11-18 | +10.35% |
| 2021-02-05 | 2021-02-07 | -10.18% |
| 2023-01-21 | 2023-01-30 | -5.01% |
| 2023-03-22 | 2023-03-22 | -10.17% |
| 2023-05-29 | 2023-05-30 | +2.12% |
| 2023-07-14 | 2023-07-14 | -10.18% |
| 2023-10-27 | 2023-10-31 | +3.98% |
| 2024-03-01 | 2024-03-03 | +0.99% |
| 2024-07-18 | 2024-07-18 | -10.18% |
| 2024-09-16 | 2024-09-29 | +8.13% |
| 2024-11-12 | 2024-11-12 | -4.06% |
| 2025-07-10 | 2025-07-11 | +14.94% |
| 2026-08-23 | 2026-08-26 | -5.14% |

---

## Step 5: Trade Frequency / Business Viability

| Metric | Value |
|---|---|
| Total trades across 8 pairs | 63 |
| Backtest duration | ~9.07 years (2017-08-17 to 2026-09-13) |
| **Trades per year (portfolio total)** | **~6.9 trades/year** |
| **Trades per year per pair (average)** | **~0.9 trades/year** |
| Active trading days | 54 of 3,308 total days (1.6%) |

**Conclusion on trade frequency:** With 8 pairs, the strategy produces ~7 portfolio-level trades per year, or less than 1 trade per pair per year on average. This is extremely low for a daily-bar strategy and confirms the trade-frequency concern is real. The SMA200 filter is doing its job — blocking false crossovers in bearish/sideways markets — but it also blocks nearly everything in the choppy 2022–2025 range.

---

## Step 6: Observations & Flags

### ⚠️ BNB/USDT — Structural Issue
- **1 win in 9 trades (11.1% win rate), -32.44% sum** 
- BNB's price action appears to generate EMA crossovers that repeatedly fail the subsequent trend test. This is not a data gap — BNB had the longest history of the 6 non-BTC/ETH pairs.
- This is reported factually as instructed; not excluded.

### ⚠️ XRP/USDT — Stoploss Whipsaw Pattern
- **15 trades (most active pair), 40% win rate, -21.35% sum**
- XRP hit the stoploss floor (-10.18%) four times: 2021-02-07, 2023-03-22, 2023-07-14, 2024-07-18. This suggests XRP generates crossover entries into volatile spikes that reverse sharply. The high trade count with negative expectancy (-0.53%/trade) makes XRP the biggest drag.

### ✅ ETH/USDT and BTC/USDT — The Only Profitable Pairs
- ETH: +40.88% sum (driven by the 2021 bull run trades: +35.27% and +15.82%)
- BTC: +12.82% sum
- Both are positive primarily due to the 2020–2021 bull run. Post-2022, both have mixed-to-negative results.

### ✅ Rejected signals = 0
- Confirmed: `max_open_trades=8` was never a binding constraint. The portfolio was never at full capacity simultaneously. Signal suppression from capital limits was not a factor.

### ℹ️ Note on stake_amount
- `stake_amount` is set to a fixed 480 USDT per trade. With `max_open_trades=8` and a 1000 USDT starting wallet, the theoretical maximum simultaneous exposure is 3,840 USDT — 3.84x leverage if all 8 positions opened at once. In practice this never happened (rejected signals = 0, but trades per day ≈ 0.02). The fixed-stake config would need revisiting before production use.
