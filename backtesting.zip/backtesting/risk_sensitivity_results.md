# EmaAtrTrend — Risk % Sensitivity Scan

**Timerange:** 2017-08-17 → 2026-09-13 | **Pairs:** BTC/USDT, ETH/USDT  
**Scan:** Only `risk_pct` in `custom_stake_amount` varied. No signal logic, ATR, stoploss, or exit parameters changed.  
**Trade integrity:** All 5 runs produced exactly **20 trades with identical entry/exit dates** ✅  
**Post-scan:** `risk_pct` restored to `0.01` (1%) as the working default ✅

---

## Comparison Table

| Risk% | Total Profit% | CAGR% | MaxDD% (closed) | MaxDD% (wallet) | Profit Factor | Sharpe (wallet) | Trades |
|------:|-------------:|------:|----------------:|----------------:|--------------:|----------------:|-------:|
| **0.5%** | 1.99% | 0.22% | 1.22% | 1.46% | 1.946 | 0.326 | 20 |
| **1.0%** | 4.00% | 0.43% | 2.44% | 2.91% | 1.932 | 0.328 | 20 |
| **2.0%** | 8.00% | 0.85% | 4.83% | 5.73% | 1.899 | 0.331 | 20 |
| **3.0%** | 11.97% | 1.25% | 7.18% | 8.47% | 1.867 | 0.333 | 20 |
| **5.0%** | 23.02% | 2.31% | 10.65% | 12.65% | 2.066 | 0.404 | 20 |

---

## Factual Observations (no recommendation)

### Linear scaling of both profit and drawdown
Profit and drawdown scale approximately linearly with risk_pct up through 3%:
- Doubling from 1% → 2%: profit doubles (4.0% → 8.0%), drawdown doubles (2.91% → 5.73%)
- Tripling from 1% → 3%: profit triples (4.0% → 12.0%), drawdown triples (2.91% → 8.47%)

This is the expected behaviour of fixed-fractional sizing when the trade sequence is fixed.

### Non-linearity appears at 5%
At 5%, profit grows faster than the linear projection (23% vs. expected ~20%), and the profit factor rises back to 2.066 vs. the declining trend at 1–3%. This is compounding — the two large ETH wins (+35.27% and +15.82%) benefit disproportionately at higher stake levels because they grow the equity base that subsequent positions are sized against.

### Sharpe is nearly flat across all levels
Sharpe (wallet balance) ranges from 0.326 to 0.404 — essentially flat at low risk levels and rising slightly only at 5%. Sharpe is theoretically scale-invariant for fixed-fractional sizing; the mild upward drift at 5% reflects the compounding asymmetry noted above.

### Profit factor trend
Profit factor declines slightly from 0.5%→3% (1.946 → 1.867), then jumps at 5% (2.066). The decline in the 0.5–3% range is a rounding/discretization artifact from the compounding path — at very small risk levels the sequence is nearly linear, so small differences in compounding order show up. The 5% jump is compounding from the big winners.

### Max drawdown at each level
| Risk% | MaxDD% (wallet) | Notes |
|---|---|---|
| 0.5% | 1.46% | Very conservative |
| 1.0% | 2.91% | Current default |
| 2.0% | 5.73% | |
| 3.0% | 8.47% | Approaching meaningful single-event risk |
| 5.0% | 12.65% | Would feel significant on real capital |

The 1012-day drawdown duration (Oct 2021 → Jul 2024) is structural and appears at every risk level — it's a consequence of the signal quality, not the sizing. Sizing only affects the amplitude, not the timing.

---

## Implementation Note

The 0.5% run used the zip from an earlier crashed script attempt. This is valid: the crash was in Python's stdout reader thread (Windows cp1252 encoding failure on UTF-8 box-drawing characters from docker), not in the docker/freqtrade process itself. The backtest completed and wrote the result zip before the Python process crashed. The 20-trade count and date match with all subsequent runs confirms the data is correct.
