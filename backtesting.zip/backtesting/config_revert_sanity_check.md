# Config Revert & Sanity Check — EmaAtrTrend 2-Pair (2017-08-17 → 2026-09-13)

## Config State After Revert

| Setting | Value |
|---|---|
| `pair_whitelist` | BTC/USDT, ETH/USDT |
| `max_open_trades` | 2 |
| `stake_amount` | 480 USDT (fixed — see Phase 3 flag below) |
| `ccxt_config` | `{"options": {"defaultType": "spot"}}` (retained; prevents futures DNS issue, no effect on backtest logic) |
| Strategy files | **Unchanged** — EmaAtrTrend.py, DiagnosticCrossoverOnly.py, DiagnosticCrossoverSMA200.py not touched |

---

## ⚠️ Phase 3 Risk-Sizing Flag (Do Not Fix in This Task)

`stake_amount` is currently a **fixed 480 USDT per trade**, uncoupled from account balance and stoploss distance.

**The defect:** Total exposure scales with concurrent open positions regardless of account equity. With `max_open_trades=2` and `stake_amount=480`, the strategy can commit up to 960 USDT on a 1000 USDT wallet (96% exposure). If both positions hit stoploss simultaneously (~10% each), that's a ~19.2% single-event drawdown on the full account — from just two trades.

**What's needed before live capital:** Fixed-fractional (percent-of-equity) sizing tied to both account balance and stoploss distance (i.e., risk a fixed % of equity per trade, size the position so that a full stoploss hit equals that % loss). This is standard Kelly/fixed-fractional position sizing and is Phase 3 scope.

---

## Backtest Summary Table

```
Backtested 2017-08-17 00:00:00 -> 2026-09-13 00:00:00 | Max open trades: 2

SUMMARY METRICS
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Metric                                 ┃ Value                                     ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ Backtesting from                       │ 2017-08-17 00:00:00                       │
│ Backtesting to                         │ 2026-09-13 00:00:00                       │
│ Max open trades                        │ 2                                         │
│ Total/Daily Avg Trades                 │ 20 / 0.01                                 │
│ Starting balance                       │ 1000 USDT                                 │
│ Final balance                          │ 1252.645 USDT                             │
│ Absolute profit                        │ 252.645 USDT                              │
│ Total profit %                         │ 25.26%                                    │
│ CAGR %                                 │ 2.51%                                     │
│ Sharpe (closed trades)                 │ 0.03                                      │
│ Sortino (closed trades)                │ 0.14                                      │
│ Calmar (closed trades)                 │ 2.22                                      │
│ SQN                                    │ 1.23                                      │
│ Mean profit p-value                    │ 0.2354                                    │
│ Profit factor                          │ 2.69                                      │
│ Expectancy (Ratio)                     │ 12.63 (0.93)                              │
│ Market change                          │ 1206.74%                                  │
│ Best trade                             │ ETH/USDT 35.27%                           │
│ Worst trade                            │ BTC/USDT -6.67%                           │
│ Max Consecutive Wins / Loss            │ 3 / 4                                     │
│ Rejected Entry signals                 │ 0                                         │
│ Max % of account underwater            │ 6.57%                                     │
│ Absolute drawdown                      │ 86.582 USDT (6.57%)                       │
│ Drawdown duration                      │ 1012 days                                 │
│ Drawdown start                         │ 2021-10-22 00:00:00                       │
│ Drawdown end                           │ 2024-07-30 00:00:00                       │
│ Max % underwater (wallet balance)      │ 8.98%                                     │
│ Absolute drawdown (wallet balance)     │ 121.335 USDT (8.98%)                      │
│ Drawdown duration (wallet)             │ 1285 days                                 │
│ Drawdown start (wallet)                │ 2021-10-21 00:00:00                       │
│ Drawdown end (wallet)                  │ 2025-04-28 00:00:00                       │
└────────────────────────────────────────┴───────────────────────────────────────────┘

STRATEGY SUMMARY
┏━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━┓
┃    Strategy ┃ Trades ┃ Avg Profit % ┃ Tot Profit USDT ┃ Tot Profit % ┃     Avg Duration ┃  Win  Draw  Loss  Win% ┃           Drawdown ┃
┡━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━┩
│ EmaAtrTrend │     20 │         2.63 │         252.645 │        25.26 │ 7 days, 16:48:00 │    9     0    11  45.0 │ 86.582 USDT  6.57% │
└─────────────┴────────┴──────────────┴─────────────────┴──────────────┴──────────────────┴────────────────────────┴────────────────────┘
```

---

## Full Trade List — Cross-Reference Against Prior Validated Windows

| # | Pair | Open | Close | P/L% | Window | Prior Match? |
|---|---|---|---|---|---|---|
| 1 | ETH/USDT | 2018-04-30 | 2018-05-03 | +0.75% | 2017–2021 | ✅ |
| 2 | BTC/USDT | 2019-11-07 | 2019-11-12 | -6.67% | 2017–2021 | ✅ |
| 3 | ETH/USDT | 2020-04-24 | 2020-05-04 | +8.60% | 2017–2021 | ✅ |
| 4 | BTC/USDT | 2020-10-11 | 2020-10-21 | +11.29% | 2017–2021 | ✅ |
| 5 | ETH/USDT | 2020-10-14 | 2020-10-21 | -3.47% | 2017–2021 | ✅ |
| 6 | ETH/USDT | 2021-08-02 | 2021-09-01 | +35.27% | 2021–2024 in-sample | ✅ |
| 7 | BTC/USDT | 2021-10-04 | 2021-10-06 | +4.66% | 2021–2024 in-sample | ✅ |
| 8 | ETH/USDT | 2021-10-03 | 2021-10-22 | +15.82% | 2021–2024 in-sample | ✅ |
| 9 | BTC/USDT | 2023-01-14 | 2023-01-14 | -0.41% | 2021–2024 in-sample | ✅ |
| 10 | ETH/USDT | 2023-05-30 | 2023-06-05 | -4.79% | 2021–2024 in-sample | ✅ |
| 11 | ETH/USDT | 2023-06-28 | 2023-07-07 | -2.65% | 2021–2024 in-sample | ✅ |
| 12 | BTC/USDT | 2023-06-23 | 2023-07-14 | +0.53% | 2021–2024 in-sample | ✅ |
| 13 | ETH/USDT | 2023-10-26 | 2023-10-27 | -2.05% | 2021–2024 in-sample | ✅ |
| 14 | BTC/USDT | 2024-05-19 | 2024-05-20 | -0.95% | 2021–2024 in-sample | ✅ |
| 15 | ETH/USDT | 2024-05-23 | 2024-05-23 | -6.60% | 2021–2024 in-sample | ✅ |
| 16 | BTC/USDT | 2024-07-24 | 2024-07-30 | -1.10% | 2024–2026 out-of-sample | ✅ |
| 17 | BTC/USDT | 2025-04-25 | 2025-05-08 | +5.06% | 2024–2026 out-of-sample | ✅ |
| 18 | BTC/USDT | 2025-09-16 | 2025-09-22 | -2.20% | 2024–2026 out-of-sample | ✅ |
| 19 | BTC/USDT | 2025-10-02 | 2025-10-07 | +1.72% | 2024–2026 out-of-sample | ✅ |
| 20 | BTC/USDT | 2026-08-21 | 2026-08-21 | -0.20% | 2024–2026 out-of-sample | ✅ |

**All 20 trades match their respective prior validated windows exactly — dates and P/L% are identical.** The concatenated continuous run is deterministically consistent with the three segmented runs.

---

## Sanity Check: Count Verification

| Window | Expected trades (from prior runs) | Present in this run |
|---|---|---|
| 2017-08-17 → 2021-01-01 | 5 | ✅ 5 (trades 1–5) |
| 2021-01-01 → 2024-06-30 | 10 | ✅ 10 (trades 6–15) |
| 2024-07-01 → 2026-09-13 | 5 | ✅ 5 (trades 16–20) |
| **Total** | **20** | ✅ **20** |

**Sanity check passed. Config revert is confirmed correct. No data contamination, no result drift.**
