# Diagnostic Crossover Only: 2021-2026 Backtest Results

### 1. Full Backtest Summary Table

```text
========================================================= STRATEGY SUMMARY =========================================================
|                Strategy | Trades | Avg Profit % | Tot Profit USDT | Tot Profit % |     Avg Duration |  Win  Draw  Loss  Win% |             Drawdown |
| DiagnosticCrossoverOnly |     35 |        -0.32 |         -54.006 |         -5.4 | 6 days, 13:02:00 |   10     0    25  28.6 | 304.926 USDT  24.38% |
```

```text
| Metric                                 | Value                                     |
|----------------------------------------|-------------------------------------------|
| Backtesting from                       | 2021-01-01 00:00:00                       |
| Backtesting to                         | 2026-09-12 00:00:00                       |
| Trading Mode                           | Spot                                      |
| Max open trades                        | 2                                         |
|                                        |                                           |
| Total/Daily Avg Trades                 | 35 / 0.02                                 |
| Starting balance                       | 1000 USDT                                 |
| Final balance                          | 945.994 USDT                              |
| Absolute profit                        | -54.006 USDT                              |
| Total profit %                         | -5.40%                                    |
| CAGR %                                 | -0.97%                                    |
| Sharpe (closed trades)                 | -0.01                                     |
| Sortino (closed trades)                | -0.04                                     |
| Calmar (closed trades)                 | -0.20                                     |
| SQN                                    | -0.24                                     |
| Mean profit p-value                    | 0.814                                     |
| Profit factor                          | 0.88                                      |
| Expectancy (Ratio)                     | -1.54 (-0.08)                             |
| Avg. daily profit                      | -0.026 USDT                               |
| Avg. stake amount                      | 479.779 USDT                              |
| Market change                          | 205.00%                                   |
| Total trade volume                     | 33597.671 USDT                            |
|                                        |                                           |
| Best Pair                              | ETH/USDT 3.45%                            |
| Worst Pair                             | BTC/USDT -8.85%                           |
| Best trade                             | ETH/USDT 35.27%                           |
| Worst trade                            | ETH/USDT -8.23%                           |
| Best day                               | 169.456 USDT                              |
| Worst day                              | -48.566 USDT                              |
| Days win/draw/lose                     | 10 / 1813 / 22                            |
| Min/Max/Avg. Duration Winners          | 2d 00:00 / 30d 00:00 / 11d 04:48          |
| Min/Max/Avg. Duration Losers           | 0d 00:00 / 14d 00:00 / 4d 16:19           |
| Max Consecutive Wins / Loss            | 5 / 8                                     |
| Rejected Entry signals                 | 0                                         |
| Entry/Exit Timeouts                    | 0 / 0                                     |
|                                        |                                           |
| Min/Max balance (closed trades)        | 945.994 USDT / 1250.92 USDT               |
| Max % of account underwater            | 24.38%                                    |
| Absolute drawdown                      | 304.926 USDT (24.38%)                     |
| Drawdown duration                      | 1598 days 00:00:00                        |
| Profit at drawdown start               | 250.92 USDT                               |
| Profit at drawdown end                 | -54.006 USDT                              |
| Drawdown start                         | 2022-04-06 00:00:00                       |
| Drawdown end                           | 2026-08-21 00:00:00                       |
|                                        |                                           |
| Wallet based Metrics                   |                                           |
| Min/Max balance (wallet balance)       | 945.994 USDT / 1306.415 USDT              |
| Min/Max balance dates (wallet balance) | 2026-08-22 00:00:00 / 2022-03-30 00:00:00 |
| Max % of account underwater (balance)  | 27.59%                                    |
| Absolute drawdown (wallet balance)     | 360.42 USDT (27.59%)                      |
| Drawdown duration                      | 1606 days 00:00:00                        |
| Profit at drawdown start               | 306.415 USDT                              |
| Profit at drawdown end                 | -54.006 USDT                              |
| Drawdown start                         | 2022-03-30 00:00:00                       |
| Drawdown end                           | 2026-08-22 00:00:00                       |
| Sharpe (daily wallet balance)          | -0.07                                     |
| Sortino (daily wallet balance)         | -0.04                                     |
| Calmar (daily wallet balance)          | -0.18                                     |
```

### 2. Specific Summary Metrics

*   **Total profit % (strategy):** -5.40%
*   **Market change % (buy-and-hold):** 205.00%
*   **Absolute drawdown % (closed trades):** 24.38%
*   **Absolute drawdown % (wallet balance):** 27.59%
*   **Max % of account underwater (closed trades):** 24.38%
*   **Max % of account underwater (wallet balance):** 27.59%

### 3. Full Trade List (2021-2026)

*   **BTC/USDT**: Entry 2021-08-01 00:00:00+00:00 -> Exit 2021-08-03 00:00:00+00:00 | Profit: -7.90%
*   **ETH/USDT**: Entry 2021-08-02 00:00:00+00:00 -> Exit 2021-09-01 00:00:00+00:00 | Profit: 35.27%
*   **BTC/USDT**: Entry 2021-10-04 00:00:00+00:00 -> Exit 2021-10-06 00:00:00+00:00 | Profit: 4.66%
*   **ETH/USDT**: Entry 2021-10-03 00:00:00+00:00 -> Exit 2021-10-22 00:00:00+00:00 | Profit: 15.82%
*   **BTC/USDT**: Entry 2022-03-25 00:00:00+00:00 -> Exit 2022-04-01 00:00:00+00:00 | Profit: 0.66%
*   **ETH/USDT**: Entry 2022-03-27 00:00:00+00:00 -> Exit 2022-04-06 00:00:00+00:00 | Profit: 3.72%
*   **ETH/USDT**: Entry 2022-07-30 00:00:00+00:00 -> Exit 2022-08-10 00:00:00+00:00 | Profit: -3.90%
*   **BTC/USDT**: Entry 2022-08-15 00:00:00+00:00 -> Exit 2022-08-18 00:00:00+00:00 | Profit: -4.89%
*   **ETH/USDT**: Entry 2022-09-10 00:00:00+00:00 -> Exit 2022-09-13 00:00:00+00:00 | Profit: -8.23%
*   **ETH/USDT**: Entry 2022-10-31 00:00:00+00:00 -> Exit 2022-11-04 00:00:00+00:00 | Profit: -3.95%
*   **BTC/USDT**: Entry 2022-11-02 00:00:00+00:00 -> Exit 2022-11-08 00:00:00+00:00 | Profit: -1.62%
*   **ETH/USDT**: Entry 2023-01-12 00:00:00+00:00 -> Exit 2023-01-14 00:00:00+00:00 | Profit: 8.71%
*   **BTC/USDT**: Entry 2023-01-14 00:00:00+00:00 -> Exit 2023-01-14 00:00:00+00:00 | Profit: -0.41%
*   **ETH/USDT**: Entry 2023-05-30 00:00:00+00:00 -> Exit 2023-06-05 00:00:00+00:00 | Profit: -4.79%
*   **ETH/USDT**: Entry 2023-06-28 00:00:00+00:00 -> Exit 2023-07-07 00:00:00+00:00 | Profit: -2.65%
*   **BTC/USDT**: Entry 2023-06-23 00:00:00+00:00 -> Exit 2023-07-14 00:00:00+00:00 | Profit: 0.53%
*   **BTC/USDT**: Entry 2023-10-07 00:00:00+00:00 -> Exit 2023-10-11 00:00:00+00:00 | Profit: -4.40%
*   **ETH/USDT**: Entry 2023-10-26 00:00:00+00:00 -> Exit 2023-10-27 00:00:00+00:00 | Profit: -2.05%
*   **BTC/USDT**: Entry 2024-05-19 00:00:00+00:00 -> Exit 2024-05-20 00:00:00+00:00 | Profit: -0.95%
*   **ETH/USDT**: Entry 2024-05-23 00:00:00+00:00 -> Exit 2024-05-23 00:00:00+00:00 | Profit: -6.60%
*   **BTC/USDT**: Entry 2024-07-24 00:00:00+00:00 -> Exit 2024-07-30 00:00:00+00:00 | Profit: -1.10%
*   **BTC/USDT**: Entry 2024-09-23 00:00:00+00:00 -> Exit 2024-10-01 00:00:00+00:00 | Profit: -2.62%
*   **ETH/USDT**: Entry 2024-10-22 00:00:00+00:00 -> Exit 2024-10-23 00:00:00+00:00 | Profit: -7.40%
*   **ETH/USDT**: Entry 2024-10-31 00:00:00+00:00 -> Exit 2024-11-02 00:00:00+00:00 | Profit: -5.74%
*   **ETH/USDT**: Entry 2024-11-08 00:00:00+00:00 -> Exit 2024-11-11 00:00:00+00:00 | Profit: 7.47%
*   **BTC/USDT**: Entry 2025-04-25 00:00:00+00:00 -> Exit 2025-05-08 00:00:00+00:00 | Profit: 5.06%
*   **ETH/USDT**: Entry 2025-05-11 00:00:00+00:00 -> Exit 2025-05-13 00:00:00+00:00 | Profit: -5.09%
*   **BTC/USDT**: Entry 2025-09-16 00:00:00+00:00 -> Exit 2025-09-22 00:00:00+00:00 | Profit: -2.20%
*   **BTC/USDT**: Entry 2025-10-02 00:00:00+00:00 -> Exit 2025-10-07 00:00:00+00:00 | Profit: 1.72%
*   **ETH/USDT**: Entry 2026-01-16 00:00:00+00:00 -> Exit 2026-01-20 00:00:00+00:00 | Profit: -5.38%
*   **BTC/USDT**: Entry 2026-01-18 00:00:00+00:00 -> Exit 2026-01-20 00:00:00+00:00 | Profit: -4.73%
*   **ETH/USDT**: Entry 2026-04-15 00:00:00+00:00 -> Exit 2026-04-29 00:00:00+00:00 | Profit: -3.37%
*   **BTC/USDT**: Entry 2026-04-16 00:00:00+00:00 -> Exit 2026-04-29 00:00:00+00:00 | Profit: -0.02%
*   **ETH/USDT**: Entry 2026-07-23 00:00:00+00:00 -> Exit 2026-08-01 00:00:00+00:00 | Profit: -4.65%
*   **BTC/USDT**: Entry 2026-08-21 00:00:00+00:00 -> Exit 2026-08-21 00:00:00+00:00 | Profit: -0.20%

### 4. Trades During the 2022 Decline Window (2021-11-01 to 2022-12-31)

*   **BTC/USDT**: Entry 2022-03-25 00:00:00+00:00 -> Exit 2022-04-01 00:00:00+00:00 | Profit: 0.66%
*   **ETH/USDT**: Entry 2022-03-27 00:00:00+00:00 -> Exit 2022-04-06 00:00:00+00:00 | Profit: 3.72%
*   **ETH/USDT**: Entry 2022-07-30 00:00:00+00:00 -> Exit 2022-08-10 00:00:00+00:00 | Profit: -3.90%
*   **BTC/USDT**: Entry 2022-08-15 00:00:00+00:00 -> Exit 2022-08-18 00:00:00+00:00 | Profit: -4.89%
*   **ETH/USDT**: Entry 2022-09-10 00:00:00+00:00 -> Exit 2022-09-13 00:00:00+00:00 | Profit: -8.23%
*   **ETH/USDT**: Entry 2022-10-31 00:00:00+00:00 -> Exit 2022-11-04 00:00:00+00:00 | Profit: -3.95%
*   **BTC/USDT**: Entry 2022-11-02 00:00:00+00:00 -> Exit 2022-11-08 00:00:00+00:00 | Profit: -1.62%

### 5. Position Status (2021-11-01 to 2022-12-31)

**STATUS**: The strategy was in an open long position during part(s) of this window. Specifically, there were open positions during the dates shown above (e.g. late March through early April 2022, late July to mid August 2022, mid September 2022, and early November 2022), but it was not entirely flat for the entire window.
